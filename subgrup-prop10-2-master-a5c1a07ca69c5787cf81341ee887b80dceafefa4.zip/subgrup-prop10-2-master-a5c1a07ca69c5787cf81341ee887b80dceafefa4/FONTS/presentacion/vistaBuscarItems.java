package presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import project.CtrlDominio;
import project.Valoracion;

public class vistaBuscarItems extends Vista {

    private JLabel id_it = new JLabel("ID ITEM:");
    private JTextField idIt = new JTextField();
    private JButton busca = new JButton("BUSCA");

    private JList<String> l = new JList<String>();
    private JScrollPane jsc = new JScrollPane();

    public vistaBuscarItems(){
        super.ejecutarVista();

        setLocationRelativeTo(null);
        setLayout(null);

        setResizable(false);

        setTitle("BUSCAR ITEMS");

        ArrayList<String> ats = new ArrayList<>();
        ArrayList<String> val_ats = new ArrayList<>();



        id_it.setFont(new Font("Open Sans", Font.BOLD, 20));
        id_it.setBounds(145,60,100,50);
        add(id_it);

        idIt.setBounds(235,70,355,30);
        idIt.setFont(new Font("Open Sans", Font.PLAIN, 15));
        add(idIt);

        String null_TF = idIt.getText();

        busca.setBackground(Color.darkGray);
        busca.setBounds(600,67,90,35);
        busca.setFont(new Font("Open Sans", Font.BOLD, 12));
        busca.setForeground(Color.WHITE);
        add(busca);
        
        JList newRow = new JList();
	newRow.setLayout(new FlowLayout());
	newRow.setBounds(150,115,175,350);
	newRow.setVisible(true);

	JButton buttonValorar = new JButton("VALORAR");
	buttonValorar.setBounds(0,0,10,10);
	buttonValorar.setVisible(true);
	buttonValorar.setBackground(Color.orange);
	buttonValorar.setPreferredSize(new Dimension(125,25));

	
        String[] posiblesRatings = {"0","1", "2", "3","4","5"};

	JComboBox<String> ratings = new JComboBox<>(posiblesRatings);
	ratings.setSize(10,10);
	ratings.setPreferredSize(new Dimension(40,25));

	JPanel buttonXcombobox = new JPanel();
	buttonXcombobox.setBackground(Color.lightGray);
	buttonXcombobox.setLayout(new BoxLayout(buttonXcombobox, BoxLayout.X_AXIS));
	buttonXcombobox.setVisible(true);
	buttonXcombobox.setBounds(0,50,75,10);
	buttonXcombobox.add(buttonValorar);
	buttonXcombobox.add(ratings);


	buttonValorar.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(ActionEvent e) {
		
		String rating = ((String)ratings.getSelectedItem());
		if(rating.equals("-") || idIt.getText()==null) return;
		if(!CtrlPresentacion.getCtrlDominio().Instance().existe_item(idIt.getText())) {
                    JOptionPane.showMessageDialog(null,"El ID indicado no existe.","ERROR" , 0);
                    return;
		}
		double rating_value = Double.parseDouble(rating);
		CtrlDominio ctrl = CtrlPresentacion.getCtrlDominio().Instance();
		
		ctrl.addValoracion(new Valoracion(ctrl.buscar_item(idIt.getText()),rating_value,CtrlPresentacion.getCtrlDominio().Instance().getPerfil().getID()));
		CtrlPresentacion.recalcularValoracionesUsuario();
	}
	});

	newRow.add(buttonXcombobox);
	add(newRow);
           

        jsc.setBounds(145,110,545,320);
        jsc.setVisible(false);
        add(jsc);

        super.pantallaTrabajoUsuario();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    //CAMBIAR
                    vistaBuscarItems.super.dispose();

                    System.exit(0);
                }
                else if(answer == 1){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaBuscarItems no_exit = new vistaBuscarItems();
                }
            }
        });

        ActionListener buscaIt = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean exist = CtrlPresentacion.getCtrlDominio().Instance().existe_item(idIt.getText());
                String idItem = idIt.getText();

                CtrlPresentacion.addHistorial("Has intentado buscar el item: "+idIt.getText());

                if(idIt.getText().equals(null_TF)){
                    JOptionPane.showMessageDialog(null,"Indique un ID.","ERROR" , 0);
                }
                else if(!exist){
                    JOptionPane.showMessageDialog(null,"El ID indicado no existe.","ERROR" , 0);
                }

                else {

                    ArrayList<String> ats = CtrlPresentacion.getCtrlDominio().Instance().getItembyID(idItem).getCabeceras_atributos();
                    ArrayList<String> val_ats = CtrlPresentacion.getCtrlDominio().Instance().getItembyID(idItem).getValors_atributs();


                    final DefaultListModel<String> l1 = new DefaultListModel<>();

                    for(int i = 0; i < ats.size(); ++i){
                        l1.addElement(ats.get(i) + ": " + val_ats.get(i));
                    }

                    JList<String> l3 = new JList<>(l1);

                    jsc = new JScrollPane(l3);
                    jsc.setBounds(145,150,545,280);
                    jsc.setVisible(true);
                    add(jsc);
                    jsc.revalidate();
                    jsc.repaint();

                }
            }
        };
        busca.addActionListener(buscaIt);

        ejecutarVista();
    }

    @Override
    public void ejecutarVista() {
        super.ejecutarVista();
    }

    private void vistaValorarRecomendaciones(){
        vistaValorarRecomendaciones v_valRec = new vistaValorarRecomendaciones();
    }

    private void vistaConsultarHistorial(){
        vistaConsultarHistorial v_consHist = new vistaConsultarHistorial();
    }

    private void vistaConsultarValoraciones(){
        vistaConsultarValoraciones v_consVals = new vistaConsultarValoraciones();
    }

    private void vistaBuscarItems(){
        vistaBuscarItems v_buscItems = new vistaBuscarItems();
    }

    private void vistaGestionarPerfil(){
        vistaGestionarPerfil v_gestPerf = new vistaGestionarPerfil();
    }
}
