package presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class vistaGestionarPerfil extends Vista {

    //Componentes del menu
    private JLabel logo = new JLabel("RECOMENDADOR");
    private JButton recs = new JButton("RECOMENDACIONES");
    private JButton hist = new JButton("HISTORIAL");
    private JButton vals = new JButton("HIST. VALORACIONES");
    private JButton buscits = new JButton("BUSCA ITEM");
    private JButton exit = new JButton("CERRAR SESION");
    private JButton conf = new JButton("GESTIONAR PERFIL");

    //Botones propios de la vista
    private JButton editarButton = new JButton("EDITAR PERFIL");
    private JButton borrarButton = new JButton("BORRAR PERFIL");

    public vistaGestionarPerfil(){
        super.ejecutarVista();

        setLocationRelativeTo(null);
        setLayout(null);

        setResizable(false);

        setTitle("PAGINA GESTIONAR PERFIL");

        super.pantallaTrabajoUsuario();
        setWindowCloser();
        setButtons();

    }

    private void setWindowCloser() {

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    //CAMBIAR
                    vistaGestionarPerfil.super.dispose();

                    System.exit(0);
                }
                else if(answer == 1){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaGestionarPerfil no_exit = new vistaGestionarPerfil();
                }
            }
        });
    }

    private void setButtons(){
        borrarButton.setBackground(Color.gray);
        borrarButton.setBounds(300, 275,200,100);
        borrarButton.setFont(new Font("Open Sans", Font.BOLD, 20));
        borrarButton.setVisible(true);
        add(borrarButton);

        editarButton.setBackground(Color.gray);
        editarButton.setBounds(300,115,200,100);
        editarButton.setFont(new Font("Open Sans", Font.BOLD, 20));
        editarButton.setVisible(true);
        add(editarButton);

        ActionListener borrarButtonL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int answer = JOptionPane.showConfirmDialog(null,"Seguro que quieres borrar el perfil y todos sus datos?", "CONFIRMACION BORRAR PERFIL", 1);
                if(answer == 0){
                    CtrlPresentacion.eliminarUsuario(CtrlPresentacion.getCtrlDominio().Instance().getPerfil().getID());
                    vistaInicioSesion exit = new vistaInicioSesion();
                    setVisible(false);
                }
            }
        };
        borrarButton.addActionListener(borrarButtonL);

        ActionListener editarButtonL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaEditarPerfil v = new vistaEditarPerfil();
                setVisible(false);
            }
        };
        editarButton.addActionListener(editarButtonL);

    }

}
