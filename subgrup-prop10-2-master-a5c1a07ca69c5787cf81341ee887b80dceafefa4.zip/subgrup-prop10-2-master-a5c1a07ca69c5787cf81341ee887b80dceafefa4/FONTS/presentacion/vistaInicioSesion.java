package presentacion;

import persistencia.CtrlPersistencia;
import project.UsuarioActivo;
import project.Valoracion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

class vistaInicioSesion extends Vista {


    public vistaInicioSesion() {
        super();
        setTitle("INICIO SESION");

        JPanel root = new JPanel();
        //iniciarizar como contenedor root
        this.setContentPane(root);

        setLocationRelativeTo(null);
        setLayout(null);

        setResizable(false);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //LOGO
        JLabel logo = new JLabel("RECOMENDADOR", JLabel.CENTER);
        logo.setFont(new Font("Open Sans", Font.PLAIN, 30));
        logo.setForeground(Color.WHITE);
        logo.setOpaque(true);
        logo.setBackground(Color.BLACK);

        //usuario
        JLabel label1 = new JLabel("Nombre de usuario:  ", JLabel.RIGHT);
        label1.setFont(new Font("Open Sans", Font.BOLD, 15));
        JTextField user = new JTextField(20);
        //contrasena
        JLabel label2 = new JLabel("Contrasena:  ",  JLabel.RIGHT);
        label2.setFont(new Font("Open Sans", Font.BOLD, 15));
        JPasswordField pass = new JPasswordField(20);

        JButton iniciar = new JButton("INICIAR SESION");
        iniciar.setBackground(Color.orange);
        JButton registrar = new JButton("REGISTRAR");
        registrar.setBackground(Color.orange);

        JLabel vacio = new JLabel(" ");
        root.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;

        //LOGO
        c.ipady = 30;       //para que dos filas no queden muy pegados
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        root.add(logo, c);


        //User name:
        c.gridwidth = 1;
        c.ipady = 40;       //para que dos filas no queden muy pegados
        c.gridx = 0;
        c.gridy = 1;
        root.add(label1, c);

        //user testfield:
        c.ipady = 15;
        c.gridx = 1;
        c.gridy = 1;
        root.add(user, c);

        //Password:
        c.ipady = 40;
        c.gridx = 0;
        c.gridy = 2;
        root.add(label2, c);
        //Pass testfield
        c.ipady = 15;
        c.gridx = 1;
        c.gridy = 2;
        root.add(pass, c);

        //Boton inicio
        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 2;
        c.ipady = 15;
        root.add(iniciar, c);


        //Boton registro
        c.ipady = 0;
        c.gridx = 1;
        c.gridy = 4;
        c.gridwidth = 2;
        //c.weighty = 1.0;
        root.add(vacio, c);

        c.gridx = 1;
        c.gridy = 5;
        c.gridwidth = 1;
        //c.weighty = 1.0;
        root.add(registrar, c);


        //config size windows
        //tratamiento para el boton registrar
        registrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //JOptionPane.showMessageDialog(null, "Hellow World");
                vistaRegistro();
                setVisible(false);
            }
        });


        //tratamiento para el boton iniciar
        iniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String id_user = user.getText();
                String myPass=String.valueOf(pass.getPassword());



                    boolean inicio_es_correcto = CtrlPresentacion.getCtrlDominio().Instance().iniciar_sesion_p(id_user, myPass);

                    if (inicio_es_correcto) {

                        //mirar si es usuario o admin
                        if (CtrlPresentacion.getCtrlDominio().Instance().getPerfil() instanceof UsuarioActivo) {
                            //cargar datos usuario
                            CtrlPresentacion.cargar_datos_usuario();

                            vistaPrincipalUsuarioActivo vistausuario = new vistaPrincipalUsuarioActivo();
                        }

                        else {
                            //cargar datos admin
                            CtrlPresentacion.cargar_datos_administrador();

                            vistaPrincipalAdmin vistaadmin = new vistaPrincipalAdmin();
                        }

                        setVisible(false);
                      }

                      else {
                        JOptionPane.showMessageDialog(null, "Nombre de usuario o contrasena incorrecta");
                      }






            }
        });

        super.ejecutarVista();
    }

    private void vistaRegistro(){
        vistaRegistro vReg = new vistaRegistro();
    }
}
