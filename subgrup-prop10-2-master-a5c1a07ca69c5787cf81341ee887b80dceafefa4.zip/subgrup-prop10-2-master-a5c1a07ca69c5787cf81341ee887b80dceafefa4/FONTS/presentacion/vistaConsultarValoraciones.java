package presentacion;

import project.Valoracion;
import project.Perfil;
import project.CtrlDominio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

public class vistaConsultarValoraciones extends Vista {

    private JLabel logo = new JLabel("RECOMENDADOR");
    private JLabel tuHistorialLabel = new JLabel("TUS VALORACIONES:");
    private JButton exit = new JButton("CIERRA SESION");

    private JButton recs = new JButton("RECOMENDACIONES");
    private JButton hist = new JButton("HISTORIAL");
    private JButton vals = new JButton("HIST. VALORACIONES");
    private JButton buscits = new JButton("BUSCA ITEM");
    private JButton conf = new JButton("GESTIONAR PERFIL");

    vistaConsultarValoraciones(){
        super();

        setLocationRelativeTo(null);
        setLayout(null);

        setTitle("VALORACIONES");

        CtrlPresentacion.addHistorial("Has consultado el historial de valoraciones.");

        setResizable(false);

        logo.setForeground(Color.WHITE);
        logo.setBounds(0,0,125,50);
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        logo.setVerticalAlignment(SwingConstants.CENTER);
        add(logo);

        recs.setBackground(Color.orange);
        recs.setBounds(0,50,125,50);
        recs.setFont(new Font("Open Sans", Font.BOLD, 8));
        recs.setVisible(true);
        add(recs);


        hist.setBackground(Color.orange);
        hist.setBounds(0,101,125,50);
        hist.setFont(new Font("Open Sans", Font.BOLD, 12));
        hist.setVisible(true);
        add(hist);

        vals.setBackground(Color.orange);
        vals.setBounds(0,152,125,50);
        vals.setFont(new Font("Open Sans", Font.BOLD, 8));
        vals.setVisible(true);
        add(vals);

        buscits.setBackground(Color.orange);
        buscits.setBounds(0, 203, 125, 50);
        buscits.setFont(new Font("Open Sans", Font.BOLD, 12));
        buscits.setVisible(true);
        add(buscits);

        exit.setBackground(Color.RED);
        exit.setBounds(0, 390, 125, 50);
        exit.setFont(new Font("Open Sans", Font.BOLD, 10));
        exit.setVisible(true);
        add(exit);


        conf.setBackground(Color.gray);
        conf.setBounds(540,10,150,30);
        conf.setFont(new Font("Open Sans", Font.BOLD, 12));
        conf.setVisible(true);
        add(conf);

        tuHistorialLabel.setBounds(150, 75 + 25, 200, 10);
        tuHistorialLabel.setHorizontalAlignment(SwingConstants.LEFT);
        tuHistorialLabel.setVerticalAlignment(SwingConstants.CENTER);
        add(tuHistorialLabel);

        JPanel columna = new JPanel();
        columna.setBackground(Color.gray);
        columna.setBounds(0,50,125,380);
        add(columna);

        JPanel fila = new JPanel();
        fila.setBackground(Color.darkGray);
        fila.setBounds(125,0,595,50);
        add(fila);

        JPanel logoB = new JPanel();
        logoB.setBackground(Color.BLACK);
        logoB.setBounds(0,0,125,50);
        add(logoB);

        ActionListener gestionar_user = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaGestionarPerfil();
                setVisible(false);
            }
        };
        conf.addActionListener(gestionar_user);

        ActionListener recoms = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaValorarRecomendaciones();
                setVisible(false);
            }
        };
        recs.addActionListener(recoms);

        ActionListener histL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaConsultarHistorial();
                setVisible(false);
            }
        };
        hist.addActionListener(histL);

        ActionListener valsL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaConsultarValoraciones();
                setVisible(false);
            }
        };
        vals.addActionListener(valsL);

        ActionListener buscitsL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaBuscarItems();
                setVisible(false);
            }
        };
        buscits.addActionListener(buscitsL);

        ActionListener cerrar_ses = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int answer = JOptionPane.showConfirmDialog(null, "Seguro que quieres cerrar la sesión?", "Confirmacion cerrar sesion", 1);
                if(answer == 0){
                    setVisible(false);
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                }
            }
        };

        exit.addActionListener(cerrar_ses);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    //CAMBIAR
                    dispose();

                    System.exit(0);
                }
                else if(answer == 1){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaConsultarValoraciones no_exit = new vistaConsultarValoraciones();
                }
            }
        });

	ArrayList<Valoracion> valoracionesUsuario = new ArrayList<Valoracion>();
	CtrlDominio ctrlD = CtrlPresentacion.getCtrlDominio().Instance();
	valoracionesUsuario = ctrlD.getValoraciones(ctrlD.getPerfil().getID());
	ejecutarVista(valoracionesUsuario);
    }

    public void ejecutarVista(ArrayList<Valoracion> historialUsuario) {

        JPanel listHistorias = new JPanel();
        listHistorias.setBackground(Color.WHITE);
        listHistorias.setLayout(new BoxLayout(listHistorias, BoxLayout.Y_AXIS));
        int startX = 160, startY = 150;

        int i = 1;
        for(Valoracion val : historialUsuario) {
            JLabel h = new JLabel();
            h.setText("·  Item " + val.get_Item().getID() + "  >  " + val.getValor());
            h.setBounds(5,i*25+20, h.getText().length() * 2, 20);
            listHistorias.add(h);
            i++;
        }

        JScrollPane jScrollPane = new JScrollPane(listHistorias);
        jScrollPane.setBounds(150,140, 500, 260);
        add(jScrollPane);

        super.ejecutarVista();
    }

    private void vistaValorarRecomendaciones(){
        vistaValorarRecomendaciones v_valRec = new vistaValorarRecomendaciones();
    }

    private void vistaConsultarHistorial(){
        vistaConsultarHistorial v_consHist = new vistaConsultarHistorial();
    }

    private void vistaConsultarValoraciones(){
        vistaConsultarValoraciones v_consVals = new vistaConsultarValoraciones();
    }

    private void vistaBuscarItems(){
        vistaBuscarItems v_buscItems = new vistaBuscarItems();
    }

    private void vistaGestionarPerfil(){
        vistaGestionarPerfil v_gestPerf = new vistaGestionarPerfil();
    }

}
