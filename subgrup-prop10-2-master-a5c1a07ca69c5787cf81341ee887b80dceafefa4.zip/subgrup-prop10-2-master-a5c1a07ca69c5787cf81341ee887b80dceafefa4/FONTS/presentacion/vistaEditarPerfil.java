package presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import project.CtrlDominio;

public class vistaEditarPerfil extends Vista {

    private JLabel logo = new JLabel("RECOMENDADOR");
    private JButton exit = new JButton("CIERRA SESION");


    private JLabel label_user = new JLabel("Nuevo nombre usuario: ");
    private JTextField user = new JTextField(20);

    private JLabel label_pass = new JLabel("Nueva contrasena: ");
    private JPasswordField pass = new JPasswordField(20);

    private JLabel label_cpass = new JLabel("Confirmar contrasena: ");
    private JPasswordField cpass = new JPasswordField(20);

    private JButton confirm_user = new JButton("CONFIRMAR NOMBRE");
    private JButton confirm = new JButton("CONFIRMAR CONTRASENA");
    private JButton cancel = new JButton("CANCELAR");

    private JButton recomendacion = new JButton("RECOMENDACIONES");
    private JButton historial = new JButton("HISTORIAL");
    private JButton valoracion = new JButton("VALORACIONES");
    private JButton buscar_item = new JButton("BUSCAR ITEMS");


    public vistaEditarPerfil() {
        super();


        //configuracion de estilo
        label_user.setFont(new Font("Open Sans", Font.BOLD, 15));
        label_pass.setFont(new Font("Open Sans", Font.BOLD, 15));
        label_cpass.setFont(new Font("Open Sans", Font.BOLD, 15));

        confirm.setFont(new Font("Open Sans", Font.BOLD, 15));
        confirm.setHorizontalTextPosition( SwingConstants.CENTER);
        confirm.setOpaque(true);
        confirm.setBackground(Color.orange);

        confirm_user.setFont(new Font("Open Sans", Font.BOLD, 15));
        confirm_user.setHorizontalTextPosition( SwingConstants.CENTER);
        confirm_user.setOpaque(true);
        confirm_user.setBackground(Color.orange);

        cancel.setFont(new Font("Open Sans", Font.BOLD, 20));
        cancel.setHorizontalTextPosition( SwingConstants.CENTER);
        cancel.setOpaque(true);
        cancel.setBackground(Color.RED);



        setLocationRelativeTo(null);
        setLayout(null);

        setTitle("Editar Perfil");
        //logo
        logo.setForeground(Color.WHITE);
        logo.setBounds(0,0,125,50);
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        logo.setVerticalAlignment(SwingConstants.CENTER);
        add(logo);

        //recomendaciones
        recomendacion.setBackground(Color.orange);
        recomendacion.setBounds(0,50,125,50);
        recomendacion.setFont(new Font("Open Sans", Font.BOLD, 9));
        recomendacion.setVisible(true);
        add(recomendacion);

        //consultar historial
        historial.setBackground(Color.orange);
        historial.setBounds(0,50 +50,125,50);
        historial.setFont(new Font("Open Sans", Font.BOLD, 12));
        historial.setVisible(true);
        add(historial);

        //consultar valoraciones
        valoracion.setBackground(Color.orange);
        valoracion.setBounds(0,100 + 50,125,50);
        valoracion.setFont(new Font("Open Sans", Font.BOLD, 11));
        valoracion.setVisible(true);
        add(valoracion);

        //buscar item
        buscar_item.setBackground(Color.orange);
        buscar_item.setBounds(0,150 + 50,125,50);
        buscar_item.setFont(new Font("Open Sans", Font.BOLD, 11));
        buscar_item.setVisible(true);
        add(buscar_item);

        //cerrar sesion
        exit.setBackground(Color.RED);
        exit.setBounds(0, 390, 125, 50);
        exit.setFont(new Font("Open Sans", Font.BOLD, 10));
        exit.setVisible(true);
        add(exit);

        //label nombre usuario
        label_user.setBounds(150, 100, 200, 25);
        label_user.setHorizontalAlignment(SwingConstants.LEFT);
        label_user.setVerticalAlignment(SwingConstants.CENTER);
        add(label_user);

        //text nombre usuario
        user.setBounds(150 + 200, 100, 200, 25);
        user.setHorizontalAlignment(SwingConstants.LEFT);
        add(user);

        //boton confirmar edicion usuario
        confirm_user.setBounds(150 + 120, 140, 210, 40);
        confirm_user.setHorizontalAlignment(SwingConstants.LEFT);
        add(confirm_user);


        //label contrasena
        label_pass.setBounds(185, 215, 200, 25);
        label_pass.setHorizontalAlignment(SwingConstants.LEFT);
        label_pass.setVerticalAlignment(SwingConstants.CENTER);
        add(label_pass);

        //text contrasena
        pass.setBounds(150 + 200, 215, 200, 25);
        pass.setHorizontalAlignment(SwingConstants.LEFT);
        add(pass);

        //label confirmar contrasena
        label_cpass.setBounds(155, 250, 200, 25);
        label_cpass.setHorizontalAlignment(SwingConstants.LEFT);
        label_cpass.setVerticalAlignment(SwingConstants.CENTER);
        add(label_cpass);

        //text confirmar contrasena
        cpass.setBounds(150 + 200, 250, 200, 25);
        cpass.setHorizontalAlignment(SwingConstants.LEFT);
        add(cpass);

        //boton confirmar edicion
        confirm.setBounds(150 + 100, 290, 250, 40);
        confirm.setHorizontalAlignment(SwingConstants.LEFT);
        add(confirm);

        //boton cancelar
        cancel.setBounds(300, 380, 150, 30);
        cancel.setHorizontalAlignment(SwingConstants.LEFT);
        add(cancel);


        //Colores de plantilla
        JPanel columna = new JPanel();
        columna.setBackground(Color.gray);
        columna.setBounds(0,50,125,380);
        add(columna);

        JPanel fila = new JPanel();
        fila.setBackground(Color.darkGray);
        fila.setBounds(125,0,595,50);
        add(fila);

        JPanel logoB = new JPanel();
        logoB.setBackground(Color.BLACK);
        logoB.setBounds(0,0,125,50);
        add(logoB);

        super.ejecutarVista();

        //BARRA DE MENUS



        recomendacion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaValorarRecomendaciones();
                setVisible(false);
            }
        });

        historial.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaConsultarHistorial();
                setVisible(false);
            }
        });

        valoracion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaConsultarValoraciones();
                setVisible(false);
            }
        });

        buscar_item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaBuscarItems();
                setVisible(false);
            }
        });

        confirm_user.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name_user = user.getText();
                if (name_user.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "La casilla esta en blanco!");
                }
                else {
                    int answer = JOptionPane.showConfirmDialog(null, "Estas seguro de cambiar el nombre de usuario?", "Confirmar nombre",1);
                    if(answer == 0) {
                        if(CtrlDominio.Instance().existUsername(name_user)){
                        	JOptionPane.showMessageDialog(null, "El nombre de usuario " + name_user + " ya existe!");
                        } else {
		                CtrlPresentacion.getPerfil().setNickname(name_user);
		                CtrlDominio.Instance().actualizarUsuario(CtrlDominio.Instance().getPerfil(),name_user,CtrlDominio.Instance().getPerfil().getPassword());
		                JOptionPane.showMessageDialog(null, "Nuevo nombre de usuario: " + name_user);
                        }
                    }
                }
            }
        });


        confirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String myPass=String.valueOf(pass.getPassword());
                String cPass=String.valueOf(cpass.getPassword());

                if(myPass.isEmpty() | cPass.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Hay que rellenar todas las dos casillas!");
                }

                else if(!myPass.equals(cPass)) {
                    JOptionPane.showMessageDialog(null, "Las contrasenas no coinciden!");
                }

                else {
                    //setVisible(false);
                    int answer = JOptionPane.showConfirmDialog(null, "Estas seguro de cambiar la contrasena?", "Confirmar contrasena",1);


                    if (answer == 0) {
                        CtrlPresentacion.getPerfil().setPassword(myPass);
                        CtrlPresentacion.addHistorial("Se han editado los valores del perfil.");
                        CtrlDominio.Instance().actualizarUsuario(CtrlDominio.Instance().getPerfil(),CtrlDominio.Instance().getPerfil().getNickname(), myPass);
                        JOptionPane.showMessageDialog(null, "Nueva contrasena: " + myPass);
                    }
                }
            }
        });



        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int answer = JOptionPane.showConfirmDialog(null, "Seguro que quieres cerrar la sesión?", "Confirmacion cerrar sesion", 1);
                if(answer == 0){
                    setVisible(false);
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                }
            }
        });

        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //volver a la pantalla de gestionar perfil
                setVisible(false);
                vistaGestionarPerfil();
            }
        });



        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    //CAMBIAR
                    dispose();

                    System.exit(0);
                }
                else if(answer == 1){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaEditarPerfil();
                }
            }
        });

    }

    //declaracion de vistas
    private void vistaValorarRecomendaciones(){
        vistaValorarRecomendaciones v_valRec = new vistaValorarRecomendaciones();
    }

    private void vistaConsultarHistorial(){
        vistaConsultarHistorial v_consHist = new vistaConsultarHistorial();
    }

    private void vistaConsultarValoraciones(){
        vistaConsultarValoraciones v_consVals = new vistaConsultarValoraciones();
    }

    private void vistaBuscarItems(){
        vistaBuscarItems v_buscItems = new vistaBuscarItems();
    }

    private void vistaGestionarPerfil(){
        vistaGestionarPerfil v_gestPerf = new vistaGestionarPerfil();
    }

    private void vistaEditarPerfil() {vistaEditarPerfil v_editPerf = new vistaEditarPerfil();}



}
