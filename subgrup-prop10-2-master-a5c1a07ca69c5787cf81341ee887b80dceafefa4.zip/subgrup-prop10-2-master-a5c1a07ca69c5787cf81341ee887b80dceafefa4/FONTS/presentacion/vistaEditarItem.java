package presentacion;

import project.Item;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

public class vistaEditarItem extends Vista {

    private JButton buscIt = new JButton("BUSCA");
    private JButton conF = new JButton("CONFIRMA EDICION");
    private JButton cancel = new JButton("CANCELAR");

    private JLabel tit = new JLabel("Que item quieres editar?");
    private JLabel idIt = new JLabel("ID ITEM:");
    private JLabel nAtr = new JLabel("Atributo:");
    private JLabel vAtr = new JLabel("Nuevo valor:");

    private JTextField idI = new JTextField();
    private JTextField nAt = new JTextField();
    private JTextField vAt = new JTextField();

    public vistaEditarItem(){
        setLocationRelativeTo(null);
        setLayout(null);

        setResizable(false);

        setTitle("EDITAR ITEM");

        super.pantallaTrabajoAdmin();

        tit.setBounds(140, 60, 565, 50);
        tit.setHorizontalAlignment(SwingConstants.CENTER);
        tit.setVerticalAlignment(SwingConstants.CENTER);
        tit.setFont(new Font("Open Sans", Font.BOLD, 18));
        tit.setVisible(true);
        add(tit);

        idIt.setBounds(155, 120, 100, 50);
        idIt.setFont(new Font("Open Sans", Font.BOLD, 18));
        idIt.setVisible(true);
        add(idIt);

        idI.setBounds(240, 130, 340, 30);
        idI.setFont(new Font("Open Sans", Font.PLAIN, 15));
        idI.setVisible(true);
        add(idI);

        buscIt.setBackground(Color.gray);
        buscIt.setBounds(590, 130, 90, 30);
        buscIt.setFont(new Font("Open Sans", Font.BOLD, 15));
        buscIt.setVisible(true);
        add(buscIt);

        nAtr.setBounds(155, 200, 90, 30);
        nAtr.setFont(new Font("Open Sans", Font.BOLD, 18));
        nAtr.setVisible(false);
        add(nAtr);

        nAt.setBounds(240, 200, 255, 30);
        nAt.setFont(new Font("Open Sans", Font.PLAIN, 15));
        nAt.setVisible(false);
        add(nAt);

        vAtr.setBounds(155, 250, 150, 30);
        vAtr.setFont(new Font("Open Sans", Font.BOLD, 18));
        vAtr.setVisible(false);
        add(vAtr);

        vAt.setBounds(275, 250, 255, 30);
        vAt.setFont(new Font("Open Sans", Font.PLAIN, 15));
        vAt.setVisible(false);
        add(vAt);

        conF.setBackground(Color.orange);
        conF.setBounds(230,320,362,50);
        conF.setFont(new Font("Open Sans", Font.BOLD, 18));
        conF.setVisible(false);
        add(conF);

        cancel.setBackground(Color.RED);
        cancel.setBounds(301,385,220,40);
        cancel.setFont(new Font("Open Sans", Font.BOLD, 18));
        cancel.setVisible(false);
        add(cancel);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){

                    //CAMBIAR
                    dispose();

                    System.exit(0);
                }
                else if(answer == 1){

                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaEditarItem no_exit = new vistaEditarItem();
                }
            }
        });

        ActionListener buscaList = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(idI.getText().equals("")) JOptionPane.showMessageDialog(null, "Indica un ID item.", "ERROR", 0);
                else if(CtrlPresentacion.getCtrlDominio().Instance().existe_item(idI.getText())){
                    nAtr.setVisible(true);
                    nAt.setVisible(true);
                    vAtr.setVisible(true);
                    vAt.setVisible(true);
                    conF.setVisible(true);
                    cancel.setVisible(true);
                }
                else JOptionPane.showMessageDialog(null, "No existe este item.", "ERROR", 0);
            }
        };
        buscIt.addActionListener(buscaList);

        ActionListener confList = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!nAt.getText().equals("") && !vAt.getText().equals("")) {
                    if (CtrlPresentacion.getCtrlDominio().Instance().getItembyID(idI.getText()).getCabeceras_atributos().contains(nAt.getText())) {

                        Item i = CtrlPresentacion.getCtrlDominio().Instance().buscar_item(idI.getText());
                        ArrayList<String> ats = i.getCabeceras_atributos();
                        if (ats.contains(nAt.getText())) {
                            int at = it_Atr(nAt.getText());
                            i.setValor(at, vAt.getText());

                            JOptionPane.showMessageDialog(null, "Editado correctamente.", "ERROR", 1);

                        } else JOptionPane.showMessageDialog(null, "Este atributo no existe.", "ERROR", 0);
                    } else {
                        JOptionPane.showMessageDialog(null, "Este item no contiene ese atributo.", "ERROR", 0);
                    }
                }
                else {
                    JOptionPane.showMessageDialog(null, "Indica atributo y valor.", "ERROR", 0);
                }

            }
        };
        conF.addActionListener(confList);

        ActionListener canList = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaGestionaItems();
                setVisible(false);
            }
        };
        cancel.addActionListener(canList);

        ejecutarVista();
    }

    private int it_Atr(String at) {
        ArrayList<String> a = CtrlPresentacion.getCtrlDominio().Instance().getItembyID(idI.getText()).getCabeceras_atributos();
        for(int i = 0; i < a.size(); ++i){
            if(a.get(i).equals(at)) return i;
        }
        return -1;
    }

    @Override
    public void ejecutarVista() {
        super.ejecutarVista();
    }

    private void vistaGestionaItems(){
        vistaGestionarItems v_gesPerf = new vistaGestionarItems();
    }

}

