package presentacion;

import persistencia.CtrlPersistencia;
import project.CtrlDominio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class vistaBorrarItem extends Vista {

    // Componentes del menu
    private JLabel logo = new JLabel("RECOMENDADOR");
    private JButton gesits = new JButton("GESTIONAR ITEMS");
    private JButton exit = new JButton("CIERRA SESION");
    private JLabel WELCOME = new JLabel("BIENVENIDO ADMINISTRADOR");

    // Componentes principales
    private JLabel messageLabel = new JLabel("Que item quieres borrar?");
    private JLabel messageLabel2 = new JLabel("ID item:");
    private JTextField idItemTextField = new JTextField();
    private JButton confirmarButton = new JButton("CONFIRMAR");
    private JButton cancelarButton = new JButton("CANCELAR");

    public vistaBorrarItem(){
        super.ejecutarVista();

        setLocationRelativeTo(null);
        setLayout(null);

        setResizable(false);

        setTitle("BORRAR ITEM");

        super.pantallaTrabajoAdmin();
        setWindowCloser();


        setButtons();
    }

    private void setWindowCloser() {

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    //CAMBIAR
                    vistaBorrarItem.super.dispose();
                    System.exit(0);
                }
                else if(answer == 1) {
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaPrincipalAdmin no_exit = new vistaPrincipalAdmin();
                }
            }
        });
    }


    private void setButtons(){

        messageLabel.setForeground(Color.BLACK);
        messageLabel.setBounds(125,50,595,100);
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        messageLabel.setVerticalAlignment(SwingConstants.CENTER);
        messageLabel.setFont(new Font("Open Sans", Font.BOLD, 25));
        add(messageLabel);

        messageLabel2.setForeground(Color.BLACK);
        messageLabel2.setBounds(140,135,100,50);
        messageLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        messageLabel2.setVerticalAlignment(SwingConstants.CENTER);
        messageLabel2.setFont(new Font("Open Sans", Font.BOLD, 20));
        add(messageLabel2);

        idItemTextField.setBounds(235,145,400,30);
        add(idItemTextField);

        confirmarButton.setBackground(Color.gray);
        confirmarButton.setBounds(272, 220,300,60);
        confirmarButton.setFont(new Font("Open Sans", Font.BOLD, 20));
        confirmarButton.setVisible(true);
        add(confirmarButton);

        cancelarButton.setBackground(Color.red);
        cancelarButton.setBounds(322, 310,200,60);
        cancelarButton.setFont(new Font("Open Sans", Font.BOLD, 20));
        cancelarButton.setVisible(true);
        add(cancelarButton);

        ActionListener confirmarButtonL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //borrar item
                if(!CtrlPresentacion.getCtrlDominio().Instance().borraItem(idItemTextField.getText())) JOptionPane.showMessageDialog(null, "El ID item asignado no existe.", "ERROR", 0);
                else {
                    JOptionPane.showMessageDialog(null, "Item borrado correctamente.", "BORRAR", 1);
                }
            }
        };
        confirmarButton.addActionListener(confirmarButtonL);

        ActionListener cancelarButtonL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaGestionarItems v = new vistaGestionarItems();
                setVisible(false);
            }
        };
        cancelarButton.addActionListener(cancelarButtonL);

        super.ejecutarVista();
    }
}

