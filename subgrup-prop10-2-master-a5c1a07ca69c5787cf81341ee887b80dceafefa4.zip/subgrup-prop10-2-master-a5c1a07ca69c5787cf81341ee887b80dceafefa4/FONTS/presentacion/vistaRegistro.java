package presentacion;
import project.CtrlDominio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class vistaRegistro extends Vista {


    public vistaRegistro(){
        super();
        setTitle("REGISTRO");
        setLocationRelativeTo(null);
        setLayout(null);

        setResizable(false);

        JPanel root = new JPanel();
        this.setContentPane(root);


        JLabel titulo = new JLabel("REGISTRO", JLabel.CENTER);
        titulo.setFont(new Font("Open Sans", Font.PLAIN, 30));

        JLabel label_usuario = new JLabel("Nombre de usuario: ", JLabel.RIGHT);
        label_usuario.setFont(new Font("Open Sans", Font.BOLD, 15));
        JTextField user = new JTextField(20);

        JLabel label_password = new JLabel("Contrasena: ", JLabel.RIGHT);
        label_password.setFont(new Font("Open Sans", Font.BOLD, 15));
        JPasswordField pass = new JPasswordField(20);

        JLabel label_cpassword = new JLabel("Confirmar contrasena: ", JLabel.RIGHT);
        label_cpassword.setFont(new Font("Open Sans", Font.BOLD, 15));
        JPasswordField cpass = new JPasswordField(20);

        JButton registrar = new JButton("REGISTRAR");
        registrar.setFont(new Font("Open Sans", Font.BOLD, 15));
        registrar.setBackground(Color.orange);

        JButton cancel = new JButton("CANCELAR");
        cancel.setFont(new Font("Open Sans", Font.BOLD, 15));
        cancel.setBackground(Color.red);

        JLabel vacio = new JLabel(" ");

        root.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        //label titulo
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 0;
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        root.add(titulo, c);

        //label nombre usuario
        c.gridwidth = 1;
        c.ipady = 40;
        c.gridx = 0;
        c.gridy = 1;
        root.add(label_usuario, c);

        //label textfield usuario
        c.ipady = 15;
        c.gridx = 1;
        c.gridy = 1;
        root.add(user, c);

        //label text field contrasena
        c.ipady = 40;
        c.gridx = 0;
        c.gridy = 2;
        root.add(label_password, c);

        //passfield contrasena
        c.ipady = 15;
        c.gridx = 1;
        c.gridy = 2;
        root.add(pass, c);

        //label text field confirmar contrasena
        c.ipady = 40;
        c.gridx = 0;
        c.gridy = 3;
        root.add(label_cpassword, c);

        //passfield confirmar contrasena
        c.ipady = 15;
        c.gridx = 1;
        c.gridy = 3;
        root.add(cpass, c);

        //boton registrar
        c.ipady = 15;
        c.gridx = 0;
        c.gridy = 4;
        c.gridwidth = 2;
        root.add(registrar, c);

        c.ipady = 0;
        c.gridx = 1;
        c.gridy = 5;
        c.gridwidth = 1;
        root.add(vacio, c);

        //boton cancelar
        c.ipady = 0;
        c.gridx = 1;
        c.gridy = 6;
        root.add(cancel, c);


        registrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String name_user = user.getText();
                String myPass=String.valueOf(pass.getPassword());
                String cPass=String.valueOf(cpass.getPassword());

                if(name_user.isEmpty() | myPass.isEmpty() | cPass.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor rellene todas las opciones!");
                }

                else if(!myPass.equals(cPass)) {
                    JOptionPane.showMessageDialog(null, "Las contrasenas no coinciden!");
                }

                else {

                    boolean registro_correcto = CtrlPresentacion.getCtrlDominio().Instance().registrar_p(name_user, myPass);
                    if (registro_correcto) {
                        JOptionPane.showMessageDialog(null, "Te has registrado correctamente");
                        vistaInicioSesion();
                        setVisible(false);
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "El nombre de usuario ya existe, prueba con otra");
                    }


                }

            }
        });

        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                vistaInicioSesion();
            }
        });

        super.ejecutarVista();
    }

    private static void vistaInicioSesion(){
        vistaInicioSesion v_inicSes = new vistaInicioSesion();
    }

}

