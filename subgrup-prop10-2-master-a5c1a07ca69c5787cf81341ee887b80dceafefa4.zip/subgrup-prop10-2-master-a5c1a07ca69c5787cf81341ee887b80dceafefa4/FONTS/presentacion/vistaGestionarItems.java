package presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class vistaGestionarItems extends Vista {

    private JPanel content;

    // Componentes del menu
    private JLabel logo = new JLabel("RECOMENDADOR");
    private JButton gest = new JButton("GESTIONAR ITEMS");
    private JButton exit = new JButton("CERRAR SESION");

    //Botones propios de la vista
    private JButton crearButton = new JButton("CREAR ITEM");
    private JButton editarButton = new JButton("EDITAR ITEM");;
    private JButton borrarButton = new JButton("BORRAR ITEM");;

    public vistaGestionarItems() {

        super.ejecutarVista();

        setLocationRelativeTo(null);
        setLayout(null);

        setResizable(false);

        setTitle("GESTIONAR ITEM");

        setBorderPanels();
        setButtons();
    }

    private void setBorderPanels() {

        logo.setForeground(Color.WHITE);
        logo.setBounds(0,0,125,50);
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        logo.setVerticalAlignment(SwingConstants.CENTER);
        add(logo);

        exit.setBackground(Color.RED);
        exit.setBounds(0, 390, 125, 50);
        exit.setFont(new Font("Open Sans", Font.BOLD, 10));
        exit.setVisible(true);
        add(exit);

        JPanel columna = new JPanel();
        columna.setBackground(Color.gray);
        columna.setBounds(0,50,125,380);
        add(columna);

        JPanel fila = new JPanel();
        fila.setBackground(Color.darkGray);
        fila.setBounds(125,0,595,50);
        add(fila);

        JPanel logoB = new JPanel();
        logoB.setBackground(Color.BLACK);
        logoB.setBounds(0,0,125,50);
        add(logoB);

        gest.setBackground(Color.orange);
        gest.setBounds(0, 51, 125, 50);
        gest.setFont(new Font("Open Sans", Font.BOLD, 9));
        gest.setVisible(true);
        add(gest);

        ActionListener gestL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                vistaGestionarItems v = new vistaGestionarItems();
            }
        };
        gest.addActionListener(gestL);

        ActionListener cerrar_ses = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int answer = JOptionPane.showConfirmDialog(null, "Seguro que quieres cerrar la sesión?", "Confirmacion cerrar sesion", 1);
                if(answer == 0){
                    setVisible(false);
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                }
            }
        };
        exit.addActionListener(cerrar_ses);

        ActionListener gest_its = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaGestionaItems();
                setVisible(false);
            }
        };

        gest.addActionListener(gest_its);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    //CAMBIAR
                    vistaGestionarItems.super.dispose();

                    System.exit(0);
                }
                else if(answer == 1){
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaGestionarItems no_exit = new vistaGestionarItems();
                    setVisible(false);
                }
            }
        });
    }

    private void setButtons() {

        crearButton.setBackground(Color.gray);
        crearButton.setBounds(167,125,200,75);
        crearButton.setFont(new Font("Open Sans", Font.BOLD, 20));
        crearButton.setVisible(true);
        add(crearButton);

        editarButton.setBackground(Color.gray);
        editarButton.setBounds(467,125,200,75);
        editarButton.setFont(new Font("Open Sans", Font.BOLD, 20));
        editarButton.setVisible(true);
        add(editarButton);

        borrarButton.setBackground(Color.gray);
        borrarButton.setBounds(317,275,200,75);
        borrarButton.setFont(new Font("Open Sans", Font.BOLD, 20));
        borrarButton.setVisible(true);
        add(borrarButton);

        ActionListener crearButtonL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaCrearItem v = new vistaCrearItem();
                setVisible(false);
            }
        };
        crearButton.addActionListener(crearButtonL);

        ActionListener editarButtonL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaEditarItem v = new vistaEditarItem();
                setVisible(false);
            }
        };
        editarButton.addActionListener(editarButtonL);

        ActionListener borrarButtonL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaBorrarItem v = new vistaBorrarItem();
                setVisible(false);
            }
        };
        borrarButton.addActionListener(borrarButtonL);
    }

    @Override
    public void ejecutarVista() {
        super.ejecutarVista();
    }

    private void vistaGestionaItems(){
        vistaGestionarItems v_gesPerf = new vistaGestionarItems();
    }
}
