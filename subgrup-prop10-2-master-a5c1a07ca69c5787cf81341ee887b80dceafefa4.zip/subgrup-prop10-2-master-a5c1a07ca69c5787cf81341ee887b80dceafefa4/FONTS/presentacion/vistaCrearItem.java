package presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

public class vistaCrearItem extends Vista {

    private JLabel logo = new JLabel("RECOMENDADOR");
    private JButton gesits = new JButton("GESTIONAR ITEMS");
    private JButton exit = new JButton("CIERRA SESION");

    private JLabel idI = new JLabel("ID NEW ITEM: ");
    private JTextField idItAss = new JTextField();

    private JLabel atr = new JLabel("AÑADE ATRIBUTOS");
    private JLabel n_at = new JLabel("Nombre at.:");
    private JLabel v_at = new JLabel("Valor:");

    private JTextField nAt = new JTextField();
    private JTextField vAt = new JTextField();

    private JButton newAt = new JButton("AÑADE ATRIBUTO");
    private JButton conF = new JButton("CONFIRMA EDICIÓN");
    private JButton cancel = new JButton("CANCELAR");

    private ArrayList<String> ats = new ArrayList<>();
    private ArrayList<String> vals = new ArrayList<>();

    vistaCrearItem() {
        super();

        setLocationRelativeTo(null);
        setLayout(null);

        setResizable(false);

        setTitle("CREA ITEM");

        idI.setBounds(150,70,130,40);
        idI.setFont(new Font("Open Sans", Font.BOLD, 15));
        idI.setVisible(true);
        add(idI);

        idItAss.setBounds(260,75,412,30);
        idItAss.setFont(new Font("Open Sans", Font.PLAIN, 15));
        idItAss.setVisible(true);
        idItAss.setEditable(false);
        add(idItAss);
        idItAss.setText(String.valueOf(CtrlPresentacion.getCtrlDominio().Instance().getMaxIDItem()));
        ats.add("id");
        vals.add(idItAss.getText());

        atr.setBounds(150,125,200,40);
        atr.setFont(new Font("Open Sans", Font.BOLD, 17));
        atr.setVisible(true);
        add(atr);

        n_at.setBounds(150,160,200,40);
        n_at.setFont(new Font("Open Sans", Font.BOLD, 14));
        n_at.setVisible(true);
        add(n_at);

        nAt.setBounds(150,195,250,30);
        nAt.setFont(new Font("Open Sans", Font.PLAIN, 14));
        nAt.setVisible(true);
        add(nAt);

        v_at.setBounds(422,160,200,40);
        v_at.setFont(new Font("Open Sans", Font.BOLD, 14));
        v_at.setVisible(true);
        add(v_at);

        vAt.setBounds(422,195,250,30);
        vAt.setFont(new Font("Open Sans", Font.PLAIN, 14));
        vAt.setVisible(true);
        add(vAt);

        newAt.setBackground(Color.orange);
        newAt.setBounds(236,240,350,40);
        newAt.setFont(new Font("Open Sans", Font.BOLD, 16));
        newAt.setVisible(true);
        add(newAt);

        conF.setBackground(Color.GRAY);
        conF.setBounds(230,325,362,50);
        conF.setFont(new Font("Open Sans", Font.BOLD, 18));
        conF.setVisible(true);
        add(conF);

        cancel.setBackground(Color.RED);
        cancel.setBounds(301,390,220,40);
        cancel.setFont(new Font("Open Sans", Font.BOLD, 18));
        cancel.setVisible(true);
        add(cancel);

        super.pantallaTrabajoAdmin();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    //CAMBIAR
                    dispose();

                    System.exit(0);
                }
                else if(answer == 1){
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaCrearItem no_exit = new vistaCrearItem();
                }
            }
        });

        ActionListener  newAtList = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!nAt.getText().equals("") && !vAt.getText().equals("")){
                    if(!ats.contains(nAt.getText())) {
                        ats.add(nAt.getText());
                        vals.add(vAt.getText());

                        nAt.setText("");
                        vAt.setText("");
                    }
                    else JOptionPane.showMessageDialog(null,"Este atributo ya existe", "ERROR", 0);
                }
                else{
                    JOptionPane.showMessageDialog(null, "Indica ambos valores, por favor\n(no se permiten atributos ni valores null)","ERROR",0);
                }
            }
        };
        newAt.addActionListener(newAtList);

        ActionListener confList = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(ats.size() > 0) {
                    CtrlPresentacion.getCtrlDominio().Instance().creaItem(idItAss.getText(),ats,vals);

                    nAt.setText("");
                    vAt.setText("");

                    ats = new ArrayList<>();
                    vals = new ArrayList<>();
                    idItAss.setText(String.valueOf(CtrlPresentacion.getCtrlDominio().Instance().getMaxIDItem()));
                    ats.add("id");
                    vals.add(idItAss.getText());
                }
                else {
                    JOptionPane.showMessageDialog(null, "Añade primero algun atributo.", "ERROR", 0);
                }
            }
        };
        conF.addActionListener(confList);

        ActionListener canList = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaGestionaItems();
                setVisible(false);
            }
        };
        cancel.addActionListener(canList);

        ejecutarVista();
    }

    @Override
    public void ejecutarVista() {
        super.ejecutarVista();
    }

    private void vistaGestionaItems(){
        vistaGestionarItems v_gesPerf = new vistaGestionarItems();
    }

}

