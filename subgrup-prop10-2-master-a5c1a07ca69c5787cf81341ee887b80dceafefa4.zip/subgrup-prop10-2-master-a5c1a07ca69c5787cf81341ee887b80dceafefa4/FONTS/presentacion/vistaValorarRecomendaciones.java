package presentacion;

import javax.swing.*;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import project.CtrlDominio;
import project.Valoracion;

public class vistaValorarRecomendaciones extends Vista {

    private JLabel logo = new JLabel("RECOMENDADOR");
    private JButton exit = new JButton("CIERRA SESION");

    private JButton recs = new JButton("RECOMENDACIONES");
    private JButton hist = new JButton("HISTORIAL");
    private JButton vals = new JButton("HIST. VALORACIONES");
    private JButton buscits = new JButton("BUSCA ITEM");
    private JButton conf = new JButton("GESTIONAR PERFIL");

    public vistaValorarRecomendaciones(){
        super();

        setLocationRelativeTo(null);
        setLayout(null);

        setTitle("PAGINA PRINCIPAL ADMINISTRADOR");

        super.pantallaTrabajoUsuario();

	    recomendaciones();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    //CAMBIAR
                    dispose();

                    System.exit(0);
                }
                else if(answer == 1){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    setVisible(false);
                }
                
           
            }
        });

    }

    public void ejecutarVista(ArrayList<String> itemsRecomendados) {

        // SIEMPRE RECOMIENDA 9 o menos items

        ArrayList<JList> taula = new ArrayList<>();
        taula.add(new JList());
        taula.add(new JList());
        taula.add(new JList());
        taula.get(0).setLayout(new BoxLayout(taula.get(0), BoxLayout.Y_AXIS));
        taula.get(1).setLayout(new BoxLayout(taula.get(1), BoxLayout.Y_AXIS));
        taula.get(2).setLayout(new BoxLayout(taula.get(2), BoxLayout.Y_AXIS));

        JButton recargar = new JButton("RECARGAR RECOMENDACIONES");
        recargar.setBounds(295,10,230,30);
        recargar.setBackground(Color.orange);
        recargar.setVisible(true);

        recargar.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
			recargarVistaRecomendaciones();
			setVisible(false);
		}
	     });

        add(recargar);

        String[] posiblesRatings = {"0","1", "2", "3","4","5"};

        int offset = 180;
        int i=0;
        int j=0;
        for(String item : itemsRecomendados) {
            if(i%3==0) {
                j++;
                if(j%3==0) {
                    i=0;
                    j=0;
                }else i = 0;
            }

            JList newRow = taula.get(i);
            newRow.setLayout(new FlowLayout());
            newRow.setBounds(150 + offset*i,75 + (offset)*j,175,350);
            newRow.setVisible(true);

            JButton buttonValorar = new JButton("VALORAR");
            buttonValorar.setBounds(0,0,10,10);
            buttonValorar.setVisible(true);
            buttonValorar.setBackground(Color.orange);
            buttonValorar.setPreferredSize(new Dimension(125,25));

            JComboBox<String> ratings = new JComboBox<>(posiblesRatings);
            ratings.setSize(10,10);
            ratings.setPreferredSize(new Dimension(40,25));

            JPanel buttonXcombobox = new JPanel();
            buttonXcombobox.setBackground(Color.lightGray);
            buttonXcombobox.setLayout(new BoxLayout(buttonXcombobox, BoxLayout.X_AXIS));
            buttonXcombobox.setVisible(true);
            buttonXcombobox.setBounds(0,50,75,10);
            buttonXcombobox.add(buttonValorar);
            buttonXcombobox.add(ratings);
            
          

            JLabel itemID = new JLabel(item);
            itemID.setFont(new Font("Open Sans", Font.BOLD, 28));
            itemID.setBounds(0,0,50,50);
            itemID.setVisible(true);

            buttonValorar.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
			
			String rating = ((String)ratings.getSelectedItem());
			if(rating.equals("-")) return;
			double rating_value = Double.parseDouble(rating);
			CtrlDominio ctrl = CtrlPresentacion.getCtrlDominio().Instance();
			ctrl.addValoracion(new Valoracion(ctrl.buscar_item(itemID.getText()),rating_value,CtrlPresentacion.getCtrlDominio().Instance().getPerfil().getID()));
			CtrlPresentacion.recalcularValoracionesUsuario();
		}
	     });

            newRow.add(itemID);
            newRow.add(buttonXcombobox);

            if(item=="NULL") {
                itemID.setVisible(false);
                buttonXcombobox.setVisible(false);
            }

            JLabel space;
            for(int s = 0; s<30; s++) {
                space = new JLabel("   ");
                newRow.add(space);
            }

            i++;
        }

        for(JList fila : taula) add(fila);

	


        super.ejecutarVista();

    }

    private void recomendaciones(){
        
        ArrayList<String> itemsRecomenats = CtrlPresentacion.getRecomendaciones();
        if(itemsRecomenats.size()!=9) {
            if(itemsRecomenats.size()>9) {
                while(itemsRecomenats.size()>9) {
                    itemsRecomenats.remove(itemsRecomenats.size()-1);
                }
            }else {
                for(int i=itemsRecomenats.size(); i<9; i++) {
                    itemsRecomenats.add("NULL");
                }
            }
        }
        ejecutarVista(itemsRecomenats);
    }

    private void vistaConsultarHistorial(){
        vistaConsultarHistorial v_consHist = new vistaConsultarHistorial();
    }

    private void vistaConsultarValoraciones(){
        vistaConsultarValoraciones v_consVals = new vistaConsultarValoraciones();
    }

    private void vistaBuscarItems(){
        vistaBuscarItems v_buscItems = new vistaBuscarItems();
    }

    private void vistaGestionarPerfil(){
        vistaGestionarPerfil v_gestPerf = new vistaGestionarPerfil();
    }

}
