package presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class vistaConsultarHistorial extends Vista {

    private JLabel tuHistorialLabel = new JLabel("TU HISTORIAL:");

    public vistaConsultarHistorial(){
        super();

        setLocationRelativeTo(null);
        setLayout(null);

        setTitle("HISTORIAL ACCIONES");

        setResizable(false);

        CtrlPresentacion.addHistorial("Has consultado el historial.");

        tuHistorialLabel.setBounds(150, 75 + 25, 200, 10);
        tuHistorialLabel.setHorizontalAlignment(SwingConstants.LEFT);
        tuHistorialLabel.setVerticalAlignment(SwingConstants.CENTER);
        add(tuHistorialLabel);

        super.pantallaTrabajoUsuario();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();

                    }
                    //CAMBIAR
                    dispose();

                    System.exit(0);
                }
                else if(answer == 1){
                    int answer2 = JOptionPane.showConfirmDialog(null, "Quieres guardar los datos de la sesión?", "Guardar cambios", JOptionPane.YES_NO_OPTION, 1);
                    if(answer2 == 0){
                        CtrlPresentacion.Guardar();
                    }
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaConsultarHistorial no_exit = new vistaConsultarHistorial();
                }
            }
        });
 
        ejecutarVista(CtrlPresentacion.getHistorial());

    }

    public void ejecutarVista(ArrayList<String> historialUsuario) {

        JPanel listHistorias = new JPanel();
        listHistorias.setLayout(new BoxLayout(listHistorias, BoxLayout.Y_AXIS));
        int startX = 160, startY = 150;

        int i = 1;
        for(String historia : historialUsuario) {
            JLabel h = new JLabel();
            h.setText("· " + historia);
            listHistorias.add(h);
            i++;
        }

        JScrollPane jScrollPane = new JScrollPane(listHistorias);
        jScrollPane.setBounds(150,140, 500, 260);
        add(jScrollPane);

        super.ejecutarVista();
    }
}
