package presentacion;

import persistencia.CtrlPersistencia;
import project.*;

import javax.swing.*;
import java.util.ArrayList;

public class CtrlPresentacion {

    private static CtrlDominio ctrlDominio;
    private static CollaborativeFiltering collaborativeFiltering;

    private static ArrayList<String> historial;

    public static ArrayList<String> getRecomendaciones() {
    
    	ArrayList<Item> recomendaciones = collaborativeFiltering.RecomendarItem(ctrlDominio.Instance().getPerfil().getID(),10);
    	ArrayList<String> idsRecomendaciones = new ArrayList<String>();
    	for(Item recomendado : recomendaciones) {
    		idsRecomendaciones.add(recomendado.getID());
    	}
    	return idsRecomendaciones;
    
    }

    public static void addHistorial(String accion){
        historial.add(accion);
    }

    public static Perfil getPerfil() {
        return ctrlDominio.Instance().getPerfil();
    }

    public static ArrayList<String> getHistorial(){
        return historial;
    }

    public static CtrlDominio getCtrlDominio() {
        return ctrlDominio;
    }

    public CtrlPresentacion(){
        ctrlDominio = new CtrlDominio();
        historial = new ArrayList<>();
        collaborativeFiltering = new CollaborativeFiltering();
        UIManager.put("OptionPane.yesButtonText","Si");
        UIManager.put("OptionPane.cancelButtonText","Cancelar");
        vistaInicioSesion();
    }

    private static void vistaInicioSesion(){
        vistaInicioSesion v_inicSes = new vistaInicioSesion();
    }


    public static void cargar_datos_usuario() {
        // CARGAR ITEMS

        try {
            for (String itemCSV : CtrlPersistencia.Instance().getCSVs("item")) {
                CtrlPresentacion.getCtrlDominio().Instance().guardarItems(CtrlPersistencia.Instance().importarItems(itemCSV));
                CtrlPersistencia.Instance().eliminarFichero(itemCSV);   // se elimina el fichero y se creara otra vez cuando se guarden los nuevos items
            }

            // CARGAR VALORACIONES
            CtrlPresentacion.getCtrlDominio().Instance().guardarValoraciones(CtrlPersistencia.Instance().importarValoraciones("ratings.db.csv"));

            // CARGAR VALORACIONES DEL USUARIO ACTIVO
            ArrayList<Valoracion> valoracionesReaded = CtrlPresentacion.getCtrlDominio().Instance().getValoraciones(CtrlPresentacion.getCtrlDominio().Instance().getPerfil().getID());
            for (Valoracion val : valoracionesReaded) {
                ((UsuarioActivo) CtrlPresentacion.getCtrlDominio().Instance().getPerfil()).addValoracion(val);
            }

            // CARGAR DATOS DEL COLLABORATIVE FILTERING Y PRECALCULO DE CLUSTERS DEL KMEANS
            collaborativeFiltering.CargarValoraciones("ratings.db.csv");
            collaborativeFiltering.InicializarDatosKMeans();

            CtrlPersistencia.Instance().eliminarFichero("ratings.db.csv");   // se elimina el fichero y se creara otra vez cuando se guarden las nuevas valoraciones
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos en la pantalla de carga del usuairo [" + exception + "]");
        }

    }
    
    public static void recalcularValoracionesUsuario() {
    
    	collaborativeFiltering.RecalcularPosicion(ctrlDominio.Instance().getPerfil().getID());
    
    }

    public static void cargar_datos_administrador() {
        try {
            // CARGAR ITEMS
            for(String itemCSV : CtrlPersistencia.Instance().getCSVs("item")) {
                CtrlDominio.Instance().guardarItems(CtrlPersistencia.Instance().importarItems(itemCSV));
                CtrlPersistencia.Instance().eliminarFichero(itemCSV);
            }

            // Se cargan los datos de testeo para la evaluacion de los algoritmos
            Algoritmos.cargarDatos();
        } catch (Exception exception) {
        }

    }
    
    public static void Guardar() {
    
	ctrlDominio.Instance().Guardar();
	collaborativeFiltering.GuardarDatosCalculados();
    
    }
    
    public static void eliminarUsuario(String userID) {
    
    	ctrlDominio.Instance().eliminarUsuario(userID);
    
    }


}
