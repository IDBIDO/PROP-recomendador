package presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class vistaPrincipalAdmin extends Vista {

    private JLabel WELCOME = new JLabel("BIENVENIDO ADMINISTRADOR");

    public vistaPrincipalAdmin(){

        setLocationRelativeTo(null);
        setLayout(null);

        setResizable(false);

        setTitle("PAGINA PRINCIPAL ADMINISTRADOR");

        WELCOME.setForeground(Color.BLACK);
        WELCOME.setBounds(125,190,595,100);
        WELCOME.setHorizontalAlignment(SwingConstants.CENTER);
        WELCOME.setVerticalAlignment(SwingConstants.CENTER);
        WELCOME.setFont(new Font("Open Sans", Font.BOLD, 30));
        add(WELCOME);

        pantallaTrabajoAdmin();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String [] opciones = new String[3];
                opciones[0] = "Salir";
                opciones[1] = "Cerrar Sesión";
                opciones[2] = "Cancelar";

                int answer = JOptionPane.showOptionDialog(null, "Que quieres hacer?", "Salir", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, opciones, opciones[0]);
                if(answer == 0){
                    //CAMBIAR
                    dispose();

                    System.exit(0);
                }
                else if(answer == 1){
                    vistaInicioSesion cerrarS = new vistaInicioSesion();
                    setVisible(false);
                }
                else {
                    //CAMBIAR
                    vistaPrincipalAdmin no_exit = new vistaPrincipalAdmin();
                }
            }
        });

        ejecutarVista();
    }

    @Override
    public void ejecutarVista() {
        super.ejecutarVista();
    }
}
