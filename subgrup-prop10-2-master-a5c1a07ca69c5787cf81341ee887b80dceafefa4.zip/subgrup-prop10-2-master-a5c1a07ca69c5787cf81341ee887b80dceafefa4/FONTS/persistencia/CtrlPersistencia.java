package persistencia;

import project.CtrlDominio;
import project.Item;
import project.Valoracion;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static java.nio.file.StandardCopyOption.*;


public class CtrlPersistencia {

    private Importador importador;
    private Exportador exportador;

    private static String directoryPath;
    private static String cdSepar;
    private static Path dataPath;

    private static CtrlPersistencia instancia = null;

    public CtrlPersistencia() {

        this.importador = new Importador();
        this.exportador = new Exportador();

        this.cdSepar = System.getProperty("file.separator");
        String current;

        try{
            current = new java.io.File(".").getCanonicalPath();
            this.directoryPath = current + cdSepar;
            this.dataPath = Paths.get(directoryPath);
        }
        catch (Exception e){
            System.out.println("Error al coger datos del SO para configurar el directorio de trabajo para los ficheros.");
        }

    }

    public boolean existFiles(String nameFile) {

        ArrayList<String> files = Instance().getCSVs(nameFile);
        return files.size() > 0;

    }

    public static void resetInstance() {
        instancia = new CtrlPersistencia();
    }

    public static CtrlPersistencia Instance() {
        if(instancia == null){
            instancia = new CtrlPersistencia();
        }
        return instancia;
    }

    public static void guardarUsuarioRegistrado(String usrename, String password) {

        String newID;
        newID = Instance().importador.getNewID();

        ArrayList<String> data = new ArrayList<>();
        data.add(newID);
        data.add(usrename);
        data.add(password);

        Instance().exportador.appendFile("users.csv",data);

    }

    public String getID(String username) {

        String userID;
        try {
            userID = Instance().importador.getIDbyNickname(username);
        } catch (IOException ioe) {
            System.out.println("No se ha podido leer el fichero users.csv para encontrar el usuario " + username);
            return "";
        }
        return userID;

    }

    public ArrayList<Valoracion> importarValoraciones(String nombreFichero) {

        ArrayList<ArrayList<String>> datos = new ArrayList<>();
        ArrayList<Valoracion> valoraciones = new ArrayList<>();
        datos = this.Instance().importador.importarFichero(nombreFichero);
        if(datos==null) return new ArrayList<>();
        // Convertir los datos en valoraciones

        // Detectar formato de las valoraciones
        int user = 0, rating = 1, item = 2;
        ArrayList<String> header = new ArrayList<>();
        try {
            header = datos.get(0);
        }catch(IndexOutOfBoundsException ioobe) {
            System.out.println("El fichero " + nombreFichero + "no contiene datos o no se ha abierto correctamente, no se ha podido leer la cabecera.");
            return null;
        }

        // se detecta el orden del formato de los datos a leer
        for(int i=0; i<header.size(); i++) {
            if(header.get(i).contains("user")) user = i;
            else if(header.get(i).contains("item")) item = i;
            else rating = i;
        }

        // se leen todos las valoraciones del fichero
        for(int i=1; i<datos.size(); i++) {
            ArrayList<String> dato = datos.get(i);
            Item itemCargado = CtrlDominio.Instance().getItembyID(dato.get(item));
            if(itemCargado==null) {
                // el item con la ID de la valoracion a cargar no existe en los items importados del sistema
                Item nuevoItem = new Item(dato.get(item), new ArrayList<>(), new ArrayList<>());
                valoraciones.add(new Valoracion(nuevoItem, Double.parseDouble(dato.get(rating)), dato.get(user)));
            }
            else valoraciones.add(new Valoracion(itemCargado, Double.parseDouble(dato.get(rating)), dato.get(user)));
        }
        
        CtrlPersistencia.Instance().eliminarFichero(nombreFichero);   // se copia el fichero en backup y se guardara actualizado en /FONTS

        return valoraciones;

    }
    
    public void actualizarUsuario(String id, String user_name, String password) {
    	Instance().getExportador().actualizarUsuario(id,user_name,password);
    }

    public ArrayList<Item> importarItems(String nombreFichero) {

        ArrayList<ArrayList<String>> datos = new ArrayList<>();
        ArrayList<Item> items = new ArrayList<>();
        datos = this.Instance().importador.importarFichero(nombreFichero);

        ArrayList<String> header = new ArrayList<>();
        try {
            header = datos.get(0);
        }catch(IndexOutOfBoundsException ioobe) {
            System.out.println("El fichero " + nombreFichero + "no contiene datos o no se ha abierto correctamente, no se ha podido leer la cabecera.");
            return null;
        }
        int idIndex = 0;
        for(String s : header) {
            if(s.equals("id")) break;
            idIndex++;
        }
        if(idIndex >= header.size()) {
            System.out.println("No s'han pogut cargar els items del fitxer " + nombreFichero + " ja que falta l'atribut del identificador del item.");
            return new ArrayList<>();
        }

        for(int i=1; i<datos.size(); i++) {
            ArrayList<String> dato = datos.get(i);
            items.add(new Item(dato.get(idIndex), dato, header));
        }
        
        CtrlPersistencia.Instance().eliminarFichero(nombreFichero);   // se copia el fichero en backup y se guardara actualizado en /FONTS

        return items;

    }

    public Importador getImportador() { return this.Instance().importador; }

    public String getDirectoryPath() { return this.Instance().directoryPath; }

    public ArrayList<String> getCSVs(String name) {
        ArrayList<String> result = new ArrayList<>();
        List<String> csvs = new ArrayList<>();
        try (Stream<Path> walk = Files.walk(Paths.get(""))) {
            csvs = walk.filter(Files::isRegularFile)
                    .map(x -> x.toString()).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
            return result;
        }
        for(String csv : csvs) {
            if(!csv.contains("/") && csv.contains(name) && !csv.contains("lock")) result.add(csv);
        }
        System.out.println(result);
        return result;
    }

    public void guardarItems(ArrayList<Item> items) {

        // GUARDA TODOS LOS ITEMS EN SU RESPECTIVO FICHERO

        // Dado un item con tipo item "TIPO ITEM N", su respectivo fichero es: itemsTIPOITEMN.csv

        Map<String,ArrayList<ArrayList<String>>> data = new HashMap<>();
        for(Item item : items) {
            ArrayList<String> itemData = new ArrayList<>();
            String currentNameFile = "items" + item.getTipoItem().getNombre_tipo().replace(" ", "") + ".csv";   // nombre del respectivo fichero
            if(!data.keySet().contains(item.getTipoItem().getNombre_tipo())) {
                // Genera un nuevo fichero con la cabecera de este tipo de item
                // Si no existe el fichero lo crea vacio, si ya existe lo limpia y lo deja vacio

                Instance().exportador.cleanFile(currentNameFile);
                ArrayList<String> header = new ArrayList<>();
                for(String atr : item.getCabeceras_atributos()) header.add(atr);
                Instance().exportador.appendFile(currentNameFile, header);
                data.put(item.getTipoItem().getNombre_tipo(), new ArrayList<>());
            }
            // Coge los datos del item para guardarlos
            for(String atr : item.getValors_atributs()) itemData.add(atr);
            data.get(item.getTipoItem().getNombre_tipo()).add(itemData);
        }

        // Guarda los items en su respectivo fichero
        for(String key : data.keySet()) {
            Instance().exportador.fillFile("items"+key.replace(" ","")+".csv", data.get(key));
        }


    }

    public Exportador getExportador() { return Instance().exportador; }

    public void guardarValoraciones(ArrayList<Valoracion> valoraciones) {

        if(valoraciones==null || valoraciones.size()==0) return;

        Instance().exportador.cleanFile("ratings.db.csv");

        // GUARDA TODAS LAS VALORACIONES EN SU RESPECTIVO FICHERO

        ArrayList<ArrayList<String>> data = new ArrayList<>();
        ArrayList<String> header = new ArrayList<>();
        header.add("userID");
        header.add("itemID");
        header.add("rating");
        data.add(header);

        for(Valoracion valoracion : valoraciones) {
            ArrayList<String> newRow = new ArrayList<>();
            newRow.add(valoracion.getUser());
            newRow.add(valoracion.get_Item().getID());
            newRow.add(String.valueOf(valoracion.getValor()));
            data.add(newRow);
        }

        // Guarda las valoraciones en el fichero 'ratings.db.csv'
        Instance().exportador.fillFile("ratings.db.csv", data);

    }

    public void eliminarFichero(String nameFile) {
    	System.out.println("Haciendo BACKUP del fichero " + nameFile);
        File ficheroAborrar = new File(nameFile);
        try {
            Path source = Paths.get(dataPath + Instance().cdSepar + nameFile);
            Path target = Paths.get(dataPath + Instance().cdSepar + "/backup/"+nameFile);
            Files.copy(source,target,REPLACE_EXISTING);
            System.out.println("Se ha guardado el fichero " + nameFile + " en la carpeta .root/FONTS/backup...");
        } catch (Exception e) {
            System.out.println("No se ha podido mover a backup correctamente el fichero " + nameFile + ", no se mueve y se queda en el directorio .root/FONTS...");
        }
    }
    
    public void eliminarUsuario(String userID) {
    
    	Instance().getExportador().eliminarUsuario(userID,"users.csv");
    	
    }

}
