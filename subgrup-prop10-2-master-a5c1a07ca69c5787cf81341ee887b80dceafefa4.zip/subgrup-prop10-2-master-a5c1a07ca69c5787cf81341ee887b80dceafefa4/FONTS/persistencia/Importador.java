package persistencia;

import com.opencsv.CSVParser;
import com.opencsv.CSVReader;

import project.CtrlDominio;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;


public class Importador {

    public Importador(){ }

    public ArrayList<ArrayList<String>> importarFichero(String nombreFichero) {

        System.out.println("Importando " + nombreFichero + "...");

        CSVReader reader;
        try {
            reader = new CSVReader(new FileReader(nombreFichero));
        } catch (FileNotFoundException fnfe) {
            System.out.println("El fichero '" + nombreFichero + "' no se ha encontrado en el directorio '" + CtrlPersistencia.Instance().getDirectoryPath() + "' o el nombre del fichero no tiene la extension adecuada.");
            return null;
        }

        String[] nextLine;
        ArrayList<ArrayList<String>> datos = new ArrayList<>();
        ArrayList<String> line = new ArrayList<>();

        // Se lee una linea de los datos del .csv
        try {
            while ((nextLine = reader.readNext()) != null) {
                line = new ArrayList<>();
                for(int i=0; i<nextLine.length; i++) {
                    nextLine[i] = nextLine[i].replace(",","").replace('"',' ');
                }
                Collections.addAll(line, nextLine);
                datos.add(line);
            }
        } catch (IOException ioe) {
            System.out.println("Error al leer los datos del fichero " + nombreFichero + " al querer importarlos.");
            return new ArrayList<>();
        }
        System.out.println("Importado correctamente > " + nombreFichero);
        return datos;

    }

    public String getIDbyNickname(String nickname) throws IOException {

        CSVReader reader;
        try {
            reader = new CSVReader(new FileReader("users.csv"));
        } catch (FileNotFoundException fnfe) {
            System.out.println("El fichero 'users.csv' no se ha encontrado en el directorio '" + CtrlPersistencia.Instance().getDirectoryPath() + "' o el nombre del fichero no tiene la extension adecuada.");
            return "";
        }
        //reads one line at a time
        String[] nextLine;
        try {
            nextLine = reader.readNext();

            while ((nextLine = reader.readNext()) != null) {
                if (nextLine[1].equals(nickname)) {
                    return nextLine[0];
                }
            }
        } catch (IOException ioe) {
            System.out.println("No se ha podido leer correctamente el fichero users.csv del directorio " + CtrlPersistencia.Instance().getDirectoryPath() + "FONTS/users.csv");
            return null;
        }

        return null;
    }

    public boolean correct_user_pass(String nick, String passw) {

        CSVReader reader;
        try
        {
            //parsing a CSV file into CSVReader class constructor
            CSVParser parser = new CSVParser(CSVParser.DEFAULT_SEPARATOR, CSVParser.DEFAULT_QUOTE_CHARACTER, '\0', CSVParser.DEFAULT_STRICT_QUOTES);
            try {
                reader = new CSVReader(new FileReader("users.csv"));
            } catch (FileNotFoundException fnfe) {
                System.out.println("El fichero '" + "users.csv" + "' no se ha encontrado en el directorio '" + CtrlPersistencia.Instance().getDirectoryPath() + "' o el nombre del fichero no tiene la extension adecuada.");
                return false;
            }
            //reads one line at a time
            String[] nextLine;
            String id, nickname, pass;

            while ((nextLine = reader.readNext()) != null)
            {
                if(nextLine[1].equals(nick)) {
                    if(nextLine[2].equals(passw)){
                        System.out.println("Bienvenido "+nick+", has iniciado sesion correctamente.");
                        return true;
                    }
                }
            }
            return false;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }

    public boolean existe_username(String nick) {
        CSVReader reader;
        try
        {
            //parsing a CSV file into CSVReader class constructor
            try {
                reader = new CSVReader(new FileReader("users.csv"));
            } catch (FileNotFoundException fnfe) {
                System.out.println("El fichero '" + "users.csv" + "' no se ha encontrado en el directorio '" + CtrlPersistencia.Instance().getDirectoryPath() + "' o el nombre del fichero no tiene la extension adecuada.");
                return false;
            }
            //reads one line at a time
            String[] nextLine;
            String nickname;

            while ((nextLine = reader.readNext()) != null)
            {
                if(nextLine[1].equals(nick)) {
                    return true;
                }
            }
            return false;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }

    public String getNewID() {

        CSVReader reader;
        String[] nextLine;
        try {
            reader = new CSVReader(new FileReader("ratings.db.csv"));
        } catch (IOException ioe) {
            System.out.println("No se ha encontrado el fichero ratings.db.csv en el directorio " + CtrlPersistencia.Instance().getDirectoryPath() + "ratings.db.csv");
            return "";
        }
        int i=1;
        try {
            nextLine = reader.readNext();
            while ((nextLine = reader.readNext()) != null) {
                if (Integer.parseInt(nextLine[CtrlDominio.Instance().indexUser]) >= i)
                    i = Integer.parseInt(nextLine[CtrlDominio.Instance().indexUser]) + 1;
            }

            reader = new CSVReader(new FileReader("users.csv"));
            nextLine=reader.readNext();
            while ((nextLine = reader.readNext()) != null)
            {
                if(Integer.parseInt(nextLine[0])>=i) i=Integer.parseInt(nextLine[0]) + 1;
            }

        } catch (IOException ioe) {
            System.out.println("No se ha leido bien el fichero ratings.db.csv del directorio " + CtrlPersistencia.Instance().getDirectoryPath() + "ratings.db.csv");
            return "";
        }

        return String.valueOf(i);
    }

}

