package persistencia;

import com.opencsv.CSVWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Exportador {

    // añade un elemento al final de un fichero
    public void appendFile(String nameFile, ArrayList<String> data) {

        FileWriter csvWriter;
        try {
            csvWriter = new FileWriter(nameFile, true);
        } catch (IOException ioe) {
            System.out.println("Error al abrir el fichero " + nameFile + ".");
            return;
        }

        try{
            for (int i=0; i<data.size(); i++) {
                csvWriter.append(data.get(i));
                if(i!=data.size()-1) csvWriter.append(',');
                else csvWriter.append('\n');
            }
        } catch (IOException ioe) {
            System.out.println("Error al escibir en el fichero " + nameFile + ".");
            return;
        }

        try {
            csvWriter.flush();
            csvWriter.close();
        } catch (IOException ioe) {
            System.out.println("Error al abrir el fichero " + nameFile + ".");
            return;
        }
    }

    public void cleanFile(String nameFile) {

        FileWriter csvWriter;
        try {
            csvWriter = new FileWriter(nameFile, false);
            csvWriter.append("");
            System.out.println("Se ha limpiado el fichero " + nameFile + " correctamente.");
        } catch (IOException ioe) {
            System.out.println("No se ha encontrado el fichero " + nameFile + " para limpiarlo.");
            this.createFile(nameFile,new ArrayList<>());
            System.out.println("Se ha creado el fichero " + nameFile + ", totalmente vacio.");
        }

    }

    public void fillFile(String nameFile, ArrayList<ArrayList<String>> data) {

        FileWriter csvWriter;
        try {
            csvWriter = new FileWriter(nameFile, true);

        } catch (IOException ioe) {
            System.out.println("Error al abrir el fichero " + nameFile + ".");
            return;
        }

        try {
            for (int i = 0; i < data.size(); i++) {
                for(int j=0; j<data.get(i).size(); j++) {
                    csvWriter.append(data.get(i).get(j).toString());
                    if (j < data.get(i).size() - 1) csvWriter.append(',');
                    else csvWriter.append('\n');
                }
            }
        } catch (IOException ioe) {
            System.out.println("Error al escibir en el fichero " + nameFile + ".");
            return;
        }

        try {
            csvWriter.flush();
            csvWriter.close();
        } catch (IOException ioe) {
            System.out.println("Error al cerrar el fichero " + nameFile + ".");
            return;
        }
    }
    
    public void actualizarUsuario(String id, String user_name, String password) {
    	
    	try {
	    	ArrayList<ArrayList<String>> data = CtrlPersistencia.Instance().getImportador().importarFichero("users.csv");
	    	for(ArrayList<String> row : data) {
	    		if(row.contains(id)) {
	    			row.set(1,user_name);
	    			row.set(2,password);
	    			break;
	    		}
	    	}
	    	cleanFile("users.csv");
	    	fillFile("users.csv",data);
    	} catch(Exception e) {
    		System.out.println("No se ha podido actualizar el fichero users.csv con los datos del nuevo usuario...");
    		return;
    	}
    }

    public void createFile(String nameFile, ArrayList<String> header) {

        CSVWriter csvWriter;
        try {
            csvWriter = new CSVWriter(new FileWriter(nameFile));
        } catch (IOException ioe) {
            System.out.println("Error al crear el fichero " + nameFile + ".");
            return;
        }

        appendFile(nameFile, header);

    }
    
    public void eliminarUsuario(String userID, String nombreFichero) {
    
    	ArrayList<ArrayList<String>> data = CtrlPersistencia.Instance().getImportador().importarFichero(nombreFichero);
    	ArrayList<ArrayList<String>> newData = new ArrayList<>();
    	
    	for(ArrayList<String> row : data) {
    		if(row.contains(userID)) continue;
    		else newData.add(row);
    	}
    	
    	cleanFile(nombreFichero);
    	fillFile(nombreFichero,newData);
    	
    
    }

}
