package project;

public class Perfil {

    private String password;
    private String Nickname;
    private String id_Usuario;

    CtrlDominio ctrl;

    //Constructor por defecto
    public Perfil(){

    }

    //Constructor completo
    public Perfil(String Nick, String id, String password, CtrlDominio ctrldom) {
        this.Nickname = Nick;
        this.id_Usuario = id;
        this.password = password;
        this.ctrl = ctrldom;
    }

    //GETTERS
    public String getNickname(){
        return Nickname;
    }

    public String getID() {return this.id_Usuario; }

    public String getPassword(){
        return password;
    }

    //SETTERS
    public void setNickname(String Nick){
        this.Nickname = Nick;
    }

    public void setID(String id) { this.id_Usuario = id; }

    public void setPassword(String pass){ this.password = pass; }

}
