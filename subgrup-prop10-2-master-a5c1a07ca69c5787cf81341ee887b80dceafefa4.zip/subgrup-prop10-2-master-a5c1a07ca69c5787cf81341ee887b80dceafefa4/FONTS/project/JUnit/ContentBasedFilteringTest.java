package project.JUnit;

import org.junit.*;
import project.ContentBasedFiltering;
import project.Item;
import project.Pair;

import org.junit.jupiter.api.BeforeAll;

import java.io.IOException;
import java.util.ArrayList;

import static org.mockito.Mockito.*;


public class ContentBasedFilteringTest {




    @BeforeAll
    public static void init() {
        System.out.println("Inicializado Content\n");

    }


    @Test
    void repetido() throws IOException {

        ContentBasedFiltering x = new ContentBasedFiltering();
        Item mokedItem = mock(Item.class);
        Item mokedItem2 = mock(Item.class);
        Item mokedItem3 = mock(Item.class);
        Item mokedItem4 = mock(Item.class);


        when(mokedItem.getID()).thenReturn("hola");

        //Declaracion de datos de prueba
        Pair<Item> p = new Pair<Item>(mokedItem,0.);
        Pair<Item> p2 = new Pair<Item>(mokedItem2,0.);
        Pair<Item> p3 = new Pair<Item>(mokedItem3,0.);
        Pair<Item> p4 = new Pair<Item>(mokedItem4,0.);

        ArrayList< Pair<Item> > l = new ArrayList<>(4);
        l.add(0, p);
        l.add(1, p2);
        l.add(2, p3);
        l.add(3, p4);

        //miramos que llama si  (mod[i].get_first().getID() == x) retorna true:
        String id = "hola";
        //assertEquals(true, x.repetido(l,id,4));

        //se invoca 1 vez el Item mokedItem(el primero) y 0 veces los otros
        verify(mokedItem, times(1)).getID();
        verify(mokedItem2, times(0)).getID();
        verify(mokedItem3, times(0)).getID();
        verify(mokedItem4, times(0)).getID();

        //miramos que efectivamente hace j comprovaciones si no encuentra repetido:
        String diferente = "cosa";
        x.repetido(l,diferente,4);
        verify(mokedItem, times(2)).getID();        //mokedItem se ya se ha invocado 1 vez en la llamada anteriol
        verify(mokedItem2, times(1)).getID();
        verify(mokedItem3, times(1)).getID();
        verify(mokedItem4, times(1)).getID();
    }


    @Test
    void valor_min() throws IOException {
        //FUNCION: dado tres arrays de pair<Item> a, b, c. Donde a, b estan ordenamos ascendentemente.
        // Coge los elementos mas pequen.os, no repetidos,  de a, b y lo escribe en c.
        //Si en algun caso el elemento candidato esta repetido se rechaza.


        System.out.println("valor_min:");

        //Declaracion de datos de prueba:
        Pair<Item> p1 = mock(Pair.class);
        Pair<Item> p2 = mock(Pair.class);
        Pair<Item> p3 = mock(Pair.class);
        Pair<Item> p4 = mock(Pair.class);
        Pair<Item> p5 = mock(Pair.class);
        Pair<Item> p6 = mock(Pair.class);
        Pair<Item> p7 = mock(Pair.class);
        Pair<Item> p8 = mock(Pair.class);

        ArrayList< Pair<Item> > min = new ArrayList<>(4);
        min.add(0, p1);
        min.add(1, p2);
        min.add(2, p3);
        min.add(3, p4);

        ArrayList< Pair<Item> > nuevo = new ArrayList<>(4);
        nuevo.add(0, p5);
        nuevo.add(1, p6);
        nuevo.add(2, p7);
        nuevo.add(3, p8);

        ArrayList< Pair<Item> > mod = new ArrayList<>(4);
        mod.add(0, p5);
        mod.add(1, p6);
        mod.add(2, p7);
        mod.add(3, p8);

        ContentBasedFiltering x = new ContentBasedFiltering();
        ContentBasedFiltering sping = spy(x);
        doReturn(false).when(sping).repetido(anyObject(),anyString(), anyInt());

        Item mokedItem = mock(Item.class);
        Item mokedItem1 = mock(Item.class);
        ArrayList< Pair<Item> > r = new ArrayList<>(4);
        r.add(new Pair<Item>(mokedItem,0.0));
        r.add(new Pair<Item>(mokedItem,0.0));
        r.add( new Pair<Item>(mokedItem,0.0));
        r.add(new Pair<Item>(mokedItem,0.0));

        //CASO 1: Todos Los minimos estan en un array (solo se accede al primer if)
        //min: p1 p2 p3 p4 ;    nuevo: p5 p6 p7 p8
        //  p1 <= p2 <= p3 <= p4 < p5 < p6 < p7 < p8        caso repetido == false
        // mod: p1 p2 p3 p4
        for (int i = 0; i < 4; ++i) {
            //stubs para funcion falsa
            when(nuevo.get(i).get_second()).thenReturn(3.0);
            when(min.get(i).get_second()).thenReturn(0.0);
            when(min.get(i).get_first()).thenReturn(mokedItem);
            when(nuevo.get(i).get_first()).thenReturn(mokedItem1);
        }

        sping.valor_min(nuevo, min, mod);       //llamada a la funcion "falsa"
        //para facilitar la comprobacion comparo el segundo valor(distancia)
        System.out.println("CASO 1: ");
        for (int j = 0; j < 4; ++j) {
            System.out.println(mod.get(j).get_second());
            //assertEquals(r.get(j).get_second(), mod.get(j).get_second());

        }

        //Caso combinado: se accede a los dos if, repetido = false;
        //  p1 <= p5 <= p6 < p2 <= p3 ....
        //mod: p1 p5 p6 p2
        when (min.get(0).get_second()).thenReturn(0.0); //p1 el mas pequeno
        when (nuevo.get(0).get_second()).thenReturn(1.0);
        when (nuevo.get(1).get_second()).thenReturn(2.0);
        when (min.get(1).get_second()).thenReturn(4.0);
        for (int i = 2; i < 4; ++i) {
            when (min.get(i).get_second()).thenReturn(5.0);
            when (nuevo.get(i).get_second()).thenReturn(5.0);
        }
        r.set(0, new Pair<Item>(mokedItem,0.0));
        r.set(0, new Pair<Item>(mokedItem,1.0));
        r.set(0, new Pair<Item>(mokedItem,2.0));
        r.set(0, new Pair<Item>(mokedItem,4.0));

        sping.valor_min(min, nuevo, mod);
        System.out.println("CASO 2: ");
        for (int j = 0; j < 4; ++j) {
            //assertEquals(r[j].get_second(), mod.get(j).get_second());
            System.out.println(mod.get(j).get_second());
        }


        //Miramos que si tot repetido == true, no asigna valor a mod:
        //mod: - - - - (vacio)
        doReturn(true).when(sping).repetido(anyObject(),anyString(), anyInt());

        ArrayList < Pair<Item> > vacio = new ArrayList<>(4);
        mod = vacio;        //asignamos mod a un array vacio
        sping.valor_min(min, nuevo, mod);


        boolean empty = true;
        for (int i=0; i<mod.size(); i++) {
            if (mod.get(i) != null) {
                empty = false;
                break;
            }
        }
        System.out.println("CASO 3:");
        if (empty) System.out.println("mod esta vacio");

    }



}
