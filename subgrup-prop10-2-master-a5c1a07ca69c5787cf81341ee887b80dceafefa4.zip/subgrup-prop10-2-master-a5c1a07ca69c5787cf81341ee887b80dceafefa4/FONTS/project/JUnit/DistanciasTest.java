package FONTSproject.Driver;

import org.junit.jupiter.api.*;
import project.Distancias;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

class DistanciasTest {



    @Test
    //formato de lectura: [n] [a1] [b1] [a2] [b2] ... [an] [bn] [solucion]
    void distanciaEucladianaTest() throws FileNotFoundException {
        ArrayList<Double> a = new ArrayList<>();
        ArrayList<Double> b = new ArrayList<>();

        File f = new File("../EXE/DriverDistancias/SampleDistancias.txt");
        Scanner sc = new Scanner(f);
        int n = 0;

        while(sc.hasNextInt()) {
            n = sc.nextInt();
            for (int i = 0; i < n; ++i) {
                Double x = sc.nextDouble();
                Double y = sc.nextDouble();
                a.add(x);
                b.add(y);

            }
            Double r = sc.nextDouble();

            Assertions.assertEquals(r, Distancias.distanciaEucladiana(a, b), 0.001);

        }


    }


    @Test
        //formato de lectura: [n] [a1] [b1] [a2] [b2] ... [an] [bn] [solucion esperado]
    void distancia_dos_items() throws FileNotFoundException {
        ArrayList<String> a = new ArrayList<>();
        ArrayList<String> b = new ArrayList<>();
        File f = new File("../EXE/DriverDistancias/SampleAtributos.txt");
        Scanner sc = new Scanner(f);

        int n = 0;
        while(sc.hasNextInt()) {
            n = sc.nextInt();
            for (int i = 0; i < n; ++i) {
                String x = sc.next();
                a.add(x);
            }
            for (int j = 0; j < n; ++j) {
                String y = sc.next();
                b.add(y);
            }

            Double r = sc.nextDouble();
            if (r == -1) r = Double.MAX_VALUE;
            System.out.println(a);
            System.out.println(b);
            //assertEquals(r, Distancias.distancia_dos_items(a, b), 0.001);
        }

    }

    @Test
        //formato de lectura: [n] [a1] [b1] [a2] [b2] ... [an] [bn]
    void sumarVectores() throws FileNotFoundException {
        ArrayList<Double> a = new ArrayList<>();
        ArrayList<Double> b = new ArrayList<>();

        ArrayList<Double> r = new ArrayList<>();
        File f = new File("../EXE/DriverDistancias/SampleSumaVectores.txt");
        Scanner sc = new Scanner(f);
        int n = 0;
        double sum = 0;
        while(sc.hasNextInt()) {
            n = sc.nextInt();
            for (int i = 0; i < n; ++i) {
                Double x = sc.nextDouble();
                Double y = sc.nextDouble();
                a.add(x);
                b.add(y);
                sum = x+y;
                r.add(sum);
            }


            //assertEquals(r, Distancias.sumarVectores(a, b));

        }
    }



    @Test
        //formato de lectura: [n] [a1] [b1] [a2] [b2] ... [an] [bn]
    void escalarVector() throws FileNotFoundException {
        ArrayList<Double> a = new ArrayList<>();
        ArrayList<Double> r = new ArrayList<>();
        File f = new File("../EXE/DriverDistancias/SampleDistancias.txt");
        Scanner sc = new Scanner(f);
        double escalar = 0.0;

        while(sc.hasNextLine()) {
            escalar = sc.nextDouble();
            while(sc.hasNextDouble()) {
                Double x = sc.nextDouble();
                a.add(x);
                r.add(x*escalar);
            }
            //assertEquals(r, Distancias.escalarVector(a, escalar));

        }
    }


}
