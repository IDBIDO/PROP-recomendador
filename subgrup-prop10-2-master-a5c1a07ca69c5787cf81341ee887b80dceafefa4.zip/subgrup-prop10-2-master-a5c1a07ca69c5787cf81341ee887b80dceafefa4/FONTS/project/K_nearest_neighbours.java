package project;

import java.util.ArrayList;
import java.util.Arrays;

public class K_nearest_neighbours {

    public static ArrayList< Pair<Item> > k_nearest_neighbours (Item ob, ArrayList<Item> candidato, int k) {

        //dis tiene todos las distancias de id_ob a items del ids.
        Compare obj = new Compare();


        Pair<Item>[] distancias = new Pair[candidato.size()];

        for (int i = 0; i < candidato.size(); ++i) {
            Item x = candidato.get(i);
            double y = Distancias.distancia_dos_items(ob.getValors_atributs(), candidato.get(i).getValors_atributs());
            Pair<Item> a = new Pair<Item>(x, y);
            distancias[i] = a;
        }
        obj.compare(distancias, distancias.length);

        int kk = k;

        ArrayList< Pair<Item> > k_distancias = new ArrayList<>(kk);
        for (int i = 0; i < kk; ++i) k_distancias.add(i, distancias[i]);
        return k_distancias;

    }

}
