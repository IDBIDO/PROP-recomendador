package project;
import java.util.ArrayList;

public class PosicionKMeans {

    private ArrayList<Double> valores;
    private int dimension;

    public PosicionKMeans() {
        this.valores = new ArrayList<>();
        this.dimension = 0;
    }

    public PosicionKMeans(ArrayList<Double> valores) {
        this.valores = new ArrayList<>();
        for(Double value : valores) {
            this.valores.add(value);
        }
        this.dimension = valores.size();
    }

    public ArrayList<Double> getValores() { return this.valores; }

    public double get(int index) { return this.valores.get(index); }

    public void añadirValor(Double valor) {
        // Añade una nueva dimension con el valor del parametro pasado
        this.valores.add(valor);
        this.dimension++;
    }

    public void set(int index, double value) {
        this.valores.set(index, value);
    }

    public static PosicionKMeans puntoAleatorio(int dimension, PosicionKMeans min, PosicionKMeans max) {

        // Devuelve un punto aleatorio con dimension 'dimension' entre los puntos 'min' y 'max'
        PosicionKMeans puntoAleatorio = new PosicionKMeans();
        for(int i=0; i<dimension; i++) {
            puntoAleatorio.añadirValor(Math.random()*(max.get(i)-min.get(i))+min.get(i));
        }
        return puntoAleatorio;

    }

    public PosicionKMeans escalarPosicion(double escalar) {
        // Escala euclidianamente la posicion por el valor pasado por parametro
        for(int i=0; i<dimension; i++) this.valores.set(i,this.valores.get(i) * escalar);
        return this;
    }

    public static PosicionKMeans sumarPosiciones( PosicionKMeans a, PosicionKMeans b){
        // Devuelve la suma entre dos posiciones 'a' + 'b', suma euclidiana
        if(a.dimension==b.dimension) {
            PosicionKMeans suma = new PosicionKMeans();
            for(int i=0; i< a.dimension; i++) {
                suma.añadirValor(a.get(i)+b.get(i));
            }
            return suma;
        } else return null;  // si las posiciones no tienen la misma dimension no se pueden sumar
    }

    public static PosicionKMeans nulo(int dimension, double initalValue) {
        // Devuelve una posicion de dimension 'dimension' con todos los valores a 'initValue'
        // Ejemplo: (0,0,0) -> dimension = 3, initValue = 0.0
        PosicionKMeans nulo = new PosicionKMeans();
        for(int i=0; i<dimension; i++) nulo.añadirValor(initalValue);
        return nulo;
    }

    public static PosicionKMeans restarPosiciones(PosicionKMeans a, PosicionKMeans b) {
        // Devuelve la resta de las dos posiciones 'a' - 'b', resta euclidiana
        if(a.dimension==b.dimension) {
            PosicionKMeans resta = new PosicionKMeans();
            for(int i=0; i< a.dimension; i++) {
                resta.añadirValor(a.get(i)-b.get(i));
            }
            return resta;
        }else return null; // no se pueden restar dos posiciones con dimensiones diferentes
    }

    public PosicionKMeans sumarElemento(int index, double rating) {
        // Suma al elemento i-esimo (index) el valor de rating pasado por parametro
        this.valores.set(index, this.valores.get(index) + rating);
        return this;
    }

    public boolean isNull() {
        // Devuelve cierto si el vector tiene todos sus valores a 0.0, falso en caso contrario
        for(int i=0; i<this.dimension; i++) {
            if(valores.get(i)!=0.0) return false;
        }
        return true;
    }

}
