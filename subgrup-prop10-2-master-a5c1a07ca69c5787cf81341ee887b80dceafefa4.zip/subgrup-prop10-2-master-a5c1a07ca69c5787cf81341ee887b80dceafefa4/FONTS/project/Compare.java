package project;

import java.util.Arrays;
import java.util.Comparator;

public class Compare {

    static void compare(Pair arr[], int n)
    {
        // Comparator to sort the pair according to second element
        Arrays.sort(arr, new Comparator<Pair>() {
            public int compare(Pair p1, Pair p2)
            {
                //return p1.y - p2.y;
                if (p1.y > p2.y) return 1;
                else if (p1.y == p2.y) return 0;
                else return -1;

            }
        });

        /*
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i].x + " " + arr[i].y + " " + "\n");
        }
        */

    }

}
