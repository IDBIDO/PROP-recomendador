package project;

import persistencia.CtrlPersistencia;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Scanner;

public class CtrlDominio {


    private Perfil perfil = null;                           // perfil cargado que esta usando el programa
    private ArrayList<Item> itemsDelSistema;                // items del sistema
    private ArrayList<Valoracion> valoracionesDelSistema;   // valoraciones del sistema
    private ArrayList<TipoItem> tiposItem;      // todos los tipo de item del programa
    private double minRating;                   // valoracion minima de las valoraciones del sistema
    private double maxRating;                   // valoracion maxima de las valoraciones del sistema
    public int indexUser;

    private static CtrlDominio instance = null;     // Singleton

    public CtrlDominio() {
        itemsDelSistema = new ArrayList<>();
        valoracionesDelSistema = new ArrayList<>();
        tiposItem = new ArrayList<>();
        minRating = 0;
        maxRating = 0;
    }

    public static void resetInstance() {
        Instance().itemsDelSistema = new ArrayList<>();
        Instance().valoracionesDelSistema = new ArrayList<>();
        Instance().tiposItem = new ArrayList<>();
        Instance().minRating = 0;
        Instance().maxRating = 0;
    }


    public static CtrlDominio Instance(){
        if(instance == null){
            instance = new CtrlDominio();
        }
        return instance;
    }

    public double getMinRating() { return this.minRating; }

    public double getMaxRating() { return this.maxRating; }

    public ArrayList<Valoracion> getValoraciones() { return this.valoracionesDelSistema; }

    public ArrayList<Valoracion> getValoraciones(String userID) {
        ArrayList<Valoracion> valoracionesLeidas = new ArrayList<>();
        for(Valoracion val : Instance().valoracionesDelSistema) {
            if(val.getUser().equals(userID)) valoracionesLeidas.add(val);
        }
        return valoracionesLeidas;
    }

    public Perfil getPerfil() { return Instance().perfil; }

    public static void Guardar() {
    
        // GUARDAR ITEMS
        CtrlPersistencia.Instance().guardarItems(CtrlDominio.Instance().getItems());

        // GUARDAR VALORACIONES
        CtrlPersistencia.Instance().guardarValoraciones(CtrlDominio.Instance().getValoraciones());

    }

    public ArrayList<TipoItem> getTiposItem() {
        return Instance().tiposItem;
    }

    public ArrayList<Item> getItems() {
        return Instance().itemsDelSistema;
    }

    public Item buscar_item(String itemID) {
        for(Item i : CtrlDominio.Instance().getItems()) {
            if(i.getID().equals(itemID)) return i;
        }
        return null;
    }

    public int getMaxIDItem() {
        int max_id = 0;
        for(Item i: itemsDelSistema){
            if (Integer.parseInt(i.getID()) > max_id) max_id = Integer.parseInt(i.getID());
        }
        return max_id + 1;
    }

    public double getMediaValoraciones() {
        if(((UsuarioActivo)CtrlDominio.Instance().getPerfil()).getValoraciones().size()==0) return 0.0;
        double mediaValoraciones = 0.0;
        for(Valoracion v : ((UsuarioActivo)CtrlDominio.Instance().getPerfil()).getValoraciones()) mediaValoraciones += v.getValor();
        mediaValoraciones = mediaValoraciones / ((UsuarioActivo)CtrlDominio.Instance().getPerfil()).getValoraciones().size();
        return mediaValoraciones;
    }

    public void add_TipoItem(ArrayList<String> cabecera, String nombre){

        if(!nombre.equals("")) this.tiposItem.add(new TipoItem(nombre,cabecera));
        else {
            System.out.println("Se quiere crear un nuevo tipo de item con la sigüiente cabecera:");
            System.out.println(cabecera);
            System.out.println("Con que nombre la quieres crear?");
            Scanner input = new Scanner(System.in);
            nombre=input.nextLine();
            while (alreadyExistTipoItem(nombre)) {
                System.out.println("Ya existe este tipo de item, prueba con otro nombre.");
                nombre = input.nextLine();
            }
            this.tiposItem.add(new TipoItem(nombre, cabecera));
        }
    }

    public void creaItem(String id, ArrayList<String> atributos, ArrayList<String> valores) {
        if(!existe_item(id)){
            // generar instancia del nuevo item
            Item i = new Item(id, valores,atributos);

            // se detecta el tipo de item
            if(tiposItem.size()==0) add_TipoItem(i.getCabeceras_atributos(), "TIPO ITEM " + getTiposItem().size());
            double precision = i.detectaTipo(CtrlDominio.Instance().getTiposItem());
            if(precision<85) {
                add_TipoItem(i.getCabeceras_atributos(),"TIPO ITEM " + getTiposItem().size());
                i.detectaTipo(CtrlDominio.Instance().getTiposItem());
            } else i.detectaTipo(CtrlDominio.Instance().getTiposItem());
            Instance().itemsDelSistema.add(i);
        } else {
            System.out.println("Ya existe un item con este id, se aborta la creacion de este nuevo item...");
            return;
        }
    }

    public void removeItem(Item i) {
        Instance().itemsDelSistema.remove(i);
    }

    public void addValoracion(Valoracion v) {
        this.valoracionesDelSistema.add(v);
    }

    public void assigna_perfil(Perfil p){
        this.perfil = p;
    }

    public void guardarItems(ArrayList<Item> items) {
        for(Item i : items) {
            // se detecta el tipo de item que es el nuevo item
            if(tiposItem.size()==0) add_TipoItem(i.getCabeceras_atributos(), "TIPO ITEM " + getTiposItem().size());
            double precision = i.detectaTipo(CtrlDominio.Instance().getTiposItem());
            if(precision<85) {
                add_TipoItem(i.getCabeceras_atributos(),"TIPO ITEM " + getTiposItem().size());
                i.detectaTipo(CtrlDominio.Instance().getTiposItem());
            } else i.detectaTipo(CtrlDominio.Instance().getTiposItem());
            Instance().itemsDelSistema.add(i);
        }
    }

    public void guardarValoraciones(ArrayList<Valoracion> valoraciones) {
        for(Valoracion val : valoraciones) {
            if(val.getValor() > this.maxRating) this.maxRating = val.getValor();
            else if(val.getValor() < this.minRating) this.minRating = val.getValor();
            this.valoracionesDelSistema.add(val);
        }
    }

    public String CaesarCipherEncrypt(String password){
        String b64enconded = Base64.getEncoder().encodeToString(password.getBytes());
        String reverse = new StringBuffer(b64enconded).reverse().toString();

        StringBuilder tmp = new StringBuilder();
        final int OFFSET = 4;
        for(int i = 0; i < reverse.length(); ++i){
            tmp.append((char)(reverse.charAt(i)+OFFSET));
        }

        return tmp.toString();
    }

    public String CaesarCipherDecrypt(String enc_password){
        StringBuilder tmp = new StringBuilder();
        final int OFFSET = 4;

        for(int i = 0; i < enc_password.length(); ++i){
            tmp.append((char)(enc_password.charAt(i) - OFFSET));
        }

        String reversed = new StringBuffer(tmp.toString()).reverse().toString();

        return new String(Base64.getDecoder().decode(reversed));
    }

    //iniciar_sesion para presentacion ---
    public boolean iniciar_sesion_p(String user, String pass) {

        String pass_encr = CaesarCipherEncrypt(pass);

        if(CtrlPersistencia.Instance().getImportador().correct_user_pass(user,pass_encr)){
            String userID = CtrlPersistencia.Instance().getID(user);

            if(user.contains("admin")){
                Instance().perfil = new Administrador(
                        user,
                        userID,
                        pass,
                        Instance()
                );
            }
            else {
                Instance().perfil = new UsuarioActivo(
                        user,
                        userID,
                        pass,
                        Instance()
                );
            }
            return true;
        }

        return false;
    }

    //metodo antiguo para main, se eliminara cuando la prueba de presentacion salga bien
    public boolean iniciar_sesion() {
        Scanner input = new Scanner(System.in);
        System.out.println("Nombre de usuario: ");
        String user = input.next();
        System.out.println("Contraseña: ");
        String pass = input.next();
        String pass_encr = CaesarCipherEncrypt(pass);
        if(CtrlPersistencia.Instance().getImportador().correct_user_pass(user,pass_encr)){
            String userID = CtrlPersistencia.Instance().getID(user);

            if(user.contains("admin")){
                Instance().perfil = new Administrador(
                        user,
                        userID,
                        pass,
                        Instance()
                );
            }
            else {
                Instance().perfil = new UsuarioActivo(
                        user,
                        userID,
                        pass,
                        Instance()
                );
            }
            return true;
        }
        else {
            System.out.println("Nick o contraseña incorrecta.");
            System.out.println("Quieres registrarte?");
            System.out.println("1.Si");
            System.out.println("2.No");
            input = new Scanner(System.in);
            int decision = input.nextInt();
            //cin
            if(decision==1){
                Instance().registrar();
            }
        }
        return false;
    }


    //registrar para presentacion ---
    public boolean registrar_p(String nick, String pwd1) {

        if(existUsername(nick)) {
            return false;
        } else {
            pwd1 = CaesarCipherEncrypt(pwd1);
            CtrlPersistencia.guardarUsuarioRegistrado(nick, pwd1);
            System.out.println("Te has registrado correctamente " + nick);
            return true;
        }

    }

    //metodo antiguo para main, se eliminara cuando la prueba de presentacion salga bien
    public void registrar() {

        String nick;
        String pwd1, pwd2;
        while(true) {
            System.out.println("Escribe tu username:");
            Scanner input = new Scanner(System.in);
            nick = input.nextLine();
            System.out.println("Escribe tu contraseña");
            pwd1 = input.nextLine();
            System.out.println("Confirma tu contraseña");
            pwd2 = input.nextLine();
            if(!pwd1.equals(pwd2)) {
                System.out.println("Las contraseñas no coinciden. Pruebalo otra vez.");
            }
            else {
                if(CtrlPersistencia.Instance().getImportador().existe_username(nick)) {
                    System.out.println("Ya existe este username, prueba de usar otro.");
                } else {
                    pwd1 = CaesarCipherEncrypt(pwd1);
                    System.out.println(pwd1);
                    System.out.println("prueba");
                    CtrlPersistencia.guardarUsuarioRegistrado(nick, pwd1);
                    System.out.println("Te has registrado correctamente " + nick);
                    return;
                }
            }
        }


    }

    public boolean alreadyExistTipoItem(String nombre) {
        for(TipoItem tt : Instance().getTiposItem()) if(tt.getNombre_tipo().equals(nombre)) return true;
        return false;
    }

    public boolean existe_item(String idItem){
        for(Item i : Instance().itemsDelSistema) {
            if(i.getID().equals(idItem)) return true;
        }
        return false;
    }
    
    public boolean existUsername(String user_name) {
    	return CtrlPersistencia.Instance().getImportador().existe_username(user_name);
    }
    
    public void actualizarUsuario(Perfil perfil, String username, String password) {
    
    	CtrlPersistencia.Instance().actualizarUsuario(perfil.getID(),username,CaesarCipherEncrypt(password));
    	
    }

    public boolean borraItem(String id_it) {
        for(int i = 0; i < itemsDelSistema.size(); ++i){
            if(itemsDelSistema.get(i).getID().equals(id_it)) {
                itemsDelSistema.remove(itemsDelSistema.get(i));
                return true;
            }
        }
        return false;
    }

    public Item getItembyID(String itemID) {
        for(Item i : Instance().getItems()) if(i.getID().equals(itemID)) return i;
        return null;
    }

    public void valorar_item(){
        System.out.println("Dinos el id del item que quieres valorar:");
        Scanner scanner = new Scanner(System.in);
        String itemID = scanner.nextLine();

        // Si el itemID no existe en el sistema, se vuelve a pedir uno
        while(itemID.equals("") || !CtrlDominio.Instance().existe_item(itemID)) {
            System.out.println("El item con id " + itemID + " no existe, prueba de nuevo o inserta 'Salir' para volver a la pantalla anterior.");
            itemID = scanner.nextLine();
            if(itemID.equals("Salir") || itemID.equals("salir")) return;  // no se ha valorado el item y se vuelve al estado anterior sin hacer cambios
        }

        System.out.println("Dinos la valoracion que le quieres dar: entre " + Instance().minRating + " i el " + Instance().maxRating);
        double rating;
        try{
            rating = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException nfe) {
            System.out.println("Formato incorrecto, se aborta la acción.");
            return;
        }

        // Se ajusta la valoracion a los valores maximos y minimos del sistema
        if(rating < CtrlDominio.Instance().getMinRating()) rating = CtrlDominio.Instance().getMinRating();
        else if(rating > CtrlDominio.Instance().getMaxRating()) rating = CtrlDominio.Instance().getMaxRating();

        Item itemValorado = getItembyID(itemID);
        Valoracion nuevaValoracion = new Valoracion(itemValorado,rating, Instance().getPerfil().getID());
        if(Instance().existe_valoracion(itemValorado)) {
            CtrlDominio.Instance().eliminar_valoracion(itemValorado);
            ((UsuarioActivo)Instance().perfil).eliminar_valoracion(itemValorado);
        }
        Instance().addValoracion(nuevaValoracion);
        ((UsuarioActivo)Instance().perfil).addValoracion(nuevaValoracion);

    }

    public boolean existe_valoracion(Item item) {
        for(Valoracion valoracion : Instance().valoracionesDelSistema) {
            if(valoracion.get_Item().equals(item)) return true;
        }
        return false;
    }

    public void eliminar_valoracion(Item item) {
        for(Valoracion valoracion : Instance().valoracionesDelSistema) {
            if(valoracion.get_Item().equals(item)) {
                Instance().valoracionesDelSistema.remove(valoracion);
                return;
            }
        }
    }
    
    public void eliminarUsuario(String userID) {
    
    	CtrlPersistencia.Instance().eliminarUsuario(userID);
    }

}
