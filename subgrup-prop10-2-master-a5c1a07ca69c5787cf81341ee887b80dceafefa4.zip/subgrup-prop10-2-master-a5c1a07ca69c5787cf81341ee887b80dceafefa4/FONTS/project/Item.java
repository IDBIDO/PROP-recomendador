package project;

import java.lang.reflect.Array;
import java.util.*;

/**Representa un item*/
public class Item {

    private String ID;                              //identificador del item
    private ArrayList<String> valors_atributs;      //valores de las columnas de la cabecera
    private ArrayList<String> cabeceras_atributos;  //cabecera que define su tipo de item
    private TipoItem tipo_item;                     //su tipo de item

    //------------------------------------
    /**Devuelve el ID del item*/
    public String getID() {
        return ID;
    }

    /**Devuelve los valores de sus atributos*/
    public ArrayList<String> getValors_atributs() {
        return valors_atributs;
    }

    /**Devuelve el valor de un atributo en la posicion i de la lista*/
    public String getValor(int i) {
        return valors_atributs.get(i);
    }

    /**Devuelve el valor de los atributos*/
    public String getValor(String atr) {
        int i=0;
        for(String atributo : this.getCabeceras_atributos()) {
            if(atr.equals(atributo)) return this.getValors_atributs().get(i);
            i++;
        }
        return "";
    }

    /**Devuelve los nombres de las columnas de la cabecera del item (que no tiene que ser igual a la del tipo de item)*/
    public ArrayList<String> getCabeceras_atributos() {
        return cabeceras_atributos;
    }

    public TipoItem getTipoItem() { return this.tipo_item; }

    /**Setea el ID del item*/
    public void setID(String ID) {
        this.ID = ID;
    }

    /**Setea un valor de un atributo*/
    public void setValor(int it, String new_valor) {
        valors_atributs.set(it, new_valor);
    }

    /**Setea los valores de los atributos*/
    public void setValors_atributs(ArrayList<String> valors_atributs) {
        this.valors_atributs = valors_atributs;
    }

    /**Setea un conjunto de nombres de columnas de su cabecera*/
    public void setCabeceras_atributos(ArrayList<String> cabeceras_atributos) {
        this.cabeceras_atributos = cabeceras_atributos;
    }

    //---------------------------------------

    /**Construye un item vacio*/
    public Item() {
        ID = "";
        valors_atributs = new ArrayList<>();
        cabeceras_atributos = new ArrayList<>();
    }

    /**Construye un item con los parametros*/
    public Item(String ID, ArrayList<String> valors_atributs, ArrayList<String> cabeceras_atributos) {
        this.ID = ID;
        this.valors_atributs = valors_atributs;
        this.cabeceras_atributos = cabeceras_atributos;
    }

    //------------------------------------------

    /**Detecta el tipo de item del que se trata*/
    public Double detectaTipo(ArrayList<TipoItem> tiposItem) {

        // calcular similitud con las cabeceras de los tipos de item existentes

        TipoItem masSimiliar = new TipoItem();
        double similitudActual = Double.MAX_VALUE;

        // si no existe ningun tipo de item, el tipo de item de este item en concreto sera un puntero null de TipoItem

        for(TipoItem tt : tiposItem) {

            double sumatorio = 0.0;
            ArrayList<String> ttAtributos = tt.getCabecera();

            int minSize = Integer.min(cabeceras_atributos.size(), ttAtributos.size());

            //recorre los atributos buscando coincidencias con el actual tipo de item
            for(int i=0; i<minSize; i++)  {
                if(ttAtributos.equals(cabeceras_atributos.get(i))) {
                    this.tipo_item = tt;
                    return 100.0;
                }
                sumatorio += CaracteresSimilares(cabeceras_atributos.get(i), ttAtributos.get(i));
            }

            // similitud entre los atributos faltantes de las cabeceras

            if(cabeceras_atributos.size() > ttAtributos.size()) {
                for(int i=0; i<cabeceras_atributos.size() - minSize; i++) {
                    sumatorio += cabeceras_atributos.get(minSize + i).length();
                }
            } else {
                for(int i=0; i<ttAtributos.size() - minSize; i++) {
                    sumatorio += ttAtributos.get(minSize + i).length();
                }
            }

            //si la similitud con el tipo item actual es mayor que el recien calculado se cambian
            if(similitudActual > sumatorio) {
                similitudActual = sumatorio;
                masSimiliar = tt;
            }

        }

        //se le asigna el tipo de item mas similar
        this.tipo_item = masSimiliar;

        if(similitudActual!=0) similitudActual = Math.log(similitudActual);
        double precision = (1.0-((similitudActual)/masSimiliar.getCabecera().size()*1.0))*100.0;
        if(precision < 0) precision = 0;
        return precision;

    }

    /**Compara caracteres*/
    public Integer CaracteresSimilares(String a, String b) {

        if(a.isEmpty()) return b.length();
        else if(b.isEmpty()) return a.length();

        return CaracteresSimilares(a.substring(1), b.substring(1)) + (a.charAt(0) == b.charAt(0) ? 0 : 1);

    }
}