package project;
import persistencia.CtrlPersistencia;

import java.util.*;

public abstract class Algoritmos {

    static public Map<String,ArrayList<Valoracion>> valoracionsKnown;
    static public Map<String,ArrayList<Valoracion>> valoracionsUnKnown;

    private static double IDCG;
    private static int Q;

    private static double minRating;
    private static double maxRating;

    public static void cargarDatos() {

        valoracionsKnown = new HashMap<>();
        valoracionsUnKnown = new HashMap<>();
        ArrayList<Valoracion> arrKnown = CtrlPersistencia.Instance().importarValoraciones("ratings.test.known.csv");
        ArrayList<Valoracion> arrUnkown = CtrlPersistencia.Instance().importarValoraciones("ratings.test.unknown.csv");

        maxRating = Double.MIN_VALUE;
        minRating = Double.MAX_VALUE;

        // Se llenan las valoraciones Known y los atributos minRating y maxRating que sirven para el calculo del IDCG
        for(Valoracion v : arrKnown) {
            if(valoracionsKnown.get(v.getUser())==null) valoracionsKnown.put(v.getUser(), new ArrayList<>());
            valoracionsKnown.get(v.getUser()).add(v);
            if(v.getValor() > maxRating) maxRating = v.getValor();
            else if(v.getValor() < minRating) minRating = v.getValor();
        }

        // Se llenan las valoraciones UnKnown
        for(Valoracion v : arrUnkown) {
            if(valoracionsUnKnown.get(v.getUser())==null) valoracionsUnKnown.put(v.getUser(), new ArrayList<>());
            valoracionsUnKnown.get(v.getUser()).add(v);
        }

        // Se calcula el DCG ideal (IDCG)
        IDCG = 0.0;
        Q = 10;
        for(int i=1; i<=Q; i++) {
            IDCG += ((Math.pow(2, maxRating) - 1) / (Math.log(i+1)));
        }

        return;
    }

    public static double calidadDeAlgoritmoCB() {

	// NO HE TINGUT TEMPS DIMPLEMENTARHO :(, ES EL MATEIX QUE 'calidadDeALgoritmoCF' PERO AMB LA CRIDA AL CONTENT BASED

        return -1.0;
    }

    public static double calidadDeAlgoritmoCF() {

        // Se calcula el NDCG para la metodologia Collaborative Filtering

        // Se cargan los datos en el Collaborative Filtering
        CollaborativeFiltering collaborativeFiltering = new CollaborativeFiltering();
        try {
            collaborativeFiltering.CargarValoraciones("ratings.test.known.csv");
        } catch (Exception e) {
            System.out.println("Error al cargar les valoraciones de test.");
            return -1.0;
        }
        // Se calculan los parametros necesarios para el Collaborative Filtering
        // Posiciones de los usuarios
        collaborativeFiltering.calcularPosiciones();
        // ElbowTest para determinar la K optima
        collaborativeFiltering.ElbowTest();
        // Valor de los clusters
        collaborativeFiltering.KMeans();

        // Se llama recomiendan items a todos los usuarios que pertenecen a las valoraciones Known
        Map<String, ArrayList<Item>> itemsRecomendados = new HashMap<>();
        for(String user : valoracionsKnown.keySet()) {
            try {
                itemsRecomendados.put(user, collaborativeFiltering.RecomendarItem(user, Q));
            } catch (Exception e) {
                System.out.println("Error al recomendar a un usuario, se ignora las recomendaciones sobre este usuario.");
            }
        }

        // Se calcula el NDCG para las recomendaciones de cada usuario
        return calcularNDCG(itemsRecomendados);

    }

    public static double calcularNDCG(Map<String, ArrayList<Item>> itemsRecomendados) {

        // Dado un conjunto de recomendaciones, se calcula su calidad a partir del IDCG

        int cantidadUsers = itemsRecomendados.size();   // cantidad de usuarios recomendados
        double NDCG = 0.0;  // sumatorio de todos los DCG que se normalizara con el IDCG al final del metodo
        int matched = 0;    // numero de valoraciones que se han acertado sin importar su orden en las recomendaciones

        // Para cada usuario de las recomendaciones se calcula su NDCG
        for(String user : itemsRecomendados.keySet()) {
            for(int i=0; i<itemsRecomendados.get(user).size(); i++) {
                if(i>=valoracionsUnKnown.get(user).size() || itemsRecomendados.get(user).size() < i) break; // Ya no hay mas recomendaciones UnKnown o no hay tantas recomendaciones hacia un usuario
                for(Valoracion v : valoracionsUnKnown.get(user)) {
                    // para cada valoracion del UnKnown del usuario 'user' se comprueba que la recomendacion 'i' exista
                    if(v.get_Item().equals(itemsRecomendados.get(user).get(i))) {
                        matched++;
                        break;
                    }
                }
                // comprobamos que en el listado de UnKnown en la posicion 'i' coincide con la recomendacion 'i' del usuario 'user'
                if(valoracionsUnKnown.get(user).get(i).get_Item().equals(itemsRecomendados.get(user).get(i))) {
                    NDCG += ((Math.pow(2, maxRating) - 1) / (Math.log(i+2)));   // formula para el calculo de un valor del NDCG, se acumula en la variable NDCG
                }
            }
        }

        if(cantidadUsers==0.0) return 0.0;

        System.out.println("\tPorcentaje de items bien recomendados: " + (double)matched / (cantidadUsers * Q) * 100 + "%");
        NDCG = (NDCG / cantidadUsers) / IDCG;
        return NDCG;

    }

}
