package project;

import persistencia.CtrlPersistencia;

import java.util.*;

public class CollaborativeFiltering extends Algoritmos {

    private int dimensionDeDatos;
    public ArrayList<Cluster> clusters;                    // Clusters, guarda los userID en clusters que les pertoca     // Numero de centroides o clusters que genera el algoritmo
    public Map<String,PosicionKMeans> posiciones;          // posiciones de los datos a trabajar
    private ArrayList<PosicionKMeans> centroides;
    public ArrayList<Valoracion> valoracionesCargadas;     // valoraciones cargadas de los ficheros, para KMeans
    private int K;                                           // K clusters del KMeans

    private Map<String,ArrayList<String>> mejoresAtributos;
    private double minRating;
    private double maxRating;


    public CollaborativeFiltering() {

        this.dimensionDeDatos = 0;
        this.clusters = new ArrayList<Cluster>();
        this.posiciones = new HashMap<>();
        this.valoracionesCargadas = new ArrayList<>();
        this.K = 0;
        this.minRating = Double.MAX_VALUE;
        this.maxRating = Double.MIN_VALUE;
        this.mejoresAtributos = new HashMap<>();

    }

    public void InicializarDatosKMeans() {

        if(CtrlPersistencia.Instance().existFiles("posicionesKMeans")) {

            ArrayList<ArrayList<String>> posiciones = CtrlPersistencia.Instance().getImportador().importarFichero("posicionesKMeans.csv");

            // SE IMPORTAN LAS POSICIONES

            this.dimensionDeDatos = Integer.parseInt(posiciones.get(0).get(0));

            for(int i=1; i<posiciones.size(); i++) {
                this.posiciones.put(posiciones.get(i).get(0), PosicionKMeans.nulo(this.dimensionDeDatos, 0.0));
                for(int j=1; j<this.dimensionDeDatos; j++) {
                    try {
                    	this.posiciones.get(posiciones.get(i).get(0)).sumarElemento(j-1, Double.parseDouble(posiciones.get(i).get(j)));
                    } catch(Exception e) { System.out.println(i + ", " + j);}
                }
            }
            

        } else calcularPosiciones();

        if(CtrlPersistencia.Instance().existFiles("clusters")) {

            ArrayList<ArrayList<String>> clustersImportados = CtrlPersistencia.Instance().getImportador().importarFichero("clusters.csv");

            // SE IMPORTAN LOS CLUSTERS

            this.K = Integer.parseInt(clustersImportados.get(0).get(0));
            for(int i=1; i<=this.K; i++) {
                this.clusters.add(new Cluster());
                for(int j=0; j<clustersImportados.get(i).size(); j++) {
                    this.clusters.get(i-1).añadirUsuario(clustersImportados.get(i).get(j));
                }
                System.out.println("\tCluster " + (i-1) + " importado correctamente.");
            }
            
            
            this.centroides = new ArrayList<>();
            
            for(int i=this.K+1; i<=(this.K*2);i++){
            	PosicionKMeans centroide = PosicionKMeans.nulo(this.dimensionDeDatos,0.0);
            	for(int j=0; j<this.dimensionDeDatos; j++) {
            		double nuevoValue;
            		try {
		    		System.out.print(j+"_");
		    		nuevoValue = Double.parseDouble(clustersImportados.get(i).get(j));
		    		centroide.sumarElemento(j,nuevoValue);
            		} catch (Exception e) {
            			nuevoValue = 0.0;
		    		centroide.sumarElemento(j,nuevoValue);
            		}
            	}
            		
            	this.centroides.add(centroide);
            }
            

        } else {
            ElbowTest();
            KMeans();
        }

    }

    public void GuardarDatosCalculados() {

        if(this.posiciones != null) {

            ArrayList<ArrayList<String>> posicionesToSave = new ArrayList<>();
            posicionesToSave.add(new ArrayList<>());
            posicionesToSave.get(0).add(String.valueOf(this.dimensionDeDatos));
            for(String key : this.posiciones.keySet()) {
                posicionesToSave.add(new ArrayList<>());
                int index = posicionesToSave.size()-1;
                posicionesToSave.get(index).add(key);
                for(Double value : this.posiciones.get(key).getValores()) {
                    posicionesToSave.get(index).add(String.valueOf(value));
                }
            }

            CtrlPersistencia.Instance().getExportador().cleanFile("posicionesKMeans.csv");
            CtrlPersistencia.Instance().getExportador().fillFile("posicionesKMeans.csv", posicionesToSave);

        }

        if(this.clusters != null) {

            ArrayList<ArrayList<String>> clusterToSave = new ArrayList<>();
            clusterToSave.add(new ArrayList<>());
            clusterToSave.get(0).add(String.valueOf(this.K));
            int indexCluster = 1;
            for(Cluster cluster : this.clusters) {
                clusterToSave.add(new ArrayList<>());
                for(String user : cluster.getUsers()) {
                    clusterToSave.get(indexCluster).add(user);
                }
                indexCluster++;
            }
            for(PosicionKMeans centroide : this.centroides) {
            	clusterToSave.add(new ArrayList<>());
            	for(Double value : centroide.getValores()) {
            		clusterToSave.get(clusterToSave.size()-1).add(String.valueOf(value));
            	}
            }

            CtrlPersistencia.Instance().getExportador().cleanFile("clusters.csv");
            CtrlPersistencia.Instance().getExportador().fillFile("clusters.csv", clusterToSave);

        }

    }

    public void CargarValoraciones(String ...nombreArchivos) {
        this.minRating = Double.MAX_VALUE;
        this.maxRating = Double.MIN_VALUE;
        for(String archivo : nombreArchivos){
            ArrayList<Valoracion> valoraciones = CtrlPersistencia.Instance().importarValoraciones(archivo);
            if(valoraciones == null) continue;
            for(Valoracion valoracion : valoraciones) {
                if(this.maxRating<valoracion.getValor()) this.maxRating = valoracion.getValor();
                else if(this.minRating > valoracion.getValor()) this.minRating = valoracion.getValor();
                this.valoracionesCargadas.add(new Valoracion(valoracion.get_Item(),valoracion.getValor(),valoracion.getUser()));
            }
        }

    }

    public void ImportarValoraciones(ArrayList<Valoracion> valoracions) {
        this.minRating = Double.MAX_VALUE;
        this.maxRating = Double.MIN_VALUE;
        for(Valoracion valoracion : valoracions) {
            if(this.maxRating<valoracion.getValor()) this.maxRating = valoracion.getValor();
            else if(this.minRating > valoracion.getValor()) this.minRating = valoracion.getValor();
            this.valoracionesCargadas.add(new Valoracion(valoracion.get_Item(),valoracion.getValor(),valoracion.getUser()));
        }
    }

    public void EliminarValoracionesCargadas() {
        this.valoracionesCargadas = new ArrayList<>();
    }

    public ArrayList<String> calcularMejoresAtributos(String tipoItem, int numeroAtributos) {

        Map<String, Map<String, Double>> IVs = new HashMap<>();
        Map<String, Double> mediaDeEleccion = new HashMap<>();
        Map<String, Double> mediaAtributo = new HashMap<>();

        int numeroItems = CtrlDominio.Instance().getItems().size();

        // Rellenamos IVs y mediaDeEleccion
        for(Item item : CtrlDominio.Instance().getItems()) {
            if(!item.getTipoItem().getNombre_tipo().equals(tipoItem)) continue;
            for(String atr : item.getCabeceras_atributos()) {
                if(IVs.get(atr)==null) IVs.put(atr, new HashMap<>());
                if(mediaDeEleccion.get(atr)==null) mediaDeEleccion.put(atr, 0.0);
                mediaDeEleccion.put(atr, mediaDeEleccion.get(atr) + item.getValor(atr).split(";").length);
                for(String val : item.getValor(atr).split(";")) {
                    if(IVs.get(atr).get(val)==null) IVs.get(atr).put(val, 0.0);
                    IVs.get(atr).put(val, IVs.get(atr).get(val) + 1.0);
                }
            }
        }

        // Calculamos la media de cada atributo
        for(String key : mediaDeEleccion.keySet()) {
            mediaDeEleccion.put(key, mediaDeEleccion.get(key) / numeroItems);
            if(mediaAtributo.get(key)==null) mediaAtributo.put(key, 0.0);
            for(String atr : IVs.get(key).keySet()) {
                IVs.get(key).put(atr, IVs.get(key).get(atr) / mediaDeEleccion.get(key));
                mediaAtributo.put(key, mediaAtributo.get(key) + IVs.get(key).get(atr));
            }
            mediaAtributo.put(key, mediaAtributo.get(key) / IVs.get(key).size());
        }

        // Calculo de calidad de cada atributo
        Map<String,Double> betterAtributs = new HashMap<>();
        for(String key : mediaAtributo.keySet()) {

            // calculo de diferencias entre cada atributo y su media de eleccion
            double thisMedium = mediaAtributo.get(key);
            for(String atr : IVs.get(key).keySet()) mediaAtributo.put(key, mediaAtributo.get(key) + (Math.abs(thisMedium - IVs.get(key).get(atr))));
            mediaAtributo.put(key, mediaAtributo.get(key) / IVs.get(key).size());

            // calculo de los valores para cada atributo
            if( IVs.get(key).size()==numeroItems || IVs.get(key).size()==1.0 ) continue;// este atributo solo sirve para clusters de K = 1 o K = data.size()
            else betterAtributs.put(key, 1/(Math.abs((IVs.get(key).size()/mediaDeEleccion.get(key))-mediaAtributo.get(key))));
        }

        if(betterAtributs.size()==0) return null;   // no existe ningun atributo que sea bueno para clasificar, no se añadira en el calculo de posiciones

        ArrayList<String> bestAtributesSorted = new ArrayList<>();
        betterAtributs.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEachOrdered(x -> bestAtributesSorted.add(x.getKey()));

        ArrayList<String> atributosEscogidos = new ArrayList<>();
        for(int i=0; i<numeroAtributos; i++) {
            String key = bestAtributesSorted.get(bestAtributesSorted.size()-i-1);
            for(String atr : IVs.get(key).keySet()) {
                atributosEscogidos.add(atr);
                this.dimensionDeDatos++;
            }
        }

        return atributosEscogidos;
    }

    public void calcularPosiciones() {

        this.dimensionDeDatos = 0;
        Map<String, Integer> subIndexTipoItem = new HashMap<>();
        for(TipoItem tt : CtrlDominio.Instance().getTiposItem()) {
            subIndexTipoItem.put(tt.getNombre_tipo(), this.dimensionDeDatos);
            ArrayList<String> mejoresAtr = calcularMejoresAtributos(tt.getNombre_tipo(),1);
            if(mejoresAtr==null) {
                subIndexTipoItem.remove(tt.getNombre_tipo());
                continue;
            }
            this.mejoresAtributos.put(tt.getNombre_tipo(), mejoresAtr);
        }

        this.posiciones.clear();

        for(Valoracion valoracion : valoracionesCargadas) {
            String userIDValoracion = valoracion.getUser();
            String tipoItem = valoracion.get_Item().getTipoItem().getNombre_tipo();
            if(!mejoresAtributos.containsKey(tipoItem)) continue;   // este item tiene un tipo item que no tiene ningun atributo bueno para ser clasificado
            if(posiciones.get(userIDValoracion)==null) posiciones.put(userIDValoracion, PosicionKMeans.nulo(this.dimensionDeDatos, 0.0));
            for(String atr : valoracion.get_Item().getCabeceras_atributos()) {
                for(String subAtr : valoracion.get_Item().getValor(atr).split(";")) {
                    if(!mejoresAtributos.get(tipoItem).contains(subAtr)) break;
                    int i=0;
                    for(String bestAtr : mejoresAtributos.get(tipoItem)) {
                        if(bestAtr.equals(subAtr)) {
                            this.posiciones.get(userIDValoracion).sumarElemento(i + subIndexTipoItem.get(tipoItem),valoracion.getValor());
                            break;
                        }
                        i++;
                    }
                }
            }
        }
        return;
    }

    public void RecalcularPosicion(String userID) {

	int copiaDimensionDatos = this.dimensionDeDatos;
        Map<String, Integer> subIndexTipoItem = new HashMap<>();
        for(TipoItem tt : CtrlDominio.Instance().getTiposItem()) {
            subIndexTipoItem.put(tt.getNombre_tipo(), this.dimensionDeDatos);
            ArrayList<String> mejoresAtr = calcularMejoresAtributos(tt.getNombre_tipo(),1);
            if(mejoresAtr==null) {
                subIndexTipoItem.remove(tt.getNombre_tipo());
                continue;
            }
            this.mejoresAtributos.put(tt.getNombre_tipo(), mejoresAtr);
        }
	this.dimensionDeDatos = copiaDimensionDatos;

        int cluster = getClusterByUserID(userID);
        if(cluster != -1) this.clusters.remove(userID);

        this.posiciones.put(userID, PosicionKMeans.nulo(this.dimensionDeDatos, 0.0));
        for(Valoracion valoracion : CtrlDominio.Instance().getValoraciones(userID)) {
            String tipoItem = valoracion.get_Item().getTipoItem().getNombre_tipo();
            if(posiciones.get(userID)==null) posiciones.put(userID, PosicionKMeans.nulo(this.dimensionDeDatos, 0.0));
            for(String atr : valoracion.get_Item().getCabeceras_atributos()) {
                for(String subAtr : valoracion.get_Item().getValor(atr).split(";")) {

                    if(!mejoresAtributos.get(tipoItem).contains(subAtr)) break;

                    int subIndex = 0;
                    for(String tipo : mejoresAtributos.keySet()) {
                        if(tipo.equals(tipoItem)) break;
                        subIndex += mejoresAtributos.get(tipo).size();
                    }

                    int i=0;
                    for(String bestAtr : mejoresAtributos.get(tipoItem)) {
                        if(bestAtr.equals(subAtr)) {
                            if(i>=this.dimensionDeDatos) continue;
                            this.posiciones.get(userID).sumarElemento(i + subIndex,valoracion.getValor());
                            break;
                        }
                        i++;
                    }

                }
            }
        }
        System.out.println(this.posiciones.get(userID).getValores());
        double minDistance = Double.MAX_VALUE;
        cluster = 0;
        for(int i=0; i<this.clusters.size(); i++) {
            if(this.centroides.get(i)==null)continue;
            double distance = Distancias.distanciaEucladiana(this.centroides.get(i).getValores(), this.posiciones.get(userID).getValores());
            if(distance < minDistance) {
                minDistance = distance;
                cluster = i;
            }
        }
        this.clusters.get(cluster).añadirUsuario(userID);
        
        return;

    }

    public void ElbowTest() {

        int minK = 2;
        int maxK = 10;
        int bestK = 1; // si nunca se genera una K mejor (todos los usuairos estan en el mismo cluster), peor caso
        double elbowValues[] = new double[maxK-minK];
        double slopeValues[] = new double[maxK-minK-1];
        calcularPosiciones();

        for(int i=0; i<maxK-minK; i++) {
            int actualK = i + minK;
            this.K = actualK;
            KMeans();
            double sum = 0.0;
            for(int j=0; j<actualK; j++) {
                double quadraticMean = 0.0;
                for(int k=0; k<this.clusters.get(j).size(); k++) {
                    quadraticMean += Distancias.distanciaEucladiana(this.posiciones.get(this.clusters.get(j).get(k)).getValores(), this.centroides.get(j).getValores());
                }
                if(this.clusters.get(j).size()!=0) sum += quadraticMean / this.clusters.get(j).size();
            }
            sum = sum / (actualK);
            elbowValues[i] = sum;
            if(i>0) slopeValues[i-1] = elbowValues[i-1] - elbowValues[i];
        }

        double lastRelation = slopeValues[0]/slopeValues[1];
        for(int i=2; i<slopeValues.length; i++) {
            double actualRelation = slopeValues[i-1]/slopeValues[i];
            if(lastRelation-actualRelation < 0.55) {
                bestK = i+minK+1;
                break;
            }
            lastRelation = actualRelation;
        }

        this.K = bestK;

    }

    /**
     * Genera K clusters vacios y inicializa los centroides en una posicion
     * aleatorio dentro del espacio cerrado de los datos.
     */
    private void InicializarCentroides() {

        PosicionKMeans puntoMinimo;
        PosicionKMeans puntoMaximo;

        // inicializamos los puntosMinimo y puntoMaximo al primer elemento de las posiciones
        PosicionKMeans firstPosition = posiciones.get(posiciones.keySet().iterator().next());
        puntoMinimo = new PosicionKMeans(firstPosition.getValores());
        puntoMaximo = new PosicionKMeans(firstPosition.getValores());

        // actualizamos los puntosMinimo puntoMaximo buscando sus valores en todos los datos
        Iterator it = posiciones.keySet().iterator();
        while(it.hasNext()) {
            int j = 0;
            for(Double value : posiciones.get(it.next()).getValores()){
                if(value > puntoMaximo.get(j)) puntoMaximo.set(j, value);
                else if(value < puntoMinimo.get(j)) puntoMinimo.set(j, value);
                j++;
            }
        }

        // inicializamos los clusters de manera que esten vacios
        // inicializamos los centroides de manera que sean un punto aleatorio en el espacio cerrado de los datos
        it = posiciones.keySet().iterator();
        for(int i=0; i<K; i++) {
            this.centroides.set(i,PosicionKMeans.puntoAleatorio(dimensionDeDatos,puntoMinimo,puntoMaximo));
        }

    }

    private void reconocerClusters() {

        Iterator it = posiciones.keySet().iterator();

        while(it.hasNext()){
            String userID = ((String)it.next());
            double minimumDistance = Distancias.distanciaEucladiana(posiciones.get(userID).getValores(),centroides.get(0).getValores());
            int clusterAssignado = 0;
            for(int j=1; j<K; j++){
                double actualDistance = Distancias.distanciaEucladiana(posiciones.get(userID).getValores(),centroides.get(j).getValores());
                if(actualDistance<minimumDistance) {
                    minimumDistance = actualDistance;
                    clusterAssignado = j;
                }
            }
            int clusterAntiguo = getClusterByUserID(userID);
            if(clusterAntiguo==-1) clusters.get(clusterAssignado).añadirUsuario(userID);
            else {
                if(clusterAntiguo!=clusterAssignado) {
                    clusters.get(clusterAntiguo).removeUser(userID);
                    clusters.get(clusterAssignado).añadirUsuario(userID);
                }
            }
        }

    }

    private ArrayList<PosicionKMeans> reajustarCentroides() {

        // Mueve los centroides en la media de los valores de su cluster
        // PRE: ...
        // POST: los centroides estan actualizados


        ArrayList<PosicionKMeans> distancias = new ArrayList<>();
        for(int i=0; i<centroides.size(); i++) distancias.add(centroides.get(i));

        int clusterIndex = 0;
        for(Cluster cluster : this.clusters) {
            PosicionKMeans puntoMedioDelCluster = PosicionKMeans.nulo(dimensionDeDatos,0.0);
            for(String user : cluster.getUsers()) {
                puntoMedioDelCluster = PosicionKMeans.sumarPosiciones(puntoMedioDelCluster, posiciones.get(user));
            }
            if(cluster.size()==0) continue;
            puntoMedioDelCluster = puntoMedioDelCluster.escalarPosicion(1.0/cluster.size());
            this.centroides.set(clusterIndex,puntoMedioDelCluster); // Se reajusta el centroide en el punto medio del cluster
            clusterIndex++;
        }

        for(int i = 0; i< this.centroides.size(); i++) {
            distancias.set(i,PosicionKMeans.restarPosiciones(distancias.get(i),centroides.get(i)));
        }

        return distancias;
    }

    /**
     * Generacion de K clusters sobre los usuarios que han hecho minimo una valoracion,el
     * valor de K se calcula con el parametro de Sihouette.
     */
    public void KMeans() {

        this.centroides = new ArrayList<PosicionKMeans>();
        this.clusters = new ArrayList<Cluster>();

        for (int i = 0; i < K; i++) {
            this.centroides.add(new PosicionKMeans());
            this.clusters.add(new Cluster());
        }

        // Inicializacion de los centroides y de los clusters

        InicializarCentroides();

        // Inicializamos los primeros centroides con sus primeros datos aleatorios

        reconocerClusters();

        // Fase iterativa KMeans : genera tantas iteraciones del KMeans hasta que ningun centroide se mueve
        ArrayList<PosicionKMeans> distanciasUltimaIteracion = new ArrayList<>();

        KMEANS_LABEL:
        while (true) {

            distanciasUltimaIteracion = reajustarCentroides();      // reajusta los centroides y devuelve la distancia entre los centroides de la anterior iteracion y los actuales
            reconocerClusters();                                    // ajusta los usuarios a los nuevos centroides y los asigna a su nuevo o mismo cluster

            for (PosicionKMeans distanciaUltima : distanciasUltimaIteracion) {
                // genera otra iteracion del KMeans ya que exista un centroide que ha actualizado su posicion
                if (!(distanciaUltima.isNull())) continue KMEANS_LABEL;
            }

            // todos los centroides han hecho una iteracion donde no se han actualizado su posicion, KMeans ha llegado a su punto optimo
            break KMEANS_LABEL;
        }

        return;

    }

    private int getClusterByUserID(String userID) {
        int clusterIndex = 0;
        for(Cluster c : clusters) {
            if(c.existUser(userID)) return  clusterIndex;
            clusterIndex++;
        }
        return -1;
    }

    public ArrayList<Item> RecomendarItem(String userID, int numeroItems) {

        ArrayList<Valoracion> bestPredictions = new ArrayList<>();
        Map<Item, Double> itemsValorats = new HashMap<>();
        Cluster cluster = new Cluster();

        	
        
        if(getClusterByUserID(userID)<0) {
        	System.out.println("Todabia no tiene valoraciones, valora para poderte recomendar items...");
        	return new ArrayList<>();
        }
        else cluster = this.clusters.get(getClusterByUserID(userID));
        

        if(cluster.size()<2) return new ArrayList<>();

        Map<String, ArrayList<Valoracion>> valoracionesCluster = new HashMap<>();
        Set<Valoracion> itemsQuery = new HashSet<>();

        for(Valoracion val : this.valoracionesCargadas){
            if(val.getUser().equals(userID)) itemsValorats.put(val.get_Item(), val.getValor());
            else if(cluster.getUsers().contains(val.getUser())) {
                if(valoracionesCluster.get(val.getUser())==null) valoracionesCluster.put(val.getUser(), new ArrayList<>());
                valoracionesCluster.get(val.getUser()).add(val);
            }
        }

	for(String user : valoracionesCluster.keySet()) {
            itemsQuery.addAll(valoracionesCluster.get(user));
        }
        ArrayList<String> itemsIDYaValorados = new ArrayList<>();
        for(Valoracion valQuery : itemsQuery) {
            if(itemsValorats.keySet().contains(valQuery.get_Item())) continue;
            if(itemsIDYaValorados.contains(valQuery.get_Item().getID())) continue;
            itemsIDYaValorados.add(valQuery.get_Item().getID());
            Valoracion val = predecirItem(userID, itemsValorats, valoracionesCluster,cluster, valQuery.get_Item());
            boolean better = false;
            for(int i=0; i<bestPredictions.size(); i++) {
                if(bestPredictions.get(i).getValor() < val.getValor()) {
                    bestPredictions.add(i,val);
                    better = true;
                    break;
                }
            }
            if(!better) bestPredictions.add(val);
        }

        ArrayList<Item> sortedBestItems = new ArrayList<>();
        for(int i=0; i<numeroItems; i++) {
            sortedBestItems.add(bestPredictions.get(i).get_Item());
        }

        return sortedBestItems;

    }

    public Valoracion predecirItem(String userID, Map<Item, Double> valoracionesUsuario, Map<String,ArrayList<Valoracion>> valoracionesCluster, Cluster clusterUsuario, Item itemQuery) {

        Map<String, ArrayList<Valoracion>> valoracionesClusterValidas = new HashMap<>();
        for(String key : valoracionesCluster.keySet()) {
            boolean valUser = false;
            boolean valItemQuery = false;
            ArrayList<Valoracion> valoraciones = new ArrayList<>();
            for(Valoracion v : valoracionesCluster.get(key)) {
                if(valoracionesUsuario.keySet().contains(v.get_Item())) {
                    valUser = true;
                    valoraciones.add(v);
                }
                else if(v.get_Item().equals(itemQuery)) {
                    valItemQuery = true;
                    valoraciones.add(v);
                }
            }
            if(valUser && valItemQuery) valoracionesClusterValidas.put(key,valoraciones);
        }

        return new Valoracion(itemQuery,SlopeOne(valoracionesUsuario, itemQuery, valoracionesClusterValidas),userID);

    }

    public double SlopeOne( Map<Item,Double> valoracionesUsuario, Item itemQuery, Map<String,ArrayList<Valoracion>> valoraciones) {

        Iterator itItemsQuery = valoraciones.keySet().iterator();
        Map<String, Double> valoracionesItemQuery = new HashMap<>();
        ArrayList<Valoracion> valoracionesDesviaciones = new ArrayList<>();
        while(itItemsQuery.hasNext()) {
            String key = (String)itItemsQuery.next();
            for(Valoracion v : valoraciones.get(key)){
                if(v.get_Item().equals(itemQuery)) {
                    valoracionesItemQuery.put(v.getUser(),v.getValor());
                } else {
                    valoracionesDesviaciones.add(v);
                }
            }
        }

        if(valoracionesDesviaciones.size()==0 || valoracionesItemQuery.size()==0) return 0.0;

        Map<Item, Double> desviacionesPorItem = new HashMap<>();
        Map<Item, Integer> cardinales = new HashMap<>();
        for(Valoracion v : valoracionesDesviaciones) {
            if(desviacionesPorItem.get(v.get_Item())==null) {
                desviacionesPorItem.put(v.get_Item(),0.0);
                cardinales.put(v.get_Item(),0);
            }
            desviacionesPorItem.put(v.get_Item(), desviacionesPorItem.get(v.get_Item()) + (valoracionesItemQuery.get(v.getUser()) - v.getValor()));
            cardinales.put(v.get_Item(), cardinales.get(v.get_Item()) + 1);
        }

        double sumatoriDesviacions = 0.0;
        double sumatorioCardinales = 0.0;
        Iterator key = desviacionesPorItem.keySet().iterator();
        while(key.hasNext()) {
            Item k = (Item)key.next();
            sumatoriDesviacions += ((desviacionesPorItem.get(k))*((double)cardinales.get(k)) + valoracionesUsuario.get(k));
            sumatorioCardinales += cardinales.get(k);
        }

        return (sumatoriDesviacions) / sumatorioCardinales;

    }

}

