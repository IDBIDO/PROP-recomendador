package project;

public class Valoracion {
    // region Attributes
    private String user;
    private Item item;
    private double valor;

    // endregion

    // region Constructors

    //Constructor completo
    public Valoracion(Item it, double val, String usuario){
        this.user = usuario;
        this.item = it;
        this.valor = val;
    }

    public Valoracion() {

    }

    // endregion

    // region Methods

    //GETTERS
    public double getValor(){
        return valor;
    }

    public Item get_Item(){
        return this.item;
    }

    public String getUser() { return this.user; }

    //SETTERS
    public void setValor(int val){
        this.valor = val;
    }

    public void set_item(Item item){
        this.item = item;
    }

    // endregion
}
