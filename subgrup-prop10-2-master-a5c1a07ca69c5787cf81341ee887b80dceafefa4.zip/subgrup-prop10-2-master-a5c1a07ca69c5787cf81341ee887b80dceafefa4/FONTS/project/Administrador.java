package project;

import java.util.ArrayList;
import java.util.Scanner;

public class Administrador extends Perfil {

    //Constructor completo
    public Administrador(String Nick, String id, String password, CtrlDominio ctrldom) {
        super.setNickname(Nick);
        super.setID("0");
        super.setPassword(password);
        this.ctrl = ctrldom;
    }

    public String eliminarItem() {
        System.out.println("Que item quieres eliminar? (Indica su id)");
        Scanner scanner = new Scanner(System.in);
        String id_it = scanner.nextLine();
        boolean b_i = CtrlDominio.Instance().borraItem(id_it);
        if(b_i){
            return id_it;
        }
        else {
            return "null";
        }
    }

    public String crea_item() {

        System.out.println("Indique cuantos atributos tiene su nuevo item:");
        Scanner scanner= new Scanner(System.in);
        int num = scanner.nextInt();
        int naux = num;
        ArrayList<String> ats = new ArrayList<>();
        ArrayList<String> valores = new ArrayList<>();
        int id = CtrlDominio.Instance().getMaxIDItem();
        ats.add("id");
        System.out.println("El id sera: " + id);
        valores.add(String.valueOf(id));
        scanner = new Scanner(System.in);
        while(naux > 0){
            System.out.println("Indica el atributo" + (num-naux) + ":");
            String at = scanner.nextLine();
            ats.add(at);
            System.out.println("Indica el valor del atributo" + (num-naux) + ":");
            String val = scanner.nextLine();
            valores.add(val);
            --naux;
        }
        String id_str = String.valueOf(id);
        CtrlDominio.Instance().creaItem(id_str, ats, valores);
        System.out.println("NUEVO ITEM MAX = " + CtrlDominio.Instance().getMaxIDItem());
        return String.valueOf(id);
    }

    public String editar_item(){
        System.out.println("Que item quieres editar? (Indique su id)");
        Scanner scanner = new Scanner(System.in);
        String s = scanner.nextLine();
        Item i = CtrlDominio.Instance().buscar_item(s);
        if(i != null){
            System.out.println("Atributos:");
            for(int j = 0; j < i.getCabeceras_atributos().size(); ++j){
                System.out.println(j+"- "+i.getCabeceras_atributos().get(j) + ": " + i.getValors_atributs().get(j));
            }
            System.out.println("Que indicador de atributo quieres editar:");
            System.out.println("(escribe -1 cuando quieras dejar de editar atributos)");
            scanner = new Scanner(System.in);
            int it = scanner.nextInt();
            while(it != -1) {
                if(it < i.getCabeceras_atributos().size() && it >= 0) {
                    System.out.println("Indica el nuevo valor:");
                    scanner = new Scanner(System.in);
                    String n_val = scanner.nextLine();
                    i.setValor(it, n_val);
                }
                else {
                    System.out.println("Indicador de atributo demasiado grande. El indicador máximo de atributo és "+ (i.getCabeceras_atributos().size()-1));
                }
                System.out.println("Que indicador de atributo quieres editar:");
                System.out.println("(escribe -1 cuando quieras dejar de editar atributos)");
                scanner = new Scanner(System.in);
                it = scanner.nextInt();
            }
        }
        else {
            System.out.println("El item que intenta buscar no existe.");
            return "null";
        }
        return i.getID();
    }

}

