package project;

import java.util.ArrayList;

public class HybridApproaches extends Algoritmos {

    public HybridApproaches() { }

    private ArrayList<Item> interseccion_arraylist(ArrayList<Item> a, ArrayList<Item> b) {

        ArrayList<Item> interseccion = new ArrayList<>();
        for(Item itemA : a) {
            if(b.contains(itemA)) interseccion.add(itemA);  // esta en las dos listas de recomendaciones
        }

        return interseccion;    // se devuelve la interseccion de las dos listas de recomendaciones
    }


    private ArrayList<Item> union_arraylists (ArrayList<Item> a, ArrayList<Item> b) {

        ArrayList<Item> union = new ArrayList<>();
        union.addAll(a);
        union.addAll(b);

        return union;
    }

    public ArrayList<Item> hybrid_approaches (ArrayList<Item> recomendacionesCF, ArrayList<Item> recomendacionesCBF, int k) {

        //llamada al metodo de interseccion
        ArrayList<Item> interseccion = interseccion_arraylist(recomendacionesCF, recomendacionesCBF);
        ArrayList<Item> union = union_arraylists(recomendacionesCF, recomendacionesCBF);

        // Se anaden las recomendaciones en el arrayList de resultados
        // Se priorizan mas las recomendaciones que estan en la interseccion que en la de union
        ArrayList<Item> resultado = new ArrayList<>();
        for(int i=0; i<interseccion.size() && k > 0; i++) {
            resultado.add(interseccion.get(i));
            k--;
        }

        for(int i=0; i<union.size() && k > 0; i++) {
            if(resultado.contains(union.get(i))) continue;
            resultado.add(union.get(i));
            k--;
        }

        return resultado;
    }



}