package project;

import java.util.ArrayList;
import java.util.Scanner;

public class UsuarioActivo extends Perfil
{
    private ArrayList<Valoracion> valoraciones;

    //Constructor por defecto.
    public UsuarioActivo() {
        super.setNickname("");
        super.setPassword("");
        super.setID("");
        this.ctrl = null;
        this.valoraciones = new ArrayList<>();
    }

    //Constructor completo
    public UsuarioActivo(String Nick, String id, String password, CtrlDominio ctrldom) {
        super.setNickname(Nick);
        super.setPassword(password);
        super.setID(id);
        this.ctrl = ctrldom;
        this.valoraciones = new ArrayList<>();
    }

    //GETTERS
    public ArrayList<Valoracion> getValoraciones() { return this.valoraciones; }

    //SETTERS
    public void setValoraciones(ArrayList<Valoracion> Valoraciones){
        this.valoraciones = Valoraciones;
    }

    //CONSULTORA VALORACIONES
    public void consulta_valoraciones(){
        for(Valoracion v: valoraciones){
            System.out.println("Item " + v.get_Item().getID()+" > "+v.getValor() + " sobre " + CtrlDominio.Instance().getMaxRating());
        }
    }

    public void eliminar_valoracion(Item item) {
        for(Valoracion valoracion : valoraciones) {
            if(valoracion.get_Item().equals(item)) {
                valoraciones.remove(valoracion);
                return;
            }
        }
    }

    public void addValoracion(Valoracion val) {
        this.valoraciones.add(val);
    }

}

