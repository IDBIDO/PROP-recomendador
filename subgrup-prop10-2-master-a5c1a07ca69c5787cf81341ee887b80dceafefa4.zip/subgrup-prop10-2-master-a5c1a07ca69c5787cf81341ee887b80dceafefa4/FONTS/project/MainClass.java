package project;
import persistencia.CtrlPersistencia;
import presentacion.CtrlPresentacion;

import javax.swing.*;


import java.util.*;

public class MainClass {

    public static void main(String[] args) {

        CtrlPresentacion presentacion = new CtrlPresentacion();

    }
}
