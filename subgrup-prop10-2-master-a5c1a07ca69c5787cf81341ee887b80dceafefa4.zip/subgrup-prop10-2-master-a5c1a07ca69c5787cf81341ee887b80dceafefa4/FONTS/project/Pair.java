package project;

public class Pair<T> {

    T x;
    double y;

    public Pair() {

    }

    public Pair(T x, Double y){
        this.x =  x;
        this.y =  y;
    }

    //consultora
    public T get_first() {
        return x;
    }

    public Double get_second() {
        return y;
    }

}
