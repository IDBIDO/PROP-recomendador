package project;
import java.util.ArrayList;

public class Cluster {

    private ArrayList<String> usuarios;     // usuarios del cluster

    public Cluster() {
        this.usuarios = new ArrayList<>();
    }

    public boolean existUser(String userID) { return usuarios.contains(userID); }

    public void añadirUsuario(String userID) { this.usuarios.add(userID); }

    public int size() { return this.usuarios.size(); }

    public String get(int index) {
        try {
            return this.usuarios.get(index);
        } catch (NullPointerException npe) {
            System.out.println("Null pointer exception, no se puede acceder a la posicion " + index + " con longitud del cluster " + this.size());
            return null;
        }
    }

    public ArrayList<String> getUsers() { return this.usuarios; }

    public void removeUser(String userID) {
        if(existUser(userID)) {
            this.usuarios.remove(userID);
        } else return;  // si no existe el usuario en el cluster el metodo no hace nada
    }

}