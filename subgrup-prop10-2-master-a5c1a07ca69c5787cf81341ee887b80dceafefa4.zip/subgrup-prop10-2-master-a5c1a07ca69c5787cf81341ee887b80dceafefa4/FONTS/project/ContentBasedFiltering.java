package project;

// region Flujo del algoritmo
//  ContentBased Filtering => K-NeareastNeighbord => Output
// endregion

import java.util.*;

public class ContentBasedFiltering extends Algoritmos {



    public ContentBasedFiltering() {


    }


    public  boolean repetido (ArrayList< Pair<Item> > mod, String x, int j) {

        int i = 0;
        boolean r = false;
        while (!r && i < j) {
            if (mod.get(i).get_first().getID() == x) r = true;
            ++i;
        }

        return r;
    }

    public void valor_min (ArrayList< Pair<Item> > min, ArrayList< Pair<Item> > nuevo, ArrayList< Pair<Item> > mod) {


        int i, j, cont;
        i = j = cont = 0;
        boolean repeated = false;
        while (i+j < nuevo.size()) {

            if (min.get(i).get_second() <= nuevo.get(j).get_second() ) {

                if (!repetido(mod, min.get(i).get_first().getID(), cont)) {
                    mod.set(cont, new Pair<Item>(min.get(i).get_first(), min.get(i).get_second()));
                }
                else repeated = true;
                ++i;
            }

            else  {
                if (!repetido(mod, nuevo.get(j).get_first().getID(), cont)) {
                    mod.set(cont, new Pair<Item>(nuevo.get(j).get_first(), nuevo.get(j).get_second()));
                }
                else repeated = true;
                ++j;
            }
            if (!repeated) ++cont;
            repeated = false;
        }

    }


    public ArrayList<Item> content_based (ArrayList<Item> favoritos, ArrayList<Item> candidatos, Integer k) {

        ArrayList< Pair<Item> >  kmin = K_nearest_neighbours.k_nearest_neighbours(favoritos.get(0), candidatos, k);

        for (int i = 1; i < favoritos.size(); ++i) {
            ArrayList< Pair<Item> >  aux = K_nearest_neighbours.k_nearest_neighbours(favoritos.get(i), candidatos, k);
            valor_min(kmin, aux, kmin);

        }

        ArrayList<Item> r = new ArrayList<>(k);
        for (int i = 0; i < k; ++i) {
            r.add(i, kmin.get(i).get_first());
        }

        return r;
    }

}
