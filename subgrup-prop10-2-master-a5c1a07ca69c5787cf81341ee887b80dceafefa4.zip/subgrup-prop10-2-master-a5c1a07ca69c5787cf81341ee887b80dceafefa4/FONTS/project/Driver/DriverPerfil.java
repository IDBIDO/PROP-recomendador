package project.Driver;

import project.CtrlDominio;
import project.Perfil;

import java.util.Scanner;

public class DriverPerfil {
    private static Scanner scanner;

    private static int generarMenu(String cabeceraMenu, String ...opciones) {

        scanner = new Scanner(System.in);
        int op;
        int i;

        do {
            i = 1;
            for (String opcion : opciones) {
                System.out.println("\t" + i + ". " + opcion);
                i++;
            }

            try {
                op = scanner.nextInt();
            } catch ( Exception InputMismatchException) {
                System.out.println("Introduce un numero.");
                return 0;
            }

        } while(op < 1 || op >= i);

        return op;
    }

    public static void ConstructorTest(String Nick, String id, String password, CtrlDominio ctrldom){
        System.out.println("Test prueba constructora Perfil:");
        Perfil act = new Perfil(Nick,id,password,ctrldom);
        System.out.println("Valores creados: ");
        System.out.println("Perfil.Nick = " + act.getNickname());
        System.out.println("Perfil.id = " + act.getID());
        if(act.getID().equals(id) && act.getNickname().equals(Nick)) System.out.println("Funciona correctamente.");
        else System.out.println("Error: Datos incorrectos");
    }

    public static void main(String[] args) {
        scanner = new Scanner(System.in);
        int opcion;
        while(true){
            System.out.println("\tTESTING PERFIL\n");
            opcion = generarMenu("Elija una opcion:", "Test Constructora Perfil", "Salir");

            switch (opcion) {
                case 1:
                    CtrlDominio dom = new CtrlDominio();
                    String nick;
                    String id = "777";
                    String password;
                    scanner = new Scanner(System.in);
                    System.out.println("Indique un Nickname");
                    nick = scanner.nextLine();
                    System.out.println("Indique un password");
                    password = scanner.nextLine();
                    ConstructorTest(nick, id, password, dom);
                    break;
                case 2:
                    System.out.println("Saliendo del sistema.");
                    return;

                default:
                    return;
            }
        }
    }
}
