package project.Driver;

import project.CtrlDominio;
import project.Item;
import project.TipoItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class DriverItem {

    public static void testgetID() {
        System.out.println("Consultar ID del Item:");
        Item a = new Item();
        a.setID("123");
        String id = a.getID();
        if (id.equals("123"))
            System.out.println("El ID se ha consultado correctamente y es "+id+".");
        else
            System.out.println("El ID no se ha consultado correctamente.");
    }

    public static void testgetValors(){
        System.out.println("Consultar valores del Item:");
        ArrayList<String> a = new ArrayList<String>(Arrays.asList("1","2","3"));
        Item it = new Item();
        it.setValors_atributs(a);
        boolean b = true;
        for(int i=0; i<a.size();i++){
            if (!(it.getValors_atributs().get(i)).equals(a.get(i))) b = false;
        }
        if(b) System.out.println("Los valores se han consultado correctamente.");
        else System.out.println("Los valores no se han consultado correctamente.");
    }

    public static void testgetValor(){
        System.out.println("Consultar un valor del Item:");
        ArrayList<String> a = new ArrayList<String>(Arrays.asList("1","2","3","4"));
        Item it = new Item();
        it.setValors_atributs(a);
        if(it.getValor(2).equals("3")) System.out.println("El valor se ha consultado correctamente.");
        else System.out.println("El valor no se ha consultado correctamente.");
    }

    public static void getcabecera(){
        System.out.println("Consultar cabecera del Item:");
        ArrayList<String> test = new ArrayList<String>(Arrays.asList("autor", "genero", "sinopsis"));
        System.out.println("Consultar cabeceras de Tipo de Item:");
        TipoItem a = new TipoItem();
        a.addCabecera(test);
        boolean b = true;
        for(int i=0; i<test.size();i++){
            if (a.getCabecera().get(i) != test.get(i)) b = false;
        }
        if(b) System.out.println("La cabecera se ha consultado correctamente.");
        else System.out.println("La cabecera no se ha consultado correctamente.");
    }

    public static void gettipo(){
        System.out.println("Consultar tipo de Item:");
        ArrayList<String> valors = new ArrayList<String>(Arrays.asList("pepe","terror","cosas cosas"));
        ArrayList<String> cabecera = new ArrayList<String>(Arrays.asList("autor","genero","sinopsis"));
        Item it = new Item("123", valors, cabecera);
        double a = it.detectaTipo(CtrlDominio.Instance().getTiposItem());
        if (it.getTipoItem() != null)  System.out.println("El tipo se ha consultado correctamente.");
        else System.out.println("EL tipo no se ha consultado correctamente.");

    }

    public static void testsetid(){
        System.out.println("Setear ID del Item:");
        System.out.println("Introducir ID del Tipo de Item:");
        Scanner scanner = new Scanner(System.in);
        Item a = new Item();
        String id = scanner.next();
        a.setID(id);
        if (a.getID().equals(id)) System.out.println("El id se ha seteado correctamente");
        else
            System.out.println("El id no se ha seteado correctamente");
    }

    public static void testsetValors(){
        System.out.println("Setear valores del Item:");
        ArrayList<String> valores = new ArrayList<String>(Arrays.asList("1","2","3"));
        ArrayList<String> cabecera = new ArrayList<String>(Arrays.asList("autor","genero","sinopsis"));
        Item it = new Item();
        it.setValors_atributs(valores);
        if (it.getValors_atributs() != null) System.out.println("Los valores se han añadido correctamente.");
        else System.out.println("Los valores no se han añadido correctamente.");
    }

    public static void testsetvalor(){
        System.out.println("Setear un valor del Item:");
        ArrayList<String> valores = new ArrayList<String>(Arrays.asList("1","2","3"));
        ArrayList<String> cabecera = new ArrayList<String>(Arrays.asList("autor","genero","sinopsis"));
        int i = 1;
        String nuevo = "3";
        Item it = new Item("123",valores, cabecera);
        it.setValor(i,nuevo);
        if (it.getValor(i).equals("3")) System.out.println("El valor se ha añadido correctamente.");
        else System.out.println("El valor no se ha añadido correctamente");
    }

    public static void setCabeceras(){
        System.out.println("Setear cabeceras del Item:");
        ArrayList<String> valores = new ArrayList<String>(Arrays.asList("1","2","3"));
        ArrayList<String> cabecera = new ArrayList<String>(Arrays.asList("autor","genero","sinopsis"));
        Item it = new Item();
        it.setCabeceras_atributos(cabecera);
        if (it.getCabeceras_atributos() != null) System.out.println("La cabecera se ha añadido correctamente.");
        else System.out.println("La cabecera no se ha añadido correctamente.");
    }

    public static void Constructora(){
        Scanner scanner1 = new Scanner(System.in);
        Scanner scanner2 = new Scanner(System.in);
        ArrayList<String> vals = new ArrayList<String>();
        ArrayList<String> cabs = new ArrayList<String>();

        System.out.println("Creacion de Item: ");
        System.out.println("Indicar id: ");
        String id = scanner1.next();

        System.out.println("Indica todas las cabeceras y pulsa a para continuar: ");
        String c;
        while (scanner1.hasNext()){
            c = scanner2.next();
            cabs.add(c);
            if(c.equals("a")) break;
        }

        System.out.println("Indicar valores y pulsa a para continuar: ");
        String cc;
        while (scanner1.hasNext()) {
            cc = scanner2.next();
            cabs.add(cc);
            if(cc.equals("a")) break;
        }

        Item it = new Item(id,vals, cabs);

        System.out.println("Item se ha creado correctamente.");

    }

    public static void detecta(){
        System.out.println("Detectar tipo de item: ");
        Scanner sc = new Scanner(System.in);
        CtrlDominio ctrl = CtrlDominio.Instance();

        ArrayList<String> cabecera1 = new ArrayList<String>(Arrays.asList("director","genero","pais"));
        CtrlDominio.Instance().add_TipoItem(cabecera1, "Peliculas");
        ArrayList<String> cabecera2 = new ArrayList<String>(Arrays.asList("autor","pags","año"));
        CtrlDominio.Instance().add_TipoItem(cabecera2, "Libros");
        ArrayList<ArrayList<String>> cabeceras = new ArrayList<>();
        cabeceras.add(cabecera1);
        cabeceras.add(cabecera2);

        System.out.println("Tenemos los tipos item Peliculas y Libros con las siguientes cabeceras:");
        int i=0;
        for(TipoItem tt : ctrl.getTiposItem()){
            System.out.println(tt.getNombre_tipo() + "\t" + cabeceras.get(i));
            i++;
        }


        System.out.println("Indica la cabecera del item a testear y pulsa 'FIN' como ultimo parametro para terminar: ");
        String next;
        ArrayList<String> cabs = new ArrayList<String>();

        while (sc.hasNext()){
            next = sc.next();
            if(next.equals("FIN")) break;
            cabs.add(next);
        }

        Item new_it= new Item("", new ArrayList<>(),cabs);

        double afinidad = new_it.detectaTipo(ctrl.getTiposItem());
        System.out.println("El tipo de item detectado ha sido el de " + new_it.getTipoItem().getNombre_tipo());
        System.out.println("El tipo detectado tiene una afinidad de "+afinidad+".");
        System.out.println("Siempre que la afinidad sea menor del 85% el programa crea un nuevo tipo de item para ese item, en este test no se enseña porque no se usara en adelante.");

    }

    public static void caracteres(){
        System.out.println("Comparar caracteres: ");
        Scanner sc = new Scanner(System.in);
        System.out.println("Inserta dos caracteres: ");
        String a = sc.next();
        String b = sc.next();
        ArrayList<String> valores = new ArrayList<String>(Arrays.asList(a,b));
        ArrayList<String> cabecera = new ArrayList<String>(Arrays.asList("char1","char2"));
        Item it = new Item("1",valores,cabecera);

        int res = it.CaracteresSimilares(it.getValor(0), it.getValor(1));

        if (res==0) System.out.println("Los caracteres son iguales.");
        else System.out.println("Los caracteres no son iguales");

    }

    public static void main(String args[]){
        Constructora();
        System.out.println();
        testgetID();
        System.out.println();
        testgetValors();
        System.out.println();
        testgetValor();
        System.out.println();
        getcabecera();
        System.out.println();
        gettipo();
        System.out.println();
        testsetid();
        System.out.println();
        testsetValors();
        System.out.println();
        testsetvalor();
        System.out.println();
        setCabeceras();
        System.out.println();
        detecta();
        System.out.println();
        caracteres();
        System.out.println();
    }


}
