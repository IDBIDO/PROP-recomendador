package project.Driver;


import project.ContentBasedFiltering;
import project.Distancias;
import project.Item;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import static org.mockito.Mockito.mock;

public class Driver_content_based {

    public static void inicio() {
        System.out.println("Programa de pruebas del metodo content_based de ContentBasedFiltering");
        System.out.println("Parametros de entrada: ");
        System.out.println("   Item[] ob");
        System.out.println("   Item[] lista");
        System.out.println("   int k");
        System.out.println("El metodo calcula las distancias de todo item ob a todo item de lista y retorna los k con distancia menor\n");

        System.out.println("formato entrada para Item: [id_item] [atributo1] [atributo2] ... [atributon]");
        System.out.println("Formato para entradas de datos:");
        System.out.println("Primera linea: [numero atriburos] [numero item de lista] [k]");
        System.out.println("Segunda linea: [Entrada del Item x]");
        System.out.println("Tercera linea +: [Entrada de los Items de lista]");

    }

    public static void main(String[] args) throws IOException {
    boolean repetir = true;

    while(repetir) {
        File f = new File("../EXE/DriverContentBased/Sample_conted_based.txt");
        Scanner sc = new Scanner(f);

        int k = 0;
        int n1 = 0;
        int n2 = 0;
        int n_atributos = 0;

        n_atributos = sc.nextInt();
        n1 = sc.nextInt();
        n2 = sc.nextInt();
        k = sc.nextInt();

        ArrayList<String> arr_cabecera = mock(ArrayList.class);
        String id = new String();

        Item l1[] = new Item[n1];
        Item l2[] = new Item[n2];

        //lectura l1
        for (int i = 0; i < n1; ++i) {

            String idd = sc.next();
            ArrayList<String> aa = new ArrayList<>(n_atributos);
            for (int j = 0; j < n_atributos; ++j) {
                aa.add(sc.next());
            }

            Item x = new Item(idd, aa, arr_cabecera);
            l1[i] = x;
        }

        //lectura l2
        for (int i = 0; i < n2; ++i) {

            String idd = sc.next();
            ArrayList<String> aa = new ArrayList<>(n_atributos);
            for (int j = 0; j < n_atributos; ++j) {
                aa.add(sc.next());
            }

            Item x = new Item(idd, aa, arr_cabecera);
            l2[i] = x;
        }

        //Mensages para comprobaciones de resultado
        System.out.println("Check Datas: ");
        for (int i = 0; i < n1; ++i) {
            System.out.println(l1[i].getID() + " " + l1[i].getValors_atributs());

        }
        for (int i = 0; i < n2; ++i) {
            System.out.println(l2[i].getID() + " " + l2[i].getValors_atributs());

        }

        System.out.println("\n");
        System.out.println("Calculo de distancias: ");
        for (int i = 0; i < n1; ++i) {
            System.out.println(l1[i].getID() + " " + l1[i].getValors_atributs());
            for (int j = 0; j < n2; ++j) {
                System.out.println("Distancia al Item " + l2[j].getID() + ": " + Distancias.distancia_dos_items(l2[j].getValors_atributs(), l1[i].getValors_atributs()));
            }

        }

        //Conversion de Array a ArrayList para hacer llamada content based
        ArrayList<Item> a = new ArrayList<>(l1.length);
        for (int i = 0; i < l1.length; ++i) {
            a.add(i, l1[i]);
        }

        ArrayList<Item> b = new ArrayList<>(l2.length);
        for (int i = 0; i < l2.length; ++i) {
            b.add(i, l2[i]);
        }


        ContentBasedFiltering c = new ContentBasedFiltering();
        ArrayList<Item> r = c.content_based(a, b, k);


        System.out.println("k Items no repetidos con menor distancia: ");
        for (int i = 0; i < r.size(); ++i) {
            System.out.println(r.get(i).getID());
        }
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nQuieres empezar otra prueba? (si/no)");
        System.out.println("En caso que si, tiene que modificar el archivo de entrada de datos");
        String option = scanner.next();

        if (option.equals("no")) repetir = false;

    }
    }



}
