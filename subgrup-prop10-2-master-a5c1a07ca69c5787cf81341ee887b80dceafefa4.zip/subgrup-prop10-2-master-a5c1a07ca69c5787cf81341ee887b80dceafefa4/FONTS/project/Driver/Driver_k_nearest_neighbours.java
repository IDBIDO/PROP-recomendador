package project.Driver;

import project.Distancias;
import project.Item;
import project.K_nearest_neighbours;
import project.Pair;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import static org.mockito.Mockito.mock;

public class Driver_k_nearest_neighbours {

    public static void inicio() {
        System.out.println("Programa de pruebas del k_nearest_neighbours para ContentBasedFiltering");
        System.out.println("Parametros de entrada: ");
        System.out.println("1.   Item x");
        System.out.println("2.   Item[] lista");
        System.out.println("3.   int k (numero de vecinos que quiere general)");

        System.out.println("Decripcion: ");
        System.out.println("El metodo calcula las distancias de x a todo item de lista y retorna los k con distancia menor\n");

        System.out.println("Formato para entradas de datos:");
        System.out.println("Primera linea: [numero atriburos] [numero item de lista] [k]");
        System.out.println("Segunda linea: [Entrada del Item x]");
        System.out.println("Despues de segunda linia: [Entrada de los Items de lista]");

        System.out.println("Formato entrada para Item: [id_item] [atributo1] [atributo2] ... [atributon]");

    }


    public static void main(String[] args) throws IOException {


        boolean repetido = true;

        while(repetido) {
            inicio();

            //lectura de input
            File f = new File("../EXE/DriverKNearestNeighbours/Sample_k_nearest.txt");
            Scanner sc = new Scanner(f);

            int k = 0;
            int n = 0;
            int n_atributos = 0;

            n_atributos = sc.nextInt();
            n = sc.nextInt();
            k = sc.nextInt();

            ArrayList<String> arr_cabecera = mock(ArrayList.class);
            String id = new String();
            ArrayList<String> a = new ArrayList<>(n_atributos);
            Item ob = new Item();
            Item l[] = new Item[n];

            boolean primero = true;
            int cont = 0;

            id = sc.next();
            for (int i = 0; i < n_atributos; ++i) {
                a.add(sc.next());
            }
            ob = new Item(id, a, arr_cabecera);


            for (int i = 0; i < n; ++i) {

                String idd = sc.next();
                ArrayList<String> aa = new ArrayList<>(n_atributos);
                for (int j = 0; j < n_atributos; ++j) {
                    aa.add(sc.next());
                }

                Item x = new Item(idd, aa, arr_cabecera);
                l[i] = x;
            }



            System.out.println("Primer item " + ob.getID() + " con atributos: " + ob.getValors_atributs());

            for (int i = 0; i < n; ++i) {
                System.out.println("Item " + l[i].getID() + " con atributos: " + l[i].getValors_atributs());
                System.out.println("-Distancia al primer Item: " + Distancias.distancia_dos_items(ob.getValors_atributs(), l[i].getValors_atributs()));
            }

            ArrayList<Item> ll = new ArrayList<>(l.length);
            for (int q =0; q < l.length; ++q) {
                ll.add(q, l[q]);
            }

            ArrayList<Pair<Item>> r = new ArrayList<>(k);
            r = K_nearest_neighbours.k_nearest_neighbours(ob, ll, k);
            System.out.println(" ");
            System.out.println("Resultados: [ID_Item] [Distancia al primer Item]");
            for (int i = 0; i < k; ++i) {
                System.out.println(r.get(i).get_first().getID() + " " + r.get(i).get_second());
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("\nQuieres empezar otra prueba? (si/no)");
            System.out.println("En caso que si, tiene que modificar el archivo de entrada de datos con la nueva entrada que quiere probar");
            String option = scanner.next();

            if (option.equals("no")) repetido = false;

        }
    }


}
