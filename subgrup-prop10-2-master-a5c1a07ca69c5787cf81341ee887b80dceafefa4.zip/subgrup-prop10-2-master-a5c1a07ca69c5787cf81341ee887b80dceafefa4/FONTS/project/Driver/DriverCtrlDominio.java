package project.Driver;

import project.CtrlDominio;
import project.Item;
import project.UsuarioActivo;
import project.Valoracion;

import java.util.ArrayList;
import java.util.Scanner;


public class DriverCtrlDominio {

    private static Scanner scanner;

    private static int generarMenu(String cabeceraMenu, String ...opciones) {

        scanner = new Scanner(System.in);
        int op;
        int i;

        do {
            i = 1;
            for (String opcion : opciones) {
                System.out.println("\t" + i + ". " + opcion);
                i++;
            }

            try {
                op = scanner.nextInt();
            } catch ( Exception InputMismatchException) {
                System.out.println("Introduce un numero.");
                return 0;
            }

        } while(op < 1 || op >= i);

        return op;
    }

    public static void EncriptacionTest(String pass){
        System.out.println("Test Encriptacion contraseña.");
        String enc = CtrlDominio.Instance().CaesarCipherEncrypt(pass);
        System.out.println("Encriptada: " + enc);
        if(CtrlDominio.Instance().CaesarCipherDecrypt(enc).equals(pass)) System.out.println("Funciona correctament.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void DesencriptacionTest(String pass_enc){
        System.out.println("Test desencriptacion contraseña.");
        String decoded = CtrlDominio.Instance().CaesarCipherDecrypt(pass_enc);
        System.out.println("Desencriptada: " + decoded);
        if(!CtrlDominio.Instance().CaesarCipherEncrypt(decoded).contains(decoded)) System.out.println("Funciona correctament.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void mediaValsTest(ArrayList<Valoracion> vals, double media){
        System.out.println("Test media valoraciones:");
        UsuarioActivo p = new UsuarioActivo();
        p.setValoraciones(vals);
        CtrlDominio.Instance().assigna_perfil(p);
        if(media == CtrlDominio.Instance().getMediaValoraciones()) System.out.println("Funciona correctamente.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void addTipoItemTest(ArrayList<String> cabecera, String nombre){
        System.out.println("Test add Tipo Item:");
        int tam_inic = CtrlDominio.Instance().getTiposItem().size();
        CtrlDominio.Instance().add_TipoItem(cabecera, nombre);
        if(tam_inic != CtrlDominio.Instance().getTiposItem().size()) System.out.println("Funciona correctamente.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void creaItemTest(String id, ArrayList<String> atributos, ArrayList<String> valores) {
        CtrlDominio.Instance().creaItem(id,atributos,valores);
        if(CtrlDominio.Instance().existe_item(id)) System.out.println("Funciona correctamente.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void creaValoracionTest(String idUser, String idItem, double rating) {
        CtrlDominio.Instance().addValoracion(new  Valoracion(CtrlDominio.Instance().getItembyID(idItem), rating, idUser));
        boolean b = false;
        for(Valoracion v: CtrlDominio.Instance().getValoraciones()){
            if(v.getUser().equals(idUser) && v.get_Item().equals(idItem) && v.getValor() == rating) {
                b = true;
                break;
            }
        }
        if(b) System.out.println("Funciona correctamente.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void existeItemTest(String idItem){
        if(CtrlDominio.Instance().existe_item(idItem)) System.out.println("Funciona correctamente.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void removeItemTest(Item i){
        int n_its = CtrlDominio.Instance().getItems().size();
        CtrlDominio.Instance().removeItem(i);
        if(n_its != CtrlDominio.Instance().getItems().size()) System.out.println("Funciona correctamente.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void buscarItemTest(Item i){
        if(CtrlDominio.Instance().buscar_item(i.getID()).getID().equals(i.getID()))  System.out.println("Funciona correctamente.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void getMaxIDItemTest(int max_id){
        if(max_id != CtrlDominio.Instance().getMaxIDItem()) System.out.println("Funciona correctamente.");
        else System.out.println("ERROR en la funcion.");
    }

    public static void borraItemTest(String id_it){
        int n_its = CtrlDominio.Instance().getItems().size();
        boolean b = CtrlDominio.Instance().borraItem(id_it);
        if(b){
            if(n_its != CtrlDominio.Instance().getItems().size()) System.out.println("Funciona correctamente.");
            else System.out.println("ERROR en la funcion.");
        }
        else System.out.println("ITEM NO EXISTE");
    }

    public static void main(String[] args) {
        scanner = new Scanner(System.in);
        int opcion;


        while (true){
            System.out.println("\tTESTING CONTROLADOR DE DOMINIO\n");
            opcion = generarMenu("Elija una opcion:","Encriptacion", "Desencriptacion","Media Valoraciones", "Añade Tipo Item", "Crea Items", "Crea Valoraciones", "Existe Item", "Elimina Item", "Busca Item", "Max ID de Item" , "Elimina item(ID)" ,"Salir");
            switch (opcion) {
                case 1:
                    scanner = new Scanner(System.in);
                    System.out.println("Indica palabra a encriptar:");
                    String pass = scanner.nextLine();
                    EncriptacionTest(pass);
                    break;
                case 2:
                    scanner = new Scanner(System.in);
                    System.out.println("Escribe contraseña para desencriptar:");
                    String pass_toe = scanner.nextLine();
                    String pass_enc = CtrlDominio.Instance().CaesarCipherEncrypt(pass_toe);
                    System.out.println("Encriptada: " + pass_enc);
                    DesencriptacionTest(pass_enc);
                    break;
                case 3:
                    scanner = new Scanner(System.in);
                    ArrayList<Valoracion> vals = new ArrayList<>();
                    System.out.println("Cuantas valoraciones quieres poner?");
                    int v = scanner.nextInt();
                    double sum = 0;
                    for (int i = 1; i <= v; ++i) {
                        System.out.println("Indica valoracion:");
                        double d = scanner.nextFloat();
                        sum += d;
                        vals.add(new Valoracion(CtrlDominio.Instance().getItems().get(0),d,String.valueOf(i)));
                    }
                    double media = sum / v;
                    mediaValsTest(vals, media);
                    break;
                case 4:
                    scanner = new Scanner(System.in);
                    System.out.println("Indica el tamaño de tu cabecera:  (Numero de atributos)");
                    int n_at = scanner.nextInt();
                    ArrayList<String> cab = new ArrayList<>();
                    for (int i = 0; i < n_at; ++i) {
                        scanner = new Scanner(System.in);
                        System.out.println("Indica nuevo atributo del tipo:");
                        String a = scanner.nextLine();
                        cab.add(a);
                    }
                    System.out.println("Indica el nombre del tipo:");
                    String nombre = scanner.nextLine();
                    addTipoItemTest(cab, nombre);
                    break;
                case 5:
                    scanner = new Scanner(System.in);
                    System.out.println("Cuantos atributos tiene el item?");
                    int ats = scanner.nextInt();
                    ArrayList<String> atributos = new ArrayList<>();
                    ArrayList<String> valores = new ArrayList<>();
                    for (int i = 0; i < ats; ++i) {
                        scanner = new Scanner(System.in);
                        System.out.println("Indica el nombre de atributo:");
                        String a = scanner.nextLine();
                        atributos.add(a);
                        System.out.println("Indica el valor del atributo:");
                        String val = scanner.nextLine();
                        valores.add(val);
                    }
                    creaItemTest("3214123", atributos, valores);
                    break;
                case 6:
                    scanner = new Scanner(System.in);
                    System.out.println("Indica Usuario(id):");
                    String idUs = scanner.nextLine();
                    System.out.println("Indica Item(id):");
                    String idIt = scanner.nextLine();
                    System.out.println("Indica rating: (0.5-5.0)");
                    double rat = scanner.nextFloat();
                    creaValoracionTest(idUs, idIt, rat);
                    break;
                case 7:
                    scanner = new Scanner(System.in);
                    ArrayList<String> cabec = new ArrayList<>();
                    ArrayList<String> valor = new ArrayList<>();
                    System.out.println("Indica id:");
                    String idItem = scanner.nextLine();
                    CtrlDominio.Instance().creaItem(idItem, cabec, valor);
                    existeItemTest(idItem);
                    break;
                case 8:
                    System.out.println("Elimina item");
                    scanner = new Scanner(System.in);
                    ArrayList<String> cabec2 = new ArrayList<>();
                    ArrayList<String> valor2 = new ArrayList<>();
                    System.out.println("Indica id:");
                    String idI = scanner.nextLine();
                    CtrlDominio.Instance().creaItem(idI, cabec2, valor2);
                    Item prueba = CtrlDominio.Instance().getItems().get(0);
                    removeItemTest(prueba);
                    break;
                case 9:
                    System.out.println("Busca item");
                    scanner = new Scanner(System.in);
                    ArrayList<String> cabec3 = new ArrayList<>();
                    ArrayList<String> valor3 = new ArrayList<>();
                    System.out.println("Indica id:");
                    String idI2 = scanner.nextLine();
                    CtrlDominio.Instance().creaItem(idI2, cabec3, valor3);
                    Item it = CtrlDominio.Instance().getItems().get(0);
                    buscarItemTest(it);
                    break;
                case 10:
                    scanner = new Scanner(System.in);
                    System.out.println("Indica cuantos items quieres crear para probar:");
                    int its = scanner.nextInt();
                    ArrayList<String> cab_vac = new ArrayList<>();
                    ArrayList<String> vals_vac = new ArrayList<>();
                    for (int i = 0; i < its; ++i) {
                        scanner = new Scanner(System.in);
                        System.out.println("Indica id: (int)");
                        String id = scanner.nextLine();
                        CtrlDominio.Instance().creaItem(id, cab_vac, vals_vac);
                    }
                    System.out.println("Indica cual es el id más grande:");
                    int max_id = scanner.nextInt();
                    getMaxIDItemTest(max_id);
                    break;
                case 11:
                    scanner = new Scanner(System.in);
                    ArrayList<String> cabec_vac = new ArrayList<>();
                    ArrayList<String> valores_vac = new ArrayList<>();
                    System.out.println("Indica el id del item que quieres borrar:");
                    String id_item = scanner.nextLine();
                    CtrlDominio.Instance().creaItem(id_item, cabec_vac, valores_vac);
                    borraItemTest(id_item);
                    break;
                case 12:
                    System.out.println("Saliendo del sistema.");
                    return;
                default:
                    return;
            }
            System.out.println();
            System.out.println();
        }
    }
}
