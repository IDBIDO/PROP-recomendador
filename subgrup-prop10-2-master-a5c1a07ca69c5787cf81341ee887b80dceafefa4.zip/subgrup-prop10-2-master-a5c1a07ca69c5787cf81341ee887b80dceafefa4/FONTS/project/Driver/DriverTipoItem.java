package project.Driver;

import project.TipoItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class DriverTipoItem {

    public static void testgetNombre(){
        System.out.println("Consultar Nombre del Tipo de Item:");
        TipoItem a = new TipoItem();
        Scanner scanner = new Scanner(System.in);
        String nom = scanner.nextLine();
        a.setNombre_tipo(nom);
        String aux = a.getNombre_tipo();
        if (nom.equals(aux))
            System.out.println("El nombre se ha consultado correctamente y es "+aux+".");
        else
            System.out.println("El nombre no se ha consultado correctamente.");
    }

    public static void testgetCabeceras(){
        System.out.println("Consultar cabeceras del Tipo de Item:");
        ArrayList<String> test = new ArrayList<String>(Arrays.asList("autor", "genero", "sinopsis"));
        System.out.println("Consultar cabeceras de Tipo de Item:");
        TipoItem a = new TipoItem();
        a.addCabecera(test);
        boolean b = true;
        for(int i=0; i<test.size();i++){
            if (a.getCabecera().get(i) != test.get(i)) b = false;
        }
        if(b) System.out.println("La cabecera se ha consultado correctamente.");
        else System.out.println("La cabecera no se ha consultado correctamente.");
    }

    public static void testsetNombre(){
        System.out.println("Setear Nombre del Tipo de Item:");
        System.out.println("Introducir Nombre del Tipo de Item:");
        Scanner scanner = new Scanner(System.in);
        TipoItem a = new TipoItem();
        String nombre = scanner.nextLine();
        a.setNombre_tipo(nombre);
        if (a.getNombre_tipo().equals(nombre))
            System.out.println("El nombre se ha modificado correctamente");
        else
            System.out.println("El nombre no se ha modificado correctamente");
    }

    public static void testConstructora(){
        System.out.println("Construir Tipo de Item:");
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> cabs = new ArrayList<String>();

        System.out.println("Creacion de Tipo de Item: ");
        System.out.println("Indicar nombre: ");
        String nombre = scanner.nextLine();

        System.out.println("Indica todas las cabeceras y pulsa a para continuar: ");
        String c;
        while (scanner.hasNext()){
            c = scanner.next();
            cabs.add(c);
            if(c.equals("a")) break;
        }

        TipoItem ti = new TipoItem(nombre, cabs);
        System.out.println("TipoItem se ha creado correctamente.");

    }

    public static void testadddel(){
        System.out.println("Añadir cabecera de Tipo de Item:");
        TipoItem ti = new TipoItem();
        ArrayList<String> a = new ArrayList<String>(Arrays.asList("genero", "autor"));
        ti.addCabecera(a);
        if(ti.getCabecera().get(0) == "autor") {
            System.out.println("La cabecera añadida se ha añadido correctamente.");
            System.out.println("Eliminar cabecera de Tipo de Item:");
            ti.delCabecera("autor");
            if (ti.getCabecera().equals("genero")) System.out.println("La cabecera añadida se ha eliminado correctamente.");
            else System.out.println("La cabecera no se ha eliminado correctamente.");
        }
        else if(ti.getCabecera().get(0) == "genero") System.out.println("La cabecera no se ha ordenado correctamente.");
        else System.out.println("La cabecera no se ha añadido correctamente.");


    }

    public static void main(String args[]){
        testConstructora();
        System.out.println();
        testgetNombre();
        System.out.println();
        testgetCabeceras();
        System.out.println();
        testsetNombre();
        System.out.println();
        testadddel();
        System.out.println();
    }

}
