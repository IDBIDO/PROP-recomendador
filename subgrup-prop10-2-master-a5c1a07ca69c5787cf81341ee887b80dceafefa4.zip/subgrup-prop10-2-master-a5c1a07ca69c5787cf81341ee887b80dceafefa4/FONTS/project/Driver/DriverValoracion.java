package project.Driver;

import project.CtrlDominio;
import project.Item;
import project.UsuarioActivo;
import project.Valoracion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class DriverValoracion {

    public static void Constructora(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Creacion de Valoracion: ");
        System.out.println("Indicar usuario: ");
        String user = scanner.next();

        System.out.println("Indicar item: ");
        String item = scanner.next();

        System.out.println("Indicar valor: ");
        double val = scanner.nextDouble();

        Valoracion v = new Valoracion(CtrlDominio.Instance().getItembyID(item), val,user);

        System.out.println("Valoracion se ha creado correctamente.");

    }

    public static void getValor() {
        System.out.println("Consultar valor de Valoracion:");
        Valoracion v = new Valoracion();
        v.setValor(3);
        if (v.getValor() == 3) System.out.println("El valor se ha consultado correctamente.");
        else System.out.println("El valor no se ha consultado correctamente.");
    }

    public static void setValor() {
        System.out.println("Setea valor de Item:");
        System.out.println("Introducir valor a Item:");
        Scanner scanner = new Scanner(System.in);
        Valoracion v = new Valoracion();
        int val = scanner.nextInt();
        v.setValor(val);
        if (v.getValor() == val) System.out.println("El valor se ha seteado correctamente");
        else System.out.println("El valor no se ha seteado correctamente");
    }

    public static void getItem(){
        System.out.println("Consultar item de Valoracion: ");
        Scanner scanner = new Scanner(System.in);

        System.out.println("Indica el id del item: ");
        String id= scanner.nextLine();
        ArrayList<String> a = new ArrayList<String>(Arrays.asList("a", "b"));
        ArrayList<String> b = new ArrayList<String>(Arrays.asList("a", "b"));
        Item it = new Item(id, a,b);

        System.out.println("Indica el id de un user a añadir: ");
        String idu= scanner.nextLine();

        UsuarioActivo user = new UsuarioActivo("nick", idu, "123",null);

        System.out.println("Inserta valoracion: ");
        int val = scanner.nextInt();
        Valoracion v = new Valoracion(it,val, user.getNickname());

        if(v.get_Item().equals(id)) System.out.println("El item se ha consultado correctamente");
        else System.out.println("El item no se ha consultado correctamente");
    }

    public static void getUser(){
        System.out.println("Consultar item de Valoracion: ");
        Scanner scanner = new Scanner(System.in);

        System.out.println("Indica el id del item: ");
        String id= scanner.nextLine();
        ArrayList<String> a = new ArrayList<String>(Arrays.asList("a", "b"));
        ArrayList<String> b = new ArrayList<String>(Arrays.asList("a", "b"));
        Item it = new Item(id, a,b);

        System.out.println("Indica el id de un user a añadir: ");
        String idu= scanner.nextLine();

        UsuarioActivo user = new UsuarioActivo("nick", idu, "123",null);

        System.out.println("Inserta valoracion: ");
        int val = scanner.nextInt();
        Valoracion v = new Valoracion(it,val, user.getNickname());

        if(v.getUser().equals(id)) System.out.println("El user se ha consultado correctamente");
        else System.out.println("El user no se ha consultado correctamente");
    }

    public static void setItem(){
        System.out.println("Setea item de Valoracion: ");
        Valoracion v = new Valoracion();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Inserte id del item: ");
        String id = scanner.nextLine();
        if(CtrlDominio.Instance().existe_item(id)) v.set_item(CtrlDominio.Instance().getItembyID(id));
        else System.out.println("El item con id " + id + " no existe.");
        if(v.get_Item().equals(id)) System.out.println("El item se ha seteado correctamente");
        else System.out.println("El item no se ha seteado correctamente");
    }

    public static void main(String args[]){
        Constructora();
        System.out.println();
        getValor();
        System.out.println();
        setValor();
        System.out.println();
        getItem();
        System.out.println();
        getUser();
        System.out.println();
        setItem();
        System.out.println();
    }

}
