package project.Driver;

import persistencia.CtrlPersistencia;
import project.CtrlDominio;
import project.CollaborativeFiltering;
import project.Cluster;
import project.Item;
import project.Valoracion;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class DriverCollaborativeFiltering {

    static public CollaborativeFiltering cf;
    static private CtrlDominio ctrl;

    static private String ficheroItems, ficheroValoraciones;    // sirven para cargar ficheros de juegos de prueba del usuario

    public static void pedirJuegosDePruebas(boolean items, boolean valoraciones) {

        // PERMITE HACER TESTEO CON JUEGOS DE PRUEBA DEL USUARIO
        // si el usuario quiere cargar items propios se pasa por parametro el items igual a true
        // si el usuario quiere cargar valoraciones propias se pasa por parametro el valoraciones a true

        boolean cargarFicherosPropios;
        Scanner scanner = new Scanner(System.in);
        String fichero;
        if(items) {
            cargarFicherosPropios = false;
            System.out.println("Dinos la ruta de tu fichero de ITEMS, escribe 'Salir' para cargar los ficheros de testeo del sistema.");
            fichero = scanner.nextLine();
            while (!fichero.equals("Salir")) {
                try {
                    CtrlDominio.Instance().guardarItems(new CtrlPersistencia().importarItems(fichero));
                    cargarFicherosPropios = true;
                    ficheroItems = fichero;
                    break;
                } catch (Exception e) {
                    System.out.println("Ejemplo, para cargar el fichero 'items.csv' escribe: 'EXE/CollaborativeFiltering/itemsTesteo.csv'");
                    System.out.println("Tu fichero preferentemente deberia estar en el directorio ./EXE/CollaborativeFiltering/, prueba otra vez...");
                    fichero = scanner.nextLine();
                }
            }
            if (!cargarFicherosPropios) {
                CtrlDominio.Instance().guardarItems(new CtrlPersistencia().importarItems("../EXE/DriverCollaborativeFiltering/itemsTesteo.csv"));
                ficheroItems = "../EXE/DriverCollaborativeFiltering/itemsTesteo.csv";
            }
        } else {
            CtrlDominio.Instance().guardarItems(new CtrlPersistencia().importarItems("../EXE/DriverCollaborativeFiltering/itemsTesteo.csv"));
            ficheroItems = "../EXE/DriverCollaborativeFiltering/itemsTesteo.csv";
        }

        if(valoraciones) {
            cargarFicherosPropios = false;
            System.out.println("Dinos la ruta de tu fichero de VALORACIONES (deberia estar en el directorio ./FONTS), escribe 'Salir' para cargar los ficheros de testeo del sistema.");
            fichero = scanner.nextLine();
            while (!fichero.equals("Salir")) {
                try {
                    CtrlDominio.Instance().guardarValoraciones(new CtrlPersistencia().importarValoraciones(fichero));
                    cargarFicherosPropios = true;
                    ficheroValoraciones = fichero;
                    break;
                } catch (Exception e) {
                    System.out.println("Ejemplo, para cargar el fichero 'ratings.db.csv' escribe: 'EXE/CollaborativeFiltering/valoracionesTesteo.csv'");
                    System.out.println("Tu fichero preferentemente deberia estar en el directorio ./EXE/CollaborativeFiltering/, prueba otra vez...");
                    fichero = scanner.nextLine();
                }
            }
            if (!cargarFicherosPropios) {
                CtrlDominio.Instance().guardarValoraciones(new CtrlPersistencia().importarValoraciones("../EXE/DriverCollaborativeFiltering/valoracionesTesteo.csv"));
                ficheroValoraciones = "../EXE/DriverCollaborativeFiltering/valoracionesTesteo.csv";
            }

        } else {
            CtrlDominio.Instance().guardarValoraciones(new CtrlPersistencia().importarValoraciones("../EXE/DriverCollaborativeFiltering/valoracionesTesteo.csv"));
            ficheroValoraciones = "../EXE/DriverCollaborativeFiltering/valoracionesTesteo.csv";
        }

    }

    public static void pedirEnter() {
        // PARA MEJORAR LA INTERFICIE, SE CONGELA EL PROGRAMA HASTA QUE PRESIONES ENTER O CUALQUIER LETRA
        Scanner input = new Scanner(System.in);
        System.out.println("Enter para continuar...");
        String enter = input.nextLine();
    }

    public static boolean TestCargarValoraciones() throws IOException {

        System.out.println("Para este test se tienen que cargar datos sobre valoraciones");
        Scanner scanner = new Scanner(System.in);
        boolean valoraciones;
        System.out.println("Quieres cargar un fichero propio para las VALORACIONES de testeo? [Y/n]");
        String inp;
        inp = scanner.nextLine();
        valoraciones = inp.equals("Y");
        pedirJuegosDePruebas(false, valoraciones);

        System.out.println("\n\tTEST CARGAR VALORACIONES\n");
        System.out.println("Este metodo sirve para cargar las valoraciones de un fichero o conjunto de ficheros.\nEjemplo de funcionamiento con varios juegos de pruebas del sistema:");
        pedirEnter();

        cf.CargarValoraciones("EXE/DriverCollaborativeFiltering/valoracionesTesteo.csv");
        System.out.println("Valoraciones cargadas del fichero " + ficheroValoraciones + ":");
        System.out.println("ItemID Rating UserID");
        for(Valoracion v : CtrlDominio.Instance().getValoraciones()) {
            System.out.println(v.get_Item().getID() + " " + v.getValor() + " " + v.getUser());
        }

        pedirEnter();

        return true;
    }

    public static boolean TestCalcularPosiciones() throws IOException {

        System.out.println("Para este test se tienen que cargar datos sobre items y valoraciones");
        Scanner scanner = new Scanner(System.in);
        boolean items;
        boolean valoraciones;
        System.out.println("Quieres cargar un fichero propio para los ITEMS de testeo? [Y/n]");
        String inp = scanner.nextLine();
        items = inp.equals("Y");
        System.out.println("Quieres cargar un fichero propio para las VALORACIONES de testeo? [Y/n]");
        inp = scanner.nextLine();
        valoraciones = inp.equals("Y");
        pedirJuegosDePruebas(items, valoraciones);

        System.out.println("\tTEST CALCULAR POSICIONES\n");
        System.out.println("");

        cf.EliminarValoracionesCargadas();
        cf.CargarValoraciones(ficheroValoraciones);
        cf.calcularPosiciones();
        Iterator it = cf.posiciones.keySet().iterator();
        while(it.hasNext()) {
            String key = (String)it.next();
            System.out.println(key + ": " + cf.posiciones.get(key).getValores());
        }

        pedirEnter();

        return true;    // se ha completado correctamente
    }

    public static boolean TestKMeans() throws IOException {

        System.out.println("Para este test se tienen que cargar datos sobre items y valoraciones");
        Scanner scanner = new Scanner(System.in);
        boolean items;
        boolean valoraciones;
        System.out.println("Quieres cargar un fichero propio para los ITEMS de testeo? [Y/n]");
        String inp = scanner.nextLine();
        items = inp.equals("Y");
        System.out.println("Quieres cargar un fichero propio para las VALORACIONES de testeo? [Y/n]");
        inp = scanner.nextLine();
        valoraciones = inp.equals("Y");
        pedirJuegosDePruebas(items, valoraciones);

        System.out.println("\n\tTEST CALCULAR KMEANS\n");

        cf.EliminarValoracionesCargadas();
        cf.CargarValoraciones(ficheroValoraciones);
        cf.calcularPosiciones();
        cf.ElbowTest();
        cf.KMeans();
        int i=1;
        for(Cluster c : cf.clusters) {
            System.out.println("Cluster-"+i+": " + c.getUsers());
            i++;
        }

        pedirEnter();

        return true;
    }

    public static boolean TestRecomendarItem() {

        System.out.println("Para este test se tienen que cargar datos sobre items y valoraciones");
        Scanner scanner = new Scanner(System.in);
        boolean items;
        boolean valoraciones;
        System.out.println("Quieres cargar un fichero propio para los ITEMS de testeo? [Y/n]");
        String inp = scanner.nextLine();
        items = inp.equals("Y");
        System.out.println("Quieres cargar un fichero propio para las VALORACIONES de testeo? [Y/n]");
        inp = scanner.nextLine();
        valoraciones = inp.equals("Y");
        pedirJuegosDePruebas(items, valoraciones);

        System.out.println("\tDRIVER RECOMENDAR ITEMS\n");

        System.out.println("Valora los items que quieras y luego se te recomendaran items:");
        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Quieres valorar un item? [Y/n]");
        inp = scanner1.nextLine();
        while(inp.equals("Y")) {
            scanner1 = new Scanner(System.in);
            System.out.println("Dinos el id del item a valorar");
            String id = scanner1.nextLine();
            if(CtrlDominio.Instance().existe_item(id)) {
                Item itemValorado = CtrlDominio.Instance().getItembyID(id);
                scanner = new Scanner(System.in);
                System.out.println("Dinos el rating del item a valorar");
                try {
                    double rating = scanner.nextDouble();
                    Valoracion v = new Valoracion(itemValorado,rating,"99999999");
                    CtrlDominio.Instance().addValoracion(v);
                } catch (NumberFormatException e) {
                    System.out.println("Formato de rating incorrecto.");
                }
            }
            else System.out.println("No existe el item con id " + id + ".");

            System.out.println("Quieres volver a valorar un item? [Y/n]");
            inp = scanner1.nextLine();
        }

        cf.ImportarValoraciones(CtrlDominio.Instance().getValoraciones());
        cf.calcularPosiciones();
        cf.ElbowTest();
        cf.KMeans();

        ArrayList<Item> item = cf.RecomendarItem("99999999", 3);

        int i=1;
        System.out.println("Items recomendados para ti (si no has valorado ningun item no se te recomendara nada):");
        for(Item it : item) {
            System.out.println(i+": " + it.getID());
        }
        System.out.println();

        pedirEnter();

        return true;
    }

    public static void main(String args[]) throws IOException {

        ctrl = CtrlDominio.Instance();

        System.out.println("\tDRIVER COLLABORATIVE FILTERING\n");

        boolean ret = true;
        while(ret) {

            System.out.println("\tMetodos principales de la clase:");
            System.out.println("\t1. Cargar Valoraciones");
            System.out.println("\t2. Calcular posiciones");
            System.out.println("\t3. KMeans");
            System.out.println("\t4. Recomendar items o SlopeOne");

            System.out.println("\nSelecciona el metodo que quieras testear...");

            Scanner input = new Scanner(System.in);
            int option = input.nextInt();
            while (option < 1 && option > 4) option = input.nextInt();

            // TESTEO de cada metodo

            cf = new CollaborativeFiltering();

            switch (option) {
                case 1:
                    ret = TestCargarValoraciones();
                    break;

                case 2:
                    ret = TestCalcularPosiciones();
                    break;

                case 3:
                    ret = TestKMeans();
                    break;

                case 4:
                    ret = TestRecomendarItem();
                    break;

                default:
                    ret = false;
                    break;
            }
        }

        ctrl = null;

    }

}
