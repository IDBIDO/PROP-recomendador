package project;

import java.util.ArrayList;

public class Distancias {

    public static double distanciaEucladiana(ArrayList<Double> a, ArrayList<Double> b) {

        if(a.size() != b.size()) {
            System.out.println("LANZAR EXCEPCION! DISTANCIA EUCLIDIANA ENTRE DOS PUNTOS DE DIFERENTE DIMENSION");
            
            return 0.0;
        }

        double sumatorio = 0.0;
        for(int i=0; i<a.size(); i++) {
            sumatorio += Math.pow( (a.get(i) - b.get(i) ) , 2);
        }

        return Math.sqrt(sumatorio);

    }

    public static Double distancia_dos_items(ArrayList<String> a, ArrayList<String> b) {


        int n = a.size();
        int igual = 0;

        for (int i = 0; i < n; ++i) {
            if (!a.get(i).isEmpty()) {
                if (a.get(i).equals(b.get(i))) ++igual;
            }
        }

        if (igual == 0) return Double.MAX_VALUE;
        return ((n*1.0) / igual);

    }

    public static ArrayList<Double> sumarVectores(ArrayList<Double> a, ArrayList<Double> b) {
        if(a.size()!=b.size()) {
            System.out.println("EXCEPCION DIFERENTES DIMENSIONES SUMA DE VECTORES!");
            return new ArrayList<>();
        }
        ArrayList<Double> resultado = new ArrayList<>();
        for(int i=0; i<a.size(); i++) {
            resultado.add(a.get(i)+b.get(i));
        }
        return resultado;
    }

    public static ArrayList<Double> escalarVector(ArrayList<Double> a, double escalar) {
        ArrayList<Double> resultado = new ArrayList<>();
        for(int i=0; i<a.size(); i++) {
            resultado.add(a.get(i)*escalar);
        }
        return resultado;
    }


}
