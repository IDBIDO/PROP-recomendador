package project;

import java.util.ArrayList;
import java.util.Collections;

/**Define la cabecera de cada tipo de item */
public class TipoItem {


    private String nombre_tipo;             //nombre del Tipo de item
    private ArrayList<String> columnas;      //nombres de las columnas de la cabecera que lo define

    //--------------------------------------

    /**Construye un item vacio*/
    public TipoItem() {
        nombre_tipo = "";
        columnas = new ArrayList<String>();
    }

    /**Construye un item con nombre*/
    public TipoItem(String nombre) {
        this.nombre_tipo = nombre;
        columnas = new ArrayList<String>();
    }

    public TipoItem(String nombre, ArrayList<String> columnas) {
        this.nombre_tipo = nombre;
        this.columnas = columnas;
    }

    //--------------------------------------

    /**Devuelve el nombre del tipo de item*/
    public String getNombre_tipo() {
        return nombre_tipo;
    }

    /**Devuelve los nombres de las columnas de la cabecera*/
    public ArrayList<String> getCabecera() {
        return columnas;
    }

    /**Setea el nombre del tipo de item*/
    public void setNombre_tipo(String nombre_tipo) {
        this.nombre_tipo = nombre_tipo;
    }

    //---------------------------------------

    /**Añade columnas en la cabecera y las ordena*/
    public void addCabecera(ArrayList<String> columnas_nuevas) {
        for (String nombre : columnas_nuevas) {
            columnas.add(nombre);
        }
        Collections.sort(columnas, String.CASE_INSENSITIVE_ORDER);  //reordena la cabecera en orden alfabetico
    }

    /**Borra una columna de la cabecera y las ordena*/
    public void delCabecera(String columna) {
        for (int i = 0; i< columnas.size(); i++) {
            if(columnas.get(i) == columna) {
                columnas.remove(i);
            }
        }
        Collections.sort(columnas, String.CASE_INSENSITIVE_ORDER);  //reordena la cabecera en orden alfabetico
    }

}
