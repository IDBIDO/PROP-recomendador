## SISTEMA RECOMENDADOR

EQUIP 10.2

### Uso del makefile 🔧

_Comandos que te permiten usar el makefile_
```
	make class                             Compila el codi
	make run                               Executa el codi del main
	make runtest                           Test JUnit de la clase Distancias
	make runtest2                          Test JUnit de la clase ContentBasedFiltering
	make driverAdmin                       Driver de la classe Admin
	make driverContent_Based               Driver de la classe contentbasedFiltering
	make driverUsuarioActivo               Driver de la classe UsuarioActivo
	make driverItem                        Driver de la classe Item
	make driverTipotem                     Driver de la classe TipoItem
	make driverPerfil                      Driver de la classe Perfil
	make driverValoracion                  Driver de la classe Valoracion
	make driverK_nearest_neighbours        Driver de la classe k_nearest_neighbours
	make driverCtrlDominio                 Driver de la classe CtrlDominio
	make driverCollaborativeFiltering      Driver de la classe CollaborativeFiltering
	make clean                             borra los .class

```
_Siempre que necesites información sobre los comandos del make usa -> make help_

### Uso de la cuenta administrador📋

_Para usar el modo administrador tenemos ya la cuenta registrada con las siguientes credenciales, esta cuenta te permite generar algunos casos de uso que el usuario no puede_

```
User: admin
Password: 123
```

_Siempre que quieras usar el sistema como usuario tienes que registrarte con la aplicación._

```
Miembros del equipo:
Pablo Montón Gimeno
Victor Pla Sanchis
He Chen
Monica Jimenez Candela
```
